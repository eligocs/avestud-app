export class AuthConstants {
    public static readonly AUTH = 'userData'
    public static readonly otp = 'otp'
    public static readonly phone = 'phone'
    public static readonly pwd = 'pwd'
    public static readonly Role = 'pwd'
    public static readonly userdetails = 'pwd'
};