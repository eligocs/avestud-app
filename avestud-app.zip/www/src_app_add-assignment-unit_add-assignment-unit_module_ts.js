(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_add-assignment-unit_add-assignment-unit_module_ts"],{

/***/ 8990:
/*!***************************************************************************!*\
  !*** ./src/app/add-assignment-unit/add-assignment-unit-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddAssignmentUnitPageRoutingModule": () => (/* binding */ AddAssignmentUnitPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _add_assignment_unit_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-assignment-unit.page */ 6023);




const routes = [
    {
        path: '',
        component: _add_assignment_unit_page__WEBPACK_IMPORTED_MODULE_0__.AddAssignmentUnitPage
    }
];
let AddAssignmentUnitPageRoutingModule = class AddAssignmentUnitPageRoutingModule {
};
AddAssignmentUnitPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddAssignmentUnitPageRoutingModule);



/***/ }),

/***/ 7320:
/*!*******************************************************************!*\
  !*** ./src/app/add-assignment-unit/add-assignment-unit.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddAssignmentUnitPageModule": () => (/* binding */ AddAssignmentUnitPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _add_assignment_unit_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-assignment-unit-routing.module */ 8990);
/* harmony import */ var _add_assignment_unit_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-assignment-unit.page */ 6023);







let AddAssignmentUnitPageModule = class AddAssignmentUnitPageModule {
};
AddAssignmentUnitPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_assignment_unit_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddAssignmentUnitPageRoutingModule
        ],
        declarations: [_add_assignment_unit_page__WEBPACK_IMPORTED_MODULE_1__.AddAssignmentUnitPage]
    })
], AddAssignmentUnitPageModule);



/***/ }),

/***/ 6023:
/*!*****************************************************************!*\
  !*** ./src/app/add-assignment-unit/add-assignment-unit.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddAssignmentUnitPage": () => (/* binding */ AddAssignmentUnitPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_add_assignment_unit_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./add-assignment-unit.page.html */ 6805);
/* harmony import */ var _add_assignment_unit_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-assignment-unit.page.scss */ 2042);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/toast.service */ 4465);












let AddAssignmentUnitPage = class AddAssignmentUnitPage {
    constructor(router, authService, storageService, homeService, route, toastService) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
        this.postData = {
            unitName: ''
        };
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            this.iacs = params['iacs'];
            this.subject = params['subject'];
            if (this.iacs && this.subject) {
                this.previousUrl = 'assignments?iacs=' + this.iacs + '&subject=' + this.subject;
            }
        });
    }
    createAssigmentUnit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                unitName: this.postData.unitName,
                iacsId: this.iacs,
            };
            if (newData) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                yield this.homeService.createAssigmentUnit(newData, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.toastService.presentToast(res.msg);
                        let navigationExtras = {
                            queryParams: { 'iacs': this.iacs },
                            fragment: 'anchor'
                        };
                        this.router.navigate(['assignments'], navigationExtras);
                    }
                    else {
                        this.toastService.presentToast(res.msg);
                    }
                });
            }
        });
    }
};
AddAssignmentUnitPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService }
];
AddAssignmentUnitPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-add-assignment-unit',
        template: _raw_loader_add_assignment_unit_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_add_assignment_unit_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddAssignmentUnitPage);



/***/ }),

/***/ 2042:
/*!*******************************************************************!*\
  !*** ./src/app/add-assignment-unit/add-assignment-unit.page.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".assignment_form {\n  padding: 0 18px;\n  margin-top: 15px;\n}\n\n.assignment_form ion-label {\n  font-size: 16px;\n  color: #717171;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400 !important;\n}\n\n.assignment_form ion-input {\n  height: 46px;\n  border: 1px solid #bfbfbf;\n  color: #4e4c4c;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400 !important;\n  font-size: 14px;\n  border-radius: 6px;\n  margin-top: 4px;\n  width: 100%;\n}\n\nion-checkbox {\n  width: 14px;\n  height: 14px;\n  top: 1px;\n}\n\n.checkbox {\n  margin-top: 8px;\n}\n\n.btns {\n  margin-top: 16px;\n}\n\n.btns button {\n  width: 100px;\n  height: 36px;\n  font-size: 13px;\n  color: white;\n  border-radius: 5px;\n  font-size: 12px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n#add {\n  background-color: #644699;\n  margin-right: 5px;\n}\n\n#reset {\n  background-color: #e03e91;\n  margin-left: 5px;\n}\n\n.lectureSelect {\n  width: 100%;\n  height: 44px;\n  border-radius: 4px;\n  border: 1px solid #cfcfcf;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1hc3NpZ25tZW50LXVuaXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGtDQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFRTtFQUNFLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUFDSjs7QUFFRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsUUFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtBQUNKOztBQUVFO0VBQ0UsZ0JBQUE7QUFDSjs7QUFFRTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQ0FBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSx5QkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUU7RUFDRSx5QkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBSUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUFESiIsImZpbGUiOiJhZGQtYXNzaWdubWVudC11bml0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hc3NpZ25tZW50X2Zvcm0ge1xyXG4gICAgcGFkZGluZzogMCAxOHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTVweDtcclxuICB9XHJcbiAgXHJcbiAgLmFzc2lnbm1lbnRfZm9ybSBpb24tbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgY29sb3I6ICM3MTcxNzE7XHJcbiAgICBmb250LWZhbWlseTogXCJQb3BwaW5zXCIsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5hc3NpZ25tZW50X2Zvcm0gaW9uLWlucHV0IHtcclxuICAgIGhlaWdodDogNDZweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNiZmJmYmY7XHJcbiAgICBjb2xvcjogIzRlNGM0YztcclxuICAgIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICBcclxuICBpb24tY2hlY2tib3gge1xyXG4gICAgd2lkdGg6IDE0cHg7XHJcbiAgICBoZWlnaHQ6IDE0cHg7XHJcbiAgICB0b3A6IDFweDtcclxuICB9XHJcbiAgXHJcbiAgLmNoZWNrYm94IHtcclxuICAgIG1hcmdpbi10b3A6IDhweDtcclxuICB9XHJcbiAgXHJcbiAgLmJ0bnMge1xyXG4gICAgbWFyZ2luLXRvcDogMTZweDtcclxuICB9XHJcbiAgXHJcbiAgLmJ0bnMgYnV0dG9uIHtcclxuICAgIHdpZHRoOiAxMDBweDtcclxuICAgIGhlaWdodDogMzZweDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgfVxyXG4gIFxyXG4gICNhZGQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzY0NDY5OTtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuICBcclxuICAjcmVzZXQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2UwM2U5MTtcclxuICAgIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbiAgfVxyXG4gIFxyXG4gICBcclxuXHJcbiAgLmxlY3R1cmVTZWxlY3Qge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2ZjZmNmO1xyXG59XHJcbiAgIl19 */");

/***/ }),

/***/ 6805:
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-assignment-unit/add-assignment-unit.page.html ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar> \n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\">  \n            <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button> \n        </ion-col> \n        <ion-col size=\"5\"> \n          <p class=\"ion-text-center heading\">Add Assignment Unit</p> \n        </ion-col> \n        <ion-col size=\"4\"> \n          <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div> \n        </ion-col> \n      </ion-row>\n    </ion-grid> \n  </ion-toolbar> \n</ion-header> \n\n<ion-content>\n  <div class=\"comman_page_padding \">\n    <br>\n  <form class=\"assignment_form\"> \n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Unit Name</ion-label>\n        <ion-input name='unitName'    [(ngModel)]=\"postData.unitName\" required placeholder=\"Enter Assignment Unit Name\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    \n    <!--btns--> \n    <div class=\"btns ion-text-center\">\n      <button id=\"add\" (click)=\"createAssigmentUnit()\" >Add</button> \n    </div>\n  </form>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_add-assignment-unit_add-assignment-unit_module_ts.js.map