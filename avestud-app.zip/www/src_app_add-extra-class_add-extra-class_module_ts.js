(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_add-extra-class_add-extra-class_module_ts"],{

/***/ 398:
/*!*******************************************************************!*\
  !*** ./src/app/add-extra-class/add-extra-class-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddExtraClassPageRoutingModule": () => (/* binding */ AddExtraClassPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _add_extra_class_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-extra-class.page */ 8161);




const routes = [
    {
        path: '',
        component: _add_extra_class_page__WEBPACK_IMPORTED_MODULE_0__.AddExtraClassPage
    }
];
let AddExtraClassPageRoutingModule = class AddExtraClassPageRoutingModule {
};
AddExtraClassPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddExtraClassPageRoutingModule);



/***/ }),

/***/ 9674:
/*!***********************************************************!*\
  !*** ./src/app/add-extra-class/add-extra-class.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddExtraClassPageModule": () => (/* binding */ AddExtraClassPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _add_extra_class_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-extra-class-routing.module */ 398);
/* harmony import */ var _add_extra_class_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-extra-class.page */ 8161);







let AddExtraClassPageModule = class AddExtraClassPageModule {
};
AddExtraClassPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_extra_class_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddExtraClassPageRoutingModule
        ],
        declarations: [_add_extra_class_page__WEBPACK_IMPORTED_MODULE_1__.AddExtraClassPage]
    })
], AddExtraClassPageModule);



/***/ }),

/***/ 8161:
/*!*********************************************************!*\
  !*** ./src/app/add-extra-class/add-extra-class.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddExtraClassPage": () => (/* binding */ AddExtraClassPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_add_extra_class_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./add-extra-class.page.html */ 2158);
/* harmony import */ var _add_extra_class_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-extra-class.page.scss */ 4792);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/toast.service */ 4465);












let AddExtraClassPage = class AddExtraClassPage {
    constructor(router, authService, storageService, homeService, route, toastService) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
        this.postData = {
            unit: '',
            number: '',
            lecturename: '',
            date: '',
            old_id: '',
        };
        this.notes = null;
        this.video = null;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.lectureid = params['lectureid'];
                if (this.iacs, this.subject) {
                    this.previousUrl = 'extraclass?iacs=' + this.iacs + '&subject=' + this.subject;
                }
                if (this.lectureid) {
                    this.getoldlecture(this.lectureid);
                }
                else {
                    this.postData = {
                        unit: '',
                        number: '',
                        lecturename: '',
                        date: '',
                        old_id: '',
                    };
                }
            });
            if (this.iacs) {
                var classid = this.iacs;
                var classroom = yield this.homeService.getClassunits(classid, token).subscribe((res) => {
                    if (res) {
                        this.units = res.data;
                    }
                });
            }
        });
    }
    getoldlecture(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            if (id) {
                var lectureid = id;
                var classroom = yield this.homeService.getExtraClass(lectureid, token).subscribe((res) => {
                    if (res) {
                        this.olddata = res.data;
                    }
                });
            }
        });
    }
    onChange(event) {
        this.notes = event.target.files[0];
    }
    onChangeVideo(event) {
        this.video = event.target.files[0];
    }
    createExtraClass() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                unit: this.postData.unit,
                number: this.postData.number,
                lecturename: this.postData.lecturename,
                old_id: this.lectureid,
                date: this.postData.date,
                notes: this.notes,
                video: this.video,
                i_assigned_class_subject_id: this.iacs
            };
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            if (newData && token) {
                var classid = this.iacs;
                yield this.homeService.createExtraClass(newData, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.toastService.presentToast(res.msg);
                        window.location.href = 'extraclass?iacs=' + this.iacs + '&subject=' + this.subject;
                    }
                    else {
                        this.toastService.presentToast('Fail to add extra class !!!');
                    }
                });
            }
        });
    }
};
AddExtraClassPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService }
];
AddExtraClassPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-add-extra-class',
        template: _raw_loader_add_extra_class_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_add_extra_class_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddExtraClassPage);



/***/ }),

/***/ 4792:
/*!***********************************************************!*\
  !*** ./src/app/add-extra-class/add-extra-class.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".add_lecture_form {\n  padding: 10px 20px;\n}\n\n.form_tittle {\n  font-size: 18px;\n  color: #644699;\n  margin-left: 20px;\n  font-weight: 400;\n  margin-top: 8px;\n}\n\nion-select {\n  height: 45px;\n  border: 0.5px solid #dcd4d4;\n  color: #292727;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.add_lecture_form ion-label {\n  color: #363636;\n  font-size: 16px;\n  font-weight: 400 !important;\n}\n\n.add_lecture_form ion-input {\n  height: 45px;\n  border: 0.5px solid #e0d9d9;\n  color: #4e4c4c;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.add_lecture_form ion-datetime {\n  height: 45px;\n  border: 0.5px solid #dcd9d9;\n  color: #989393;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.calender {\n  position: relative;\n}\n\n.calender_icon {\n  position: absolute;\n  top: 50%;\n  right: 5%;\n}\n\n.drag_drop {\n  border: 1px solid #d9d2d2;\n  height: 102px;\n  width: 100%;\n  border-radius: 11px;\n  background: url('pdf_img.svg');\n  background-repeat: no-repeat;\n  background-position-x: center;\n  background-position-y: center;\n  margin-top: 5px;\n}\n\n::-webkit-file-upload-button {\n  display: none;\n}\n\n.mg_top {\n  margin-top: 12px;\n}\n\n.lectureSelect {\n  width: 100%;\n  height: 44px;\n  border-radius: 4px;\n  border: 1px solid #cfcfcf;\n}\n\n.date_ipn {\n  width: 100%;\n  height: 44px;\n  border-radius: 4px;\n  border: 1px solid #cfcfcf;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1leHRyYS1jbGFzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxrQkFBQTtBQURKOztBQU1FO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUhKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQUxKOztBQVFFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSwyQkFBQTtBQUxKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQUxKOztBQVNFO0VBQ0UsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQU5KOztBQVNFO0VBQ0Usa0JBQUE7QUFOSjs7QUFTRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUFOSjs7QUFXRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBQVJKOztBQVdFO0VBQ0UsYUFBQTtBQVJKOztBQVdFO0VBQ0UsZ0JBQUE7QUFSSjs7QUFxQkE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUFsQko7O0FBb0JBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FBakJKIiwiZmlsZSI6ImFkZC1leHRyYS1jbGFzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBhZGRfbGVjdHVyZV9mb3JtXHJcblxyXG4uYWRkX2xlY3R1cmVfZm9ybSB7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIGZvcm1fdGl0dGxlXHJcbiAgXHJcbiAgLmZvcm1fdGl0dGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGNvbG9yOiAjNjQ0Njk5O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgbWFyZ2luLXRvcDogOHB4O1xyXG4gIH1cclxuICBcclxuICAvLyBpb24tbGFiZWwgYW5kIGlvbi1pbnB1dFxyXG4gIFxyXG4gIGlvbi1zZWxlY3Qge1xyXG4gICAgaGVpZ2h0OiA0NXB4O1xyXG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjZGNkNGQ0O1xyXG4gICAgY29sb3I6ICMyOTI3Mjc7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJQb3BwaW5zXCIsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gIH1cclxuICBcclxuICAuYWRkX2xlY3R1cmVfZm9ybSBpb24tbGFiZWwge1xyXG4gICAgY29sb3I6ICMzNjM2MzY7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5hZGRfbGVjdHVyZV9mb3JtIGlvbi1pbnB1dCB7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkICNlMGQ5ZDk7XHJcbiAgICBjb2xvcjogIzRlNGM0YztcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIENob29zZSBkYXRlIGlucHV0XHJcbiAgLmFkZF9sZWN0dXJlX2Zvcm0gaW9uLWRhdGV0aW1lIHtcclxuICAgIGhlaWdodDogNDVweDtcclxuICAgIGJvcmRlcjogMC41cHggc29saWQgI2RjZDlkOTtcclxuICAgIGNvbG9yOiAjOTg5MzkzO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB9XHJcbiAgXHJcbiAgLmNhbGVuZGVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB9XHJcbiAgXHJcbiAgLmNhbGVuZGVyX2ljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICByaWdodDogNSU7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIGZpbGUgdXBsb2FkZXIgLyBkcmFnIGFuZCBkcm9wXHJcbiAgXHJcbiAgLmRyYWdfZHJvcCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZDlkMmQyO1xyXG4gICAgaGVpZ2h0OiAxMDJweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTFweDtcclxuICAgIGJhY2tncm91bmQ6IHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL3BkZl9pbWcuc3ZnKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXg6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb24teTogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gIH1cclxuICBcclxuICA6Oi13ZWJraXQtZmlsZS11cGxvYWQtYnV0dG9uIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIFxyXG4gIC5tZ190b3Age1xyXG4gICAgbWFyZ2luLXRvcDogMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLy8gLmZvcm1fYnRuIGJ1dHRvbiB7XHJcbiAgLy8gICBoZWlnaHQ6IDM2cHg7XHJcbiAgLy8gICB3aWR0aDogNzFweDtcclxuICAvLyAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAvLyAgIGNvbG9yOiB3aGl0ZTtcclxuICAvLyAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgLy8gICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgLy8gICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIC8vIH1cclxuXHJcbi5sZWN0dXJlU2VsZWN0IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NmY2ZjZjtcclxufVxyXG4uZGF0ZV9pcG4ge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2ZjZmNmO1xyXG59XHJcbiAgIl19 */");

/***/ }),

/***/ 2158:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-extra-class/add-extra-class.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--Ion-Header Start-->\n<ion-header>\n  <ion-toolbar>\n     <ion-grid>\n        <ion-row>\n           <ion-col size=\"3\">\n              <ion-buttons>\n                <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button>\n              </ion-buttons>\n           </ion-col>\n           <ion-col size=\"5\">\n              <p class=\"ion-text-center heading\">Add Extra Class</p>\n           </ion-col>\n           <ion-col size=\"4\">\n              <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n           </ion-col>\n        </ion-row>\n     </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<!--Ion-Header Ends-->\n<!--ion-content Start-->\n<ion-content>\n  <h1 class=\"form_tittle\">Add Extra Class</h1>\n  <!--add_lecture_form Start-->\n  <form class=\"add_lecture_form\">\n    <!--Select Unit*-->\n    <ion-row>\n      <ion-col  >\n        <select class='lectureSelect' value=\"{{olddata?.unit_id}}\" [(ngModel)]=\"postData.unit\" name='unit'>\n          <option *ngFor=\"let unit of units\" value=\"{{unit.id}}\">{{unit.name}}</option>\n        </select> \n      </ion-col>\n    </ion-row>\n    <!--Lecture Number*--> \n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Extra Class Number*</ion-label>\n        <ion-input  [(ngModel)]=\"postData.number\" value='{{olddata?.extra_class_number}}' autocomplete=\"off\" name=\"number\"  required placeholder=\"Lecture Number\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Lecture Name*-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Extra Class Name*</ion-label>\n        <ion-input required placeholder=\"Lecture Name\" value='{{olddata?.extra_class_name}}'  [(ngModel)]=\"postData.lecturename\" autocomplete=\"off\" name=\"lecturename\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Lecture Date*-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Extra class Date*</ion-label>\n        <ion-datetime displayFormat=\"DD MM YYYY\" value='{{olddata?.extra_class_date}}'  [(ngModel)]=\"postData.date\" autocomplete=\"off\" name=\"date\" placeholder=\"Select Date\"></ion-datetime>\n        <img class=\"calender_icon\" src=\"../../assets/images/calender.svg\">\n      </ion-col>\n    </ion-row>\n    <!--file upload / drag and-->\n    <ion-row class=\"mg_top\">\n      <ion-col class=\"pdf_img\">\n        <ion-label position=\"stacked\">Upload Notes*</ion-label>\n        <input class=\"drag_drop\"  name=\"notes\" (change)=\"onChange($event)\"  type=\"file\" id=\"notes\"  /><br />\n        <!-- <img src=\"../../assets/imgs/pdf_img.svg\" class=\"pdf_img\"> -->\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"mg_top\">\n      <ion-col class=\"pdf_img\">\n        <ion-label position=\"stacked\">Upload Video (You can add later)</ion-label><br/>\n        <small>Only extra class with video will show to students</small>\n        <input class=\"drag_drop\"  name=\"video\" (change)=\"onChangeVideo($event)\"  type=\"file\" id=\"video\"  /><br />\n        <!-- <img src=\"../../assets/imgs/pdf_img.svg\" class=\"pdf_img\"> -->\n      </ion-col>\n    </ion-row>\n    <ion-button expand=\"block\" share=\"round\" color=\"success\" (click)=\"createExtraClass()\">Save</ion-button>\n  </form>\n   <!--add_lecture_form End-->\n</ion-content>\n ");

/***/ })

}]);
//# sourceMappingURL=src_app_add-extra-class_add-extra-class_module_ts.js.map