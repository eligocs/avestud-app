(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_add-question_add-question_module_ts"],{

/***/ 2236:
/*!*************************************************************!*\
  !*** ./src/app/add-question/add-question-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddQuestionPageRoutingModule": () => (/* binding */ AddQuestionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _add_question_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-question.page */ 3539);




const routes = [
    {
        path: '',
        component: _add_question_page__WEBPACK_IMPORTED_MODULE_0__.AddQuestionPage
    }
];
let AddQuestionPageRoutingModule = class AddQuestionPageRoutingModule {
};
AddQuestionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddQuestionPageRoutingModule);



/***/ }),

/***/ 8796:
/*!*****************************************************!*\
  !*** ./src/app/add-question/add-question.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddQuestionPageModule": () => (/* binding */ AddQuestionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _add_question_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-question-routing.module */ 2236);
/* harmony import */ var _add_question_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-question.page */ 3539);







let AddQuestionPageModule = class AddQuestionPageModule {
};
AddQuestionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_question_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddQuestionPageRoutingModule
        ],
        declarations: [_add_question_page__WEBPACK_IMPORTED_MODULE_1__.AddQuestionPage]
    })
], AddQuestionPageModule);



/***/ }),

/***/ 3539:
/*!***************************************************!*\
  !*** ./src/app/add-question/add-question.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddQuestionPage": () => (/* binding */ AddQuestionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_add_question_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./add-question.page.html */ 2942);
/* harmony import */ var _add_question_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-question.page.scss */ 9690);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/toast.service */ 4465);












let AddQuestionPage = class AddQuestionPage {
    constructor(router, authService, storageService, homeService, route, toastService) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
        this.postData = {
            topic_id: '',
            question: '',
            a: '',
            b: '',
            c: '',
            d: '',
            answer: '',
            answer_exp: '',
            question_img: '',
        };
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            this.iacs = params['iacs'];
            this.subject = params['subject'];
            this.assignment_id = params['assignment_id'];
            this.pagetype = params['type'];
            if (this.pagetype == 'assignment') {
                this.previousUrl = 'list-question?iacs=' + this.iacs + '&subject=' + this.subject + '&assignment_id=' + this.assignment_id + '&type=assignment';
            }
            else {
                this.previousUrl = 'list-question?iacs=' + this.iacs + '&subject=' + this.subject + '&assignment_id=' + this.assignment_id + '&type=test';
            }
            if (this.assignment_id) {
                this.getSingleQuestion(this.assignment_id);
            }
            else {
                this.postData.topic_id = '';
                this.postData.question = '';
                this.postData.a = '';
                this.postData.b = '';
                this.postData.c = '';
                this.postData.d = '';
                this.postData.answer = '';
                this.postData.question_img = '';
            }
        });
    }
    onChange(event) {
        this.postData.question_img = event.target.files[0];
    }
    getSingleQuestion(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            if (id) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                yield this.homeService.getSAssigment(id, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.olddata = res.data;
                    }
                    else {
                        this.toastService.presentToast(res.msg);
                    }
                });
            }
        });
    }
    createAssigment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                topic_id: this.assignment_id,
                question: this.postData.question,
                a: this.postData.a,
                b: this.postData.b,
                c: this.postData.c,
                d: this.postData.d,
                answer: this.postData.answer,
                question_img: this.postData.question_img,
                iacs: this.iacs,
                testType: 1,
                old_id: this.old_id,
                answer_exp: this.postData.answer_exp,
            };
            if (newData) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                yield this.homeService.createAssigmentQuestion(newData, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.toastService.presentToast(res.msg);
                        let navigationExtras = {
                            queryParams: { 'iacs': this.iacs, 'subject': this.subject, 'assignment_id': this.assignment_id },
                            fragment: 'anchor'
                        };
                        this.router.navigate(['list-question'], navigationExtras);
                    }
                    else {
                        this.toastService.presentToast(res.msg);
                    }
                });
            }
        });
    }
};
AddQuestionPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService }
];
AddQuestionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-add-question',
        template: _raw_loader_add_question_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_add_question_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddQuestionPage);



/***/ }),

/***/ 9690:
/*!*****************************************************!*\
  !*** ./src/app/add-question/add-question.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".add_question_form {\n  padding: 0 18px;\n  margin-top: 10px;\n}\n\nion-content {\n  font-family: \"Poppins\", sans-serif;\n}\n\nion-select {\n  width: 100% !important;\n}\n\n.select_opt {\n  height: 39px;\n  width: 95%;\n  border: 1px solid #bfbfbf;\n  border-radius: 6px;\n}\n\n.drag_drop {\n  height: 124px;\n  border: 1px solid #bfbfbf;\n  width: 100%;\n  border-radius: 6px;\n  background: url('pdf_img.svg');\n  background-repeat: no-repeat;\n  background-position-x: center;\n  background-position-y: center;\n}\n\n.btn_bottom_mrgn {\n  margin-bottom: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1xdWVzdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUFBSjs7QUFLRTtFQUNFLGtDQUFBO0FBRko7O0FBS0U7RUFDRSxzQkFBQTtBQUZKOztBQUtFO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBRko7O0FBT0U7RUFDRSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSw2QkFBQTtBQUpKOztBQVFFO0VBQ0ksbUJBQUE7QUFMTiIsImZpbGUiOiJhZGQtcXVlc3Rpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gYWRkX3F1ZXN0aW9uX2Zvcm0gXHJcbi5hZGRfcXVlc3Rpb25fZm9ybXtcclxuICAgIHBhZGRpbmc6IDAgMThweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIGlvbi1pbnB1dCBcclxuICBcclxuICBpb24tY29udGVudCB7XHJcbiAgICBmb250LWZhbWlseTogXCJQb3BwaW5zXCIsIHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1zZWxlY3R7XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAuc2VsZWN0X29wdCB7XHJcbiAgICBoZWlnaHQ6IDM5cHg7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2JmYmZiZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICB9XHJcbiAgXHJcbiAgLy8gaW5wdXQgdHlwZSBmaWxlIGRyYWcvZHJvcCBhcmVhIFxyXG4gIFxyXG4gIC5kcmFnX2Ryb3Age1xyXG4gICAgaGVpZ2h0OiAxMjRweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNiZmJmYmY7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgIGJhY2tncm91bmQ6IHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL3BkZl9pbWcuc3ZnKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXg6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb24teTogY2VudGVyO1xyXG4gIH1cclxuICBcclxuXHJcbiAgLmJ0bl9ib3R0b21fbXJnbntcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICB9Il19 */");

/***/ }),

/***/ 2942:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-question/add-question.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n      <ion-grid>\n          <ion-row>\n              <ion-col size=\"3\">\n                  <ion-buttons>\n                      <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button>\n                  </ion-buttons>\n              </ion-col>\n              <ion-col size=\"5\">\n                  <p class=\"ion-text-center heading\">Add Question</p>\n              </ion-col>\n              <ion-col size=\"4\">\n                  <div class=\"avatar_icon\"></div>\n              </ion-col>\n          </ion-row>\n      </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form class=\"add_question_form\">\n    <!--Question-->\n    <ion-row>\n      <ion-col>\n        <ion-label position=\"stacked\">Question</ion-label>\n        <ion-textarea  value=\"{{olddata?.question}}\" [(ngModel)]=\"postData.question\"   name='question' class=\"text_area\" placeholder=\"Please Enter Question\"></ion-textarea>\n      </ion-col>\n    </ion-row>\n    <!--select Correct Answer-->\n    <ion-row>\n      <ion-col>\n        <ion-label>Correct Answer</ion-label>\n        <ion-select placeholder=\"Answers\" class=\"select_opt\"  value=\"{{olddata?.answer}}\" [(ngModel)]=\"postData.answer\" name='answer'>\n          <ion-select-option value='A'>A</ion-select-option>\n          <ion-select-option value='B'>B</ion-select-option>\n          <ion-select-option value='C'>C</ion-select-option>\n          <ion-select-option value='D'>D</ion-select-option>\n        </ion-select>\n      </ion-col>\n    </ion-row>\n    <!--option-->\n    <ion-row>\n      <ion-col>\n        <ion-label>A</ion-label>\n        <ion-input  value=\"{{olddata?.a}}\" [(ngModel)]=\"postData.a\" name='a' placeholder=\"Please Enter Option A\"></ion-input>\n      </ion-col>\n    </ion-row>\n     <!--option-->\n    <ion-row>\n      <ion-col>\n        <ion-label>B</ion-label>\n        <ion-input value=\"{{olddata?.b}}\" [(ngModel)]=\"postData.b\" name='b' placeholder=\"Please Enter Option B\"></ion-input>\n      </ion-col>\n    </ion-row>\n     <!--option-->\n    <ion-row>\n      <ion-col>\n        <ion-label>C</ion-label>\n        <ion-input value=\"{{olddata?.c}}\" [(ngModel)]=\"postData.c\" name='c' placeholder=\"Please Enter Option c\"></ion-input>\n      </ion-col>\n    </ion-row>\n     <!--option-->\n    <ion-row>\n      <ion-col>\n        <ion-label>D</ion-label>\n        <ion-input value=\"{{olddata?.d}}\" [(ngModel)]=\"postData.d\" name='d' placeholder=\"Please Enter Option D\"></ion-input>\n      </ion-col>\n    </ion-row>\n     <!--Answer Explaination-->\n    <ion-row>\n      <ion-col>\n        <ion-label position=\"stacked\">Answer Explaination</ion-label>\n        <ion-textarea class=\"text_area\" value=\"{{olddata?.answer_exp}}\" [(ngModel)]=\"postData.answer_exp\" name='answer_exp' placeholder=\"Please Enter The Explanation\"></ion-textarea>\n      </ion-col>\n    </ion-row>\n    <!--input type file-->\n    <ion-row>\n      <ion-col class=\"pdf_img\">\n        <ion-label>Add image to Question</ion-label>\n        <input class=\"drag_drop\" type=\"file\" id=\"file\" name=\"file\"  (change)=\"onChange($event)\"    /><br />\n      </ion-col>\n    </ion-row>\n    <ion-button class=\"btn_bottom_mrgn\" expand=\"block\" share=\"round\" color=\"success\" (click)=\"createAssigment()\">Save</ion-button>\n  </form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_add-question_add-question_module_ts.js.map