(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_add-test_add-test_module_ts"],{

/***/ 9922:
/*!*****************************************************!*\
  !*** ./src/app/add-test/add-test-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddTestPageRoutingModule": () => (/* binding */ AddTestPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _add_test_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-test.page */ 202);




const routes = [
    {
        path: '',
        component: _add_test_page__WEBPACK_IMPORTED_MODULE_0__.AddTestPage
    }
];
let AddTestPageRoutingModule = class AddTestPageRoutingModule {
};
AddTestPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddTestPageRoutingModule);



/***/ }),

/***/ 1435:
/*!*********************************************!*\
  !*** ./src/app/add-test/add-test.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddTestPageModule": () => (/* binding */ AddTestPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _add_test_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-test-routing.module */ 9922);
/* harmony import */ var _add_test_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-test.page */ 202);







let AddTestPageModule = class AddTestPageModule {
};
AddTestPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_test_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddTestPageRoutingModule
        ],
        declarations: [_add_test_page__WEBPACK_IMPORTED_MODULE_1__.AddTestPage]
    })
], AddTestPageModule);



/***/ }),

/***/ 202:
/*!*******************************************!*\
  !*** ./src/app/add-test/add-test.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddTestPage": () => (/* binding */ AddTestPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_add_test_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./add-test.page.html */ 5246);
/* harmony import */ var _add_test_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-test.page.scss */ 672);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/toast.service */ 4465);












let AddTestPage = class AddTestPage {
    constructor(router, authService, storageService, homeService, route, toastService) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
        this.postData = {
            unit: '',
            title: '',
            per_q_mark: '',
            description: '',
            old_id: '',
            show_ans: '',
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.assignment_id = params['assignment_id'];
                if (this.iacs && this.subject) {
                    this.previousUrl = 'test?iacs=' + this.iacs + '&subject=' + this.subject;
                }
                if (this.assignment_id) {
                    this.getSingleTest(this.assignment_id);
                }
                else {
                    this.postData.unit = '';
                    this.postData.title = '';
                    this.postData.per_q_mark = '';
                    this.postData.description = '';
                    this.postData.old_id = '';
                    this.postData.show_ans = '';
                }
            });
            if (this.iacs) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                var classid = this.iacs;
                var classroom = yield this.homeService.getTestunits(classid, token).subscribe((res) => {
                    if (res) {
                        this.units = res.data;
                    }
                });
            }
        });
    }
    getSingleTest(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            if (id) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                yield this.homeService.getSAssigment(id, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.olddata = res.data;
                    }
                    else {
                        this.toastService.presentToast('Something went wrong,try again later');
                    }
                });
            }
        });
    }
    createTest() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                unit: this.postData.unit,
                title: this.postData.title,
                per_q_mark: this.postData.per_q_mark,
                description: this.postData.description,
                show_ans: this.postData.show_ans ? true : false,
                iacsId: this.iacs
            };
            if (newData) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                yield this.homeService.createTest(newData, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.toastService.presentToast(res.msg);
                        let navigationExtras = {
                            queryParams: { 'iacs': this.iacs, 'subject': this.subject },
                            fragment: 'anchor'
                        };
                        this.router.navigate(['test'], navigationExtras);
                    }
                    else {
                        this.toastService.presentToast(res.msg);
                    }
                });
            }
        });
    }
};
AddTestPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService }
];
AddTestPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-add-test',
        template: _raw_loader_add_test_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_add_test_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddTestPage);



/***/ }),

/***/ 672:
/*!*********************************************!*\
  !*** ./src/app/add-test/add-test.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".assignment_form {\n  padding: 0 18px;\n  margin-top: 15px;\n}\n\n.assignment_form ion-label {\n  font-size: 16px;\n  color: #717171;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400 !important;\n}\n\n.assignment_form ion-input {\n  height: 46px;\n  border: 1px solid #bfbfbf;\n  color: #4e4c4c;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400 !important;\n  font-size: 14px;\n  border-radius: 6px;\n  margin-top: 4px;\n  width: 100%;\n}\n\nion-checkbox {\n  width: 14px;\n  height: 14px;\n  top: 1px;\n}\n\n.checkbox {\n  margin-top: 8px;\n}\n\n.btns {\n  margin-top: 16px;\n}\n\n.btns button {\n  width: 100px;\n  height: 36px;\n  font-size: 13px;\n  color: white;\n  border-radius: 5px;\n  font-size: 12px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n#add {\n  background-color: #644699;\n  margin-right: 5px;\n}\n\n#reset {\n  background-color: #e03e91;\n  margin-left: 5px;\n}\n\n.lectureSelect {\n  width: 100%;\n  height: 44px;\n  border-radius: 4px;\n  border: 1px solid #cfcfcf;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC10ZXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0FBQ0o7O0FBRUU7RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0NBQUE7RUFDQSwyQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBRUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7QUFDSjs7QUFFRTtFQUNFLGVBQUE7QUFDSjs7QUFFRTtFQUNFLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVFO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVFO0VBQ0UseUJBQUE7RUFDQSxnQkFBQTtBQUNKOztBQWFFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FBVkoiLCJmaWxlIjoiYWRkLXRlc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFzc2lnbm1lbnRfZm9ybSB7XHJcbiAgICBwYWRkaW5nOiAwIDE4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gIH1cclxuICBcclxuICAuYXNzaWdubWVudF9mb3JtIGlvbi1sYWJlbCB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogIzcxNzE3MTtcclxuICAgIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDAgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgLmFzc2lnbm1lbnRfZm9ybSBpb24taW5wdXQge1xyXG4gICAgaGVpZ2h0OiA0NnB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2JmYmZiZjtcclxuICAgIGNvbG9yOiAjNGU0YzRjO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgbWFyZ2luLXRvcDogNHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1jaGVja2JveCB7XHJcbiAgICB3aWR0aDogMTRweDtcclxuICAgIGhlaWdodDogMTRweDtcclxuICAgIHRvcDogMXB4O1xyXG4gIH1cclxuICBcclxuICAuY2hlY2tib3gge1xyXG4gICAgbWFyZ2luLXRvcDogOHB4O1xyXG4gIH1cclxuICBcclxuICAuYnRucyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gIH1cclxuICBcclxuICAuYnRucyBidXR0b24ge1xyXG4gICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgaGVpZ2h0OiAzNnB4O1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB9XHJcbiAgXHJcbiAgI2FkZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNjQ0Njk5O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgfVxyXG4gIFxyXG4gICNyZXNldCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTAzZTkxO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLy8gLnRleHRfYXJlYXtcclxuICAvLyAgICAgd2lkdGg6IDk1JTtcclxuICAvLyAgICAgaGVpZ2h0OiAxMDJweDtcclxuICAvLyAgICAgYm9yZGVyOiAxcHggc29saWQgI0JGQkZCRjtcclxuICAvLyAgICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIC8vICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgLy8gICAgIGNvbG9yOiAjNzE3MTcxO1xyXG4gIC8vICAgICBmb250LWZhbWlseSA6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAvLyB9XHJcblxyXG4gIC5sZWN0dXJlU2VsZWN0IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NmY2ZjZjtcclxufVxyXG4gICJdfQ== */");

/***/ }),

/***/ 5246:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-test/add-test.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar> \n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\">  \n          <ion-buttons>\n            <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button> \n          </ion-buttons>\n        </ion-col> \n        <ion-col size=\"5\"> \n          <p class=\"ion-text-center heading\">Add Test</p> \n        </ion-col> \n        <ion-col size=\"4\"> \n          <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div> \n        </ion-col> \n      </ion-row>\n    </ion-grid> \n  </ion-toolbar> \n</ion-header> \n\n<ion-content>\n  <br>\n  <form class=\"assignment_form\"  >\n    <ion-row>\n      <ion-col  >\n        <select class='lectureSelect' value=\"{{olddata?.unit}}\" [(ngModel)]=\"postData.unit\"   name='unit'>\n          <option value='' selected disabled>Select</option>\n          <option *ngFor=\"let unit_single of units\"   value=\"{{unit_single.id}}\">{{unit_single.unitName}}</option>\n        </select>\n      </ion-col>\n    </ion-row>\n    <!--test Tittle-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Test Title</ion-label>\n        <ion-input name='title'  value=\"{{olddata?.title}}\"  [(ngModel)]=\"postData.title\" required placeholder=\"Please Enter Test Title\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Per Question Mark-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Per Question Mark</ion-label>\n        <ion-input name='per_q_mark' value=\"{{olddata?.per_q_mark}}\"  [(ngModel)]=\"postData.per_q_mark\" required placeholder=\"Please Enter Question Marks\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Discription-->\n    <ion-row>\n      <ion-col>\n        <ion-label position=\"stacked\">Description</ion-label>\n        <ion-textarea name='description' value=\"{{olddata?.description}}\"  [(ngModel)]=\"postData.description\" name='description'  class=\"text_area\" placeholder=\"Please Enter Test Description\"></ion-textarea>\n      </ion-col>\n    </ion-row>\n    <!--Enable Show Answer-->\n    <div class=\"checkbox\">\n      <ion-checkbox name='show_ans' value=\"{{olddata?.show_ans}}\"  [(ngModel)]=\"postData.show_ans\" name='show_ans' ></ion-checkbox>\n      <ion-label> Enable Show Answer</ion-label>\n    </div>\n    <!--btns-->\n    <div class=\"btns ion-text-center\">\n      <button id=\"add\" (click)=\"createTest()\" >Add</button>\n      <!-- <button id=\"reset\">Reset</button> --> \n    </div>\n  </form>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_add-test_add-test_module_ts.js.map