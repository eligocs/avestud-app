(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_addlecture_addlecture_module_ts"],{

/***/ 7650:
/*!*********************************************************!*\
  !*** ./src/app/addlecture/addlecture-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddlecturePageRoutingModule": () => (/* binding */ AddlecturePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _addlecture_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addlecture.page */ 9850);




const routes = [
    {
        path: '',
        component: _addlecture_page__WEBPACK_IMPORTED_MODULE_0__.AddlecturePage
    }
];
let AddlecturePageRoutingModule = class AddlecturePageRoutingModule {
};
AddlecturePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddlecturePageRoutingModule);



/***/ }),

/***/ 7751:
/*!*************************************************!*\
  !*** ./src/app/addlecture/addlecture.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddlecturePageModule": () => (/* binding */ AddlecturePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _addlecture_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addlecture-routing.module */ 7650);
/* harmony import */ var _addlecture_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addlecture.page */ 9850);







let AddlecturePageModule = class AddlecturePageModule {
};
AddlecturePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _addlecture_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddlecturePageRoutingModule
        ],
        declarations: [_addlecture_page__WEBPACK_IMPORTED_MODULE_1__.AddlecturePage]
    })
], AddlecturePageModule);



/***/ }),

/***/ 9850:
/*!***********************************************!*\
  !*** ./src/app/addlecture/addlecture.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddlecturePage": () => (/* binding */ AddlecturePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_addlecture_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./addlecture.page.html */ 3037);
/* harmony import */ var _addlecture_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addlecture.page.scss */ 5348);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ 1704);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/toast.service */ 4465);













let AddlecturePage = class AddlecturePage {
    constructor(router, authService, storageService, homeService, route, toastService) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
        this.postData = {
            unit: '',
            number: '',
            lecturename: '',
            date: '',
            old_id: '',
        };
        this.notes = null;
        this.video = null;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.lectureid = params['lectureid'];
                if (this.iacs && this.subject) {
                    this.previousUrl = 'lectures?iacs=' + this.iacs + '&subject=' + this.subject;
                }
                if (this.lectureid) {
                    this.getOlddata(this.lectureid);
                }
                else {
                    this.postData = {
                        unit: '',
                        number: '',
                        lecturename: '',
                        date: '',
                        old_id: '',
                    };
                }
            });
            if (this.iacs) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                var classid = this.iacs;
                var classroom = yield this.homeService.getClassunits(classid, token).subscribe((res) => {
                    if (res) {
                        this.units = res.data;
                    }
                });
            }
        });
    }
    getOlddata(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            if (id) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                var lectureid = id;
                var classroom = yield this.homeService.getLecture(lectureid, token).subscribe((res) => {
                    if (res) {
                        this.olddata = res.data;
                        this.postData.unit = res.data.unit_id ? res.data.unit_id : '';
                    }
                });
            }
        });
    }
    onChange(event) {
        this.notes = event.target.files[0];
    }
    onChangeVideo(event) {
        this.video = event.target.files[0];
    }
    createLecture() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                unit: this.postData.unit,
                number: this.postData.number,
                lecturename: this.postData.lecturename,
                old_id: this.lectureid,
                date: this.postData.date,
                notes: this.notes,
                video: this.video,
                i_assigned_class_subject_id: this.iacs
            };
            if (newData) {
                var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                var classid = this.iacs;
                yield this.homeService.createLecture(newData, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.toastService.presentToast(res.msg);
                        let navigationExtras = {
                            queryParams: { 'iacs': this.iacs },
                            fragment: 'anchor'
                        };
                        this.router.navigate(['lectures'], navigationExtras);
                    }
                    else {
                        this.toastService.presentToast('Fail to add lecture!!!');
                    }
                });
            }
        });
    }
    ngAfterViewInit() {
        jquery__WEBPACK_IMPORTED_MODULE_6__(document).ready(function () {
        });
    }
};
AddlecturePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_9__.ToastService }
];
AddlecturePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-addlecture',
        template: _raw_loader_addlecture_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_addlecture_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddlecturePage);



/***/ }),

/***/ 5348:
/*!*************************************************!*\
  !*** ./src/app/addlecture/addlecture.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".add_lecture_form {\n  padding: 10px 20px;\n}\n\n.form_tittle {\n  font-size: 18px;\n  color: #644699;\n  margin-left: 20px;\n  font-weight: 400;\n  margin-top: 8px;\n}\n\nion-select {\n  height: 45px;\n  border: 0.5px solid #dcd4d4;\n  color: #292727;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.add_lecture_form ion-label {\n  color: #363636;\n  font-size: 16px;\n  font-weight: 400 !important;\n}\n\n.add_lecture_form ion-input {\n  height: 45px;\n  border: 0.5px solid #e0d9d9;\n  color: #4e4c4c;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.add_lecture_form ion-datetime {\n  height: 45px;\n  border: 0.5px solid #dcd9d9;\n  color: #989393;\n  border-radius: 8px;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 400;\n}\n\n.calender {\n  position: relative;\n}\n\n.calender_icon {\n  position: absolute;\n  top: 50%;\n  right: 5%;\n}\n\n.drag_drop {\n  border: 1px solid #d9d2d2;\n  height: 102px;\n  width: 100%;\n  border-radius: 11px;\n  background: url('pdf_img.svg');\n  background-repeat: no-repeat;\n  background-position-x: center;\n  background-position-y: center;\n  margin-top: 5px;\n}\n\n::-webkit-file-upload-button {\n  display: none;\n}\n\n.mg_top {\n  margin-top: 12px;\n}\n\n.lectureSelect {\n  width: 100%;\n  height: 44px;\n  border-radius: 4px;\n  border: 1px solid #cfcfcf;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZGxlY3R1cmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksa0JBQUE7QUFESjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFISjs7QUFRRTtFQUNFLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0JBQUE7QUFMSjs7QUFRRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsMkJBQUE7QUFMSjs7QUFRRTtFQUNFLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0JBQUE7QUFMSjs7QUFTRTtFQUNFLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZ0JBQUE7QUFOSjs7QUFTRTtFQUNFLGtCQUFBO0FBTko7O0FBU0U7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0FBTko7O0FBV0U7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSw2QkFBQTtFQUNBLGVBQUE7QUFSSjs7QUFXRTtFQUNFLGFBQUE7QUFSSjs7QUFXRTtFQUNFLGdCQUFBO0FBUko7O0FBcUJBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FBbEJKIiwiZmlsZSI6ImFkZGxlY3R1cmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gYWRkX2xlY3R1cmVfZm9ybVxyXG5cclxuLmFkZF9sZWN0dXJlX2Zvcm0ge1xyXG4gICAgcGFkZGluZzogMTBweCAyMHB4O1xyXG4gIH1cclxuICBcclxuICAvLyBmb3JtX3RpdHRsZVxyXG4gIFxyXG4gIC5mb3JtX3RpdHRsZSB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBjb2xvcjogIzY0NDY5OTtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIG1hcmdpbi10b3A6IDhweDtcclxuICB9XHJcbiAgXHJcbiAgLy8gaW9uLWxhYmVsIGFuZCBpb24taW5wdXRcclxuICBcclxuICBpb24tc2VsZWN0IHtcclxuICAgIGhlaWdodDogNDVweDtcclxuICAgIGJvcmRlcjogMC41cHggc29saWQgI2RjZDRkNDtcclxuICAgIGNvbG9yOiAjMjkyNzI3O1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB9XHJcbiAgXHJcbiAgLmFkZF9sZWN0dXJlX2Zvcm0gaW9uLWxhYmVsIHtcclxuICAgIGNvbG9yOiAjMzYzNjM2O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAuYWRkX2xlY3R1cmVfZm9ybSBpb24taW5wdXQge1xyXG4gICAgaGVpZ2h0OiA0NXB4O1xyXG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjZTBkOWQ5O1xyXG4gICAgY29sb3I6ICM0ZTRjNGM7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJQb3BwaW5zXCIsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gIH1cclxuICBcclxuICAvLyBDaG9vc2UgZGF0ZSBpbnB1dFxyXG4gIC5hZGRfbGVjdHVyZV9mb3JtIGlvbi1kYXRldGltZSB7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkICNkY2Q5ZDk7XHJcbiAgICBjb2xvcjogIzk4OTM5MztcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5jYWxlbmRlciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgfVxyXG4gIFxyXG4gIC5jYWxlbmRlcl9pY29uIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgcmlnaHQ6IDUlO1xyXG4gIH1cclxuICBcclxuICAvLyBmaWxlIHVwbG9hZGVyIC8gZHJhZyBhbmQgZHJvcFxyXG4gIFxyXG4gIC5kcmFnX2Ryb3Age1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Q5ZDJkMjtcclxuICAgIGhlaWdodDogMTAycHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDExcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vYXNzZXRzL2ltYWdlcy9wZGZfaW1nLnN2Zyk7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbi14OiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uLXk6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICB9XHJcbiAgXHJcbiAgOjotd2Via2l0LWZpbGUtdXBsb2FkLWJ1dHRvbiB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuICBcclxuICAubWdfdG9wIHtcclxuICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIC5mb3JtX2J0biBidXR0b24ge1xyXG4gIC8vICAgaGVpZ2h0OiAzNnB4O1xyXG4gIC8vICAgd2lkdGg6IDcxcHg7XHJcbiAgLy8gICBmb250LXNpemU6IDEycHg7XHJcbiAgLy8gICBjb2xvcjogd2hpdGU7XHJcbiAgLy8gICBmb250LXdlaWdodDogNDAwO1xyXG4gIC8vICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIC8vICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAvLyB9XHJcblxyXG4ubGVjdHVyZVNlbGVjdCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjZmNmY2Y7XHJcbn1cclxuICAiXX0= */");

/***/ }),

/***/ 3037:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/addlecture/addlecture.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--Ion-Header Start-->\n<ion-header>\n  <ion-toolbar>\n     <ion-grid>\n        <ion-row>\n           <ion-col size=\"3\">\n              <ion-buttons>\n                <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button>\n              </ion-buttons>\n           </ion-col>\n           <ion-col size=\"5\">\n              <p class=\"ion-text-center heading\">Add Lecture</p>\n           </ion-col>\n           <ion-col size=\"4\">\n              <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n           </ion-col>\n        </ion-row>\n     </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<!--Ion-Header Ends-->\n<!--ion-content Start-->\n<ion-content>\n  <h1 class=\"form_tittle\">Add Lecture</h1>\n  <!--add_lecture_form Start-->\n  <form class=\"add_lecture_form\">\n    <!--Select Unit*-->\n    <ion-row>\n      <ion-col  >\n        <label>Select Unit*</label>\n        <select class='lectureSelect' value=\"{{olddata?.unit_id}}\" [(ngModel)]=\"postData.unit\" name='unit'>\n          <option value='' selected disabled>Select</option>\n          <option *ngFor=\"let unit of units\" value=\"{{unit.id}}\">{{unit.name}}</option>\n        </select> \n      </ion-col>\n    </ion-row>\n    <!--Lecture Number*--> \n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Lecture Number*</ion-label>\n        <ion-input  [(ngModel)]=\"postData.number\" value='{{olddata?.lecture_number}}' autocomplete=\"off\" name=\"number\"  required placeholder=\"Lecture Number\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Lecture Name*-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Lecture Name*</ion-label>\n        <ion-input required placeholder=\"Lecture Name\" value='{{olddata?.lecture_name}}'  [(ngModel)]=\"postData.lecturename\" autocomplete=\"off\" name=\"lecturename\" type=\"text\"></ion-input>\n      </ion-col>\n    </ion-row>\n    <!--Lecture Date*-->\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\">\n        <ion-label position=\"stacked\">Lecture Date*</ion-label>\n        <ion-datetime displayFormat=\"DD MM YYYY\" value='{{olddata?.lecture_date}}'  [(ngModel)]=\"postData.date\" autocomplete=\"off\" name=\"date\" placeholder=\"Select Date\"></ion-datetime>\n        <img class=\"calender_icon\" src=\"../../assets/images/calender.svg\">\n      </ion-col>\n    </ion-row>\n    <!--file upload / drag and-->\n    <ion-row class=\"mg_top\">\n      <ion-col class=\"pdf_img\">\n        <ion-label position=\"stacked\">Upload Notes*</ion-label>\n        <input class=\"drag_drop\"  name=\"notes\" (change)=\"onChange($event)\"  type=\"file\" id=\"notes\"  /><br />\n        <!-- <img src=\"../../assets/imgs/pdf_img.svg\" class=\"pdf_img\"> -->\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"mg_top\">\n      <ion-col class=\"pdf_img\">\n        <ion-label position=\"stacked\">Upload Video (You can add later)</ion-label><br/>\n        <small>Only lecture with video will show to students</small>\n        <input class=\"drag_drop\"  name=\"video\" (change)=\"onChangeVideo($event)\"  type=\"file\" id=\"video\"  /><br />\n        <!-- <img src=\"../../assets/imgs/pdf_img.svg\" class=\"pdf_img\"> -->\n      </ion-col>\n    </ion-row>\n    <ion-button expand=\"block\" share=\"round\" color=\"success\" class=\"btn_bottom_mrgn\"   (click)=\"createLecture()\">Save</ion-button>\n  </form>\n   <!--add_lecture_form End-->\n</ion-content>\n<!--ion-content End-->\n<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>Add lecture</ion-title>\n    <a slot='end'  [routerLink]=\"['/lectures']\" [queryParams]=\"{iacs:this.iacs}\"><ion-button  >Back</ion-button> </a>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form>\n    <ion-list>\n    <ion-item>\n    <ion-label position=\"stacked\">Select unit</ion-label>\n      <ion-select  [(ngModel)]=\"postData.unit\" name='unit'  >\n        <ion-select-option *ngFor=\"let unit of units\" [value]=\"unit.id\">{{unit.name}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Lectuer Number</ion-label>\n      <ion-input [(ngModel)]=\"postData.number\" autocomplete=\"off\" name=\"number\" type=\"text\"></ion-input>\n    </ion-item>\n    \n    <ion-item>\n    <ion-label position=\"stacked\">Lecture Name</ion-label>\n    <ion-input [(ngModel)]=\"postData.lecturename\" autocomplete=\"off\" name=\"lecturename\" type=\"text\"></ion-input>\n    </ion-item> \n    <ion-item>\n    <ion-label position=\"stacked\">Lecture Date</ion-label>\n    <ion-input [(ngModel)]=\"postData.date\" autocomplete=\"off\" name=\"date\" type=\"date\"></ion-input>\n    </ion-item> \n    <ion-item>\n    <ion-label position=\"stacked\">Notes</ion-label>\n    <ion-input  name=\"notes\" (change)=\"onChange($event)\" type=\"file\"></ion-input>\n    </ion-item> \n    <ion-item>\n    <ion-label position=\"stacked\">Video</ion-label>\n    <ion-input  (change)=\"onChangeVideo($event)\"  name=\"video\" type=\"file\"></ion-input> \n    </ion-item> \n    </ion-list>\n    <ion-button expand=\"block\" share=\"round\" color=\"success\" (click)=\"createLecture()\">Save</ion-button>\n    </form>\n</ion-content>\n -->\n ");

/***/ })

}]);
//# sourceMappingURL=src_app_addlecture_addlecture_module_ts.js.map