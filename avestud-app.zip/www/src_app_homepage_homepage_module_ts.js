(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_homepage_homepage_module_ts"],{

/***/ 1829:
/*!*****************************************************!*\
  !*** ./src/app/homepage/homepage-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomepagePageRoutingModule": () => (/* binding */ HomepagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _homepage_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./homepage.page */ 3446);




const routes = [
    {
        path: '',
        component: _homepage_page__WEBPACK_IMPORTED_MODULE_0__.HomepagePage
    }
];
let HomepagePageRoutingModule = class HomepagePageRoutingModule {
};
HomepagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomepagePageRoutingModule);



/***/ }),

/***/ 2173:
/*!*********************************************!*\
  !*** ./src/app/homepage/homepage.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomepagePageModule": () => (/* binding */ HomepagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _homepage_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./homepage-routing.module */ 1829);
/* harmony import */ var _homepage_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./homepage.page */ 3446);







let HomepagePageModule = class HomepagePageModule {
};
HomepagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _homepage_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomepagePageRoutingModule
        ],
        declarations: [_homepage_page__WEBPACK_IMPORTED_MODULE_1__.HomepagePage]
    })
], HomepagePageModule);



/***/ }),

/***/ 3446:
/*!*******************************************!*\
  !*** ./src/app/homepage/homepage.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomepagePage": () => (/* binding */ HomepagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_homepage_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./homepage.page.html */ 2691);
/* harmony import */ var _homepage_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./homepage.page.scss */ 1615);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../previous-route.service */ 8735);











let HomepagePage = class HomepagePage {
    constructor(previousRouteService, router, authService, storageService, homeService) {
        this.previousRouteService = previousRouteService;
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject([]);
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            var userdetails = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.userdetails);
            var mainThis = this;
            if (!token) {
                this.router.navigate(['/']);
            }
            else {
                if (userdetails.role == 'student') {
                    mainThis.router.navigate(['/studenthome']);
                }
                else if (userdetails.role == 'institute') {
                    mainThis.router.navigate(['/homepage']);
                }
                var classroom = yield this.homeService.getClassRoom(token).subscribe((res) => {
                    if (res.data) {
                        var result = res.data;
                        var allClasses = [];
                        result.forEach((entry, i) => {
                            entry.subjects.forEach((subj) => {
                                subj.color_code = colorLight(i);
                            });
                            allClasses.push(entry);
                        });
                        this.classes = allClasses;
                        this.inst_name = allClasses[0].institute.name;
                    }
                    else {
                        mainThis.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH).then(res => {
                            mainThis.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.userdetails);
                            mainThis.router.navigate(['/']);
                        });
                    }
                });
            }
            function colorLight(i) {
                /*  var messages = ["#F9B637", "#1582D2", "#96E601",'#FE8448'];
                 var randomColor = messages[Math.floor(Math.random() * messages.length)]; */
                var randomColor;
                if (i == 0) {
                    randomColor = 'orange_gradient_btn';
                }
                else if (i % 5 == 0) {
                    randomColor = 'pink_btn';
                }
                if (i == 1) {
                    randomColor = 'blue_gradient_btn';
                }
                if (i % 2 == 0) {
                    randomColor = 'green_gradient_btn';
                }
                if (i % 3 == 0) {
                    randomColor = 'yellow_gradient_btn';
                }
                return randomColor;
            }
            /*   function colortop() {
                var messages = ["rgb(140 210 10)", "rgb(245 165 17)", "#0FAFDF",'rgb(173 114 210)'];
                var randomColor = messages[Math.floor(Math.random() * messages.length)];
                return randomColor;
              }   */
        });
    }
    logoutAction() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.showloader = true;
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.Role);
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.userdetails);
            this.authService.logout();
        });
    }
};
HomepagePage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_6__.PreviousRouteService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService }
];
HomepagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-homepage',
        template: _raw_loader_homepage_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_homepage_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomepagePage);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 1615:
/*!*********************************************!*\
  !*** ./src/app/homepage/homepage.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  font-family: \"poppins\" sans-serif;\n}\n\n.color_violet {\n  color: #644699;\n}\n\n.avatar_icon {\n  background: url('avatar.svg');\n  background-repeat: no-repeat;\n  height: 30px;\n  width: 30px;\n  float: right;\n}\n\n.wel {\n  color: #644699;\n  font-size: 18px;\n  margin-left: 20px;\n  font-weight: 500;\n}\n\n.institute_name {\n  color: #E03E91;\n  font-size: 18px;\n  font-weight: bold;\n  margin-left: 20px;\n}\n\n.cards_section ion-card {\n  border-radius: 6px;\n  width: 98px;\n  height: 71px;\n}\n\n.card_1 p {\n  font-size: 16px;\n  font-weight: bold;\n  color: black;\n  border-radius: 10px;\n}\n\n.card_2 p {\n  font-size: 16px;\n  color: black;\n}\n\n.card_3 p {\n  font-size: 16px;\n  color: black;\n}\n\n.card_4 {\n  width: 90%;\n  box-shadow: 0 1px lightgray;\n  background-color: #F3FCE3;\n  border-radius: 10px;\n  line-height: 0%;\n  padding: 13px 4px;\n  margin-left: 18px;\n}\n\n.card_tittle {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 0%;\n  margin-top: 12px;\n}\n\n.class_5 {\n  font-size: 18px;\n  font-weight: 500;\n}\n\n.fee {\n  font-size: 22px;\n  color: black;\n  font-weight: 500;\n}\n\n.sub_btns {\n  display: flex;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  flex-wrap: wrap;\n  margin-top: 0%;\n  justify-content: space-between;\n}\n\na {\n  text-decoration: none;\n  text-align: center;\n}\n\n.green_gradient_btn {\n  background-image: linear-gradient(to bottom, #94E401, #6CB50D);\n}\n\n.yellow_gradient_btn {\n  background-image: linear-gradient(to bottom, #F9912D, #FAB938);\n}\n\n.blue_gradient_btn {\n  background-image: linear-gradient(to bottom, #1582D2, #0FB0E0);\n}\n\n.orange_gradient_btn {\n  background-image: linear-gradient(to bottom, #FE8448, #FE6761);\n}\n\n.pink_btn {\n  background-image: linear-gradient(to bottom, #e990ff, #d961fe);\n}\n\n.session_period p {\n  color: #727272;\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.session_period span {\n  color: #000000;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.btn_enroll {\n  width: 90px;\n  height: 20px;\n  font-size: 12px;\n  color: white;\n  font-weight: 500;\n  border-radius: 4px;\n  padding: 2px 10px;\n  background-color: #644699;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWVwYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGlDQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0FBQUo7O0FBR0E7RUFDSSw2QkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQUo7O0FBS0E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFGSjs7QUFLQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUZKOztBQU1BO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUhKOztBQU9BO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBSko7O0FBU0E7RUFDSSxlQUFBO0VBQ0EsWUFBQTtBQU5KOztBQVNBO0VBQ0ksZUFBQTtFQUNBLFlBQUE7QUFOSjs7QUFXQTtFQUNJLFVBQUE7RUFDQSwyQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQVJKOztBQVlBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQVRKOztBQWFBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FBVko7O0FBYUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBVko7O0FBYUE7RUFDSSxhQUFBO0VBQ0EsMEJBQUE7RUFBQSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtBQVZKOztBQVlDO0VBQ0cscUJBQUE7RUFDQSxrQkFBQTtBQVRKOztBQTZEQTtFQUNJLDhEQUFBO0FBMURKOztBQTZEQTtFQUNJLDhEQUFBO0FBMURKOztBQTZEQTtFQUNJLDhEQUFBO0FBMURKOztBQTZEQTtFQUNJLDhEQUFBO0FBMURKOztBQTREQTtFQUNJLDhEQUFBO0FBekRKOztBQThEQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUEzREo7O0FBOERBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQTNESjs7QUE4REE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7QUEzREoiLCJmaWxlIjoiaG9tZXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdwb3BwaW5zJyBzYW5zLXNlcmlmO1xyXG59XHJcblxyXG4uY29sb3JfdmlvbGV0e1xyXG4gICAgY29sb3I6ICM2NDQ2OTk7XHJcbn1cclxuXHJcbi5hdmF0YXJfaWNvbntcclxuICAgIGJhY2tncm91bmQ6IHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL2F2YXRhci5zdmcpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG5cclxuXHJcbi53ZWx7XHJcbiAgICBjb2xvcjogIzY0NDY5OTtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLmluc3RpdHV0ZV9uYW1le1xyXG4gICAgY29sb3I6ICNFMDNFOTE7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG5cclxufVxyXG5cclxuLmNhcmRzX3NlY3Rpb24gaW9uLWNhcmR7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICB3aWR0aDogOThweDtcclxuICAgIGhlaWdodDogNzFweDtcclxufVxyXG5cclxuXHJcbi5jYXJkXzEgcHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuXHJcblxyXG59XHJcblxyXG4uY2FyZF8yIHB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbi5jYXJkXzMgcHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuXHJcblxyXG4uY2FyZF80e1xyXG4gICAgd2lkdGg6IDkwJTsgXHJcbiAgICBib3gtc2hhZG93OiAwIDFweCBsaWdodGdyYXk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjNGQ0UzO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAwJTtcclxuICAgIHBhZGRpbmc6IDEzcHggNHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE4cHg7XHJcbn1cclxuXHJcblxyXG4uY2FyZF90aXR0bGV7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG5cclxufVxyXG5cclxuLmNsYXNzXzV7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uZmVle1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLnN1Yl9idG5ze1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuICAgIGZsZXgtd3JhcDp3cmFwO1xyXG4gICAgbWFyZ2luLXRvcDogMCU7IFxyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG59XHJcbiBhe1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4vLyAuYnRuX21hdGh7XHJcbi8vICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjZjdjMTVkLCAjZjg5YTJmKTtcclxuLy8gICAgIHdpZHRoOiA3OHB4O1xyXG4vLyAgICAgaGVpZ2h0OiAyMXB4O1xyXG4vLyAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4vLyAgICAgY29sb3I6IHdoaXRlO1xyXG4vLyAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbi8vICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbi8vICAgICBtYXJnaW4tcmlnaHQ6IDVweDsgXHJcbi8vIH1cclxuXHJcbi8vIC5idG5fZW5neyAgXHJcbi8vICAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbi8vIH1cclxuXHJcbi8vIC5saW5rX3N1YmplY3R7XHJcbi8vICAgICB3aWR0aDogNzVweDtcclxuLy8gICAgIGNvbG9yOiB3aGl0ZTtcclxuLy8gICAgIGhlaWdodDogMjFweDtcclxuLy8gICAgIGZvbnQtc2l6ZTogMTNweDsgIFxyXG4vLyAgICAgYm9yZGVyLXJhZGl1czogNXB4OyAgXHJcbi8vICAgICBwYWRkaW5nOiA2cHg7XHJcbi8vICAgICBtYXJnaW4tcmlnaHQ6IDRweFxyXG4vLyB9XHJcblxyXG4vLyAuYnRuX3NjaXtcclxuLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM5NEU0MDEsICM2Q0I1MEQpO1xyXG4vLyAgICAgd2lkdGg6IDc1cHg7XHJcbi8vICAgICBoZWlnaHQ6IDIxcHg7XHJcbi8vICAgICBmb250LXNpemU6IDEzcHg7XHJcbi8vICAgICBjb2xvcjogd2hpdGU7XHJcbi8vICAgICBmb250LXdlaWdodDogYm9sZDtcclxuLy8gICAgIGJvcmRlci1yYWRpdXM6IDVweDsgXHJcbi8vICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuLy8gfVxyXG5cclxuLy8gLmJ0bl9oaW5kaXtcclxuLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNGRTgzNDgsICNGRTY3NjApO1xyXG4vLyAgICAgd2lkdGg6IDcycHg7XHJcbi8vICAgICBoZWlnaHQ6IDIxcHg7XHJcbi8vICAgICBmb250LXNpemU6IDEzcHg7XHJcbi8vICAgICBjb2xvcjogd2hpdGU7XHJcbi8vICAgICBmb250LXdlaWdodDogYm9sZDtcclxuLy8gICAgIGJvcmRlci1yYWRpdXM6IDVweDsgXHJcbi8vICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuLy8gfVxyXG5cclxuXHJcblxyXG4uZ3JlZW5fZ3JhZGllbnRfYnRue1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzk0RTQwMSwgIzZDQjUwRCk7XHJcbn1cclxuXHJcbi55ZWxsb3dfZ3JhZGllbnRfYnRue1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI0Y5OTEyRCwgI0ZBQjkzOCk7XHJcbn1cclxuXHJcbi5ibHVlX2dyYWRpZW50X2J0bntcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMxNTgyRDIsICMwRkIwRTApO1xyXG59XHJcblxyXG4ub3JhbmdlX2dyYWRpZW50X2J0bntcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNGRTg0NDgsICNGRTY3NjEpO1xyXG59XHJcbi5waW5rX2J0bntcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNlOTkwZmYsICNkOTYxZmUpO1xyXG59XHJcblxyXG5cclxuXHJcbi5zZXNzaW9uX3BlcmlvZCBwe1xyXG4gICAgY29sb3I6ICM3MjcyNzI7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uc2Vzc2lvbl9wZXJpb2Qgc3BhbntcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLmJ0bl9lbnJvbGx7XHJcbiAgICB3aWR0aDogOTBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiB3aGl0ZTsgICBcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBwYWRkaW5nOiAycHggMTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM2NDQ2OTk7XHJcbn0iXX0= */");

/***/ }),

/***/ 2691:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/homepage.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" \n  <ion-app> \n    \n  <ion-header>\n    <ion-toolbar>\n  \n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"3\">\n  \n            <ion-buttons>\n               <ion-icon class='logout_btn color_violet' (click)=\"logoutAction()\" name=\"log-out-outline\"></ion-icon>\n            </ion-buttons>\n  \n          </ion-col>\n          \n          <ion-col size=\"5\">\n  \n            <p class=\"ion-text-center heading\">My Classroom</p>\n  \n          </ion-col>\n  \n          <ion-col size=\"4\">\n  \n            <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n  \n          </ion-col>\n  \n        </ion-row>\n      </ion-grid>\n  \n    </ion-toolbar>\n  \n  </ion-header>\n    <!--Ion-Header Ends-->\n    \n  \n  \n  <!--ion-Content Starts-->\n  \n    <ion-content>\n      <div class=\"comman_page_padding\">\n      <h1 class=\"wel\">Welcome</h1>\n      <span class=\"institute_name\">{{inst_name ? inst_name: ''}}</span>\n      <!-- <ion-row class=\"row_unit\">\n          <ion-col id=\"theme_shadow\">\n              <p> All</p>\n          </ion-col>\n          <ion-col>\n              <p>Unit 1</p>\n          </ion-col>\n          <ion-col>\n              <p>Unit 2</p>\n          </ion-col>\n          <ion-col>\n              <p>Unit 3</p>\n          </ion-col> \n      </ion-row> -->\n      <!-- <ion-row class=\"cards_section\">\n        <ion-col size=\"4\">\n          <ion-card class=\"card_1\">\n          <p class=\"ion-text-center\">5 Th <br>Standared</p>\n            \n          </ion-card>\n            \n        </ion-col>\n  \n        <ion-col size=\"4\">\n          <ion-card class=\"card_2\">\n          <p class=\"ion-text-center\">4 Th <br>Standared</p>\n            \n          </ion-card>\n            \n        </ion-col>\n  \n        <ion-col size=\"4\">\n          <ion-card class=\"card_3\">\n          <p class=\"ion-text-center\">6 Th <br>Standared</p>\n            \n          </ion-card>\n            \n        </ion-col>\n  \n      </ion-row> -->\n  \n     \n        <div   *ngFor=\"let data of classes; let i = index\">\n          <ion-card  [ngStyle]=\"{ background: '#F3FCE3' }\"  no-lines class=\"common_card\">\n            <ion-card-header class=\"card_tittle\">\n              <span class=\"color_violet class_5\">{{data.class.name ?? ''}}   <small>Board : {{data.class.board ?? ''}}</small></span>\n              <span class=\"fee\">₹ {{data.class.price}}</span>\n            </ion-card-header> \n            <ion-card-content>\n                <ion-row>\n                {{data.language?.name  ? '- '+data.language.name : ''}}\n                </ion-row>\n              <ion-row>\n                <ion-col class=\"sub_btns\" >   \n                  <div class=\" btn_hindi\"  *ngFor=\"let subj of data.subjects; let in = index\">  \n                    <a class='link_subject '  [routerLink]=\"['/subject-detail']\" [queryParams]=\"{iacs:subj.id,subject:subj.subject.id}\" ><button class=\"common_anc_btn common_btn_shadow {{subj.color_code ?? 'green_gradient_btn'}}\">\n                      {{subj.subject.name ?? ''}}\n                    </button>  </a> \n                  </div>        \n                </ion-col>\n              </ion-row> \n              <ion-row class=\"session_period\">\n                <ion-col>\n                  <p>Start</p>\n                  <span>{{data.class.start_date | date: 'dd/MM/yyyy' }}</span>\n                </ion-col>  \n                <ion-col>\n                  <p>End</p>\n                  <span>{{data.class.end_date | date: 'dd/MM/yyyy' }}</span>\n                </ion-col>\n              </ion-row>\n              <a class=\"btn_enroll common_anc_btn common_btn_shadow\" [routerLink]=\"['/enrollments']\" [queryParams]=\"{iacs:data.class.institute_id,subject:data.class.id}\">{{data.students ?? ''}} Enrolled</a> \n              </ion-card-content>\n            </ion-card>\n          </div>\n         \n      </div>\n      \n    </ion-content>\n  \n  </ion-app>\n  ");

/***/ })

}]);
//# sourceMappingURL=src_app_homepage_homepage_module_ts.js.map