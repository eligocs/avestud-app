(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_lectures_lectures_module_ts"],{

/***/ 5537:
/*!*****************************************************!*\
  !*** ./src/app/lectures/lectures-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LecturesPageRoutingModule": () => (/* binding */ LecturesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _lectures_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lectures.page */ 6919);




const routes = [
    {
        path: '',
        component: _lectures_page__WEBPACK_IMPORTED_MODULE_0__.LecturesPage
    }
];
let LecturesPageRoutingModule = class LecturesPageRoutingModule {
};
LecturesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LecturesPageRoutingModule);



/***/ }),

/***/ 7789:
/*!*********************************************!*\
  !*** ./src/app/lectures/lectures.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LecturesPageModule": () => (/* binding */ LecturesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _lectures_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lectures-routing.module */ 5537);
/* harmony import */ var _lectures_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lectures.page */ 6919);







let LecturesPageModule = class LecturesPageModule {
};
LecturesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _lectures_routing_module__WEBPACK_IMPORTED_MODULE_0__.LecturesPageRoutingModule
        ],
        declarations: [_lectures_page__WEBPACK_IMPORTED_MODULE_1__.LecturesPage]
    })
], LecturesPageModule);



/***/ }),

/***/ 6919:
/*!*******************************************!*\
  !*** ./src/app/lectures/lectures.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LecturesPage": () => (/* binding */ LecturesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_lectures_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./lectures.page.html */ 5939);
/* harmony import */ var _lectures_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lectures.page.scss */ 1238);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../previous-route.service */ 8735);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/toast.service */ 4465);











let LecturesPage = class LecturesPage {
    constructor(previousRouteService, storageService, homeService, route, alertController, toastService) {
        this.previousRouteService = previousRouteService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.alertController = alertController;
        this.toastService = toastService;
        this.href = "";
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.getallectures(this.iacs, token);
                if (this.iacs && this.subject) {
                    this.previousUrl = 'subject-detail?iacs=' + this.iacs + '&subject=' + this.subject;
                }
            });
        });
    }
    getallectures(iacs, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (iacs && token) {
                yield this.homeService.openLecture(iacs, token).subscribe((res) => {
                    if (res.data.length > 0) {
                        this.lectures = res.data ? res.data : '';
                    }
                    else {
                        this.lectures = [];
                        this.nolectures = true;
                    }
                });
            }
        });
    }
    toggleShow(unit) {
        if (unit) {
            this.showUnitFor = unit;
        }
        else {
            this.showUnitFor = '';
        }
    }
    presentAlert(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            var toast = this.toastService;
            var serv_home = this.homeService;
            var mainthis = this;
            function delete_l(id) {
                serv_home.delLecture(id, token).subscribe((res) => {
                    mainthis.getallectures(mainthis.iacs, token);
                    toast.presentToast(res.msg);
                });
            }
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Confirm!',
                message: 'Are you sure you want to delete this lecture!!!',
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                        }
                    }, {
                        text: 'Yes',
                        handler: function () {
                            delete_l(id);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
LecturesPage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_5__.PreviousRouteService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_3__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
LecturesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-lectures',
        template: _raw_loader_lectures_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_lectures_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LecturesPage);



/***/ }),

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 1238:
/*!*********************************************!*\
  !*** ./src/app/lectures/lectures.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".lectures {\n  padding: 0 12px;\n}\n\n.btn_theme button {\n  background-color: #644699;\n  color: white;\n  font-size: 12px;\n  font-weight: 400;\n  width: 71px;\n  height: 36px;\n  border-radius: 4px;\n  margin-top: 20px;\n}\n\n.row_unit {\n  height: 71px;\n  background-color: #f5f5f5;\n  margin-top: 16px;\n  border-radius: 6px;\n}\n\n.row_unit p {\n  font-size: 14px;\n  font-weight: 500;\n}\n\n#theme_shadow {\n  background: white;\n  height: 68px;\n  box-shadow: 0px 0 9px 1px #888888;\n  border-radius: 5px;\n  text-align: center;\n  margin-top: -2px;\n}\n\n.row_video {\n  border-radius: 8px;\n  box-shadow: 1px 4px 7px #c3c3c3;\n  margin-top: 15px;\n  max-height: 138px;\n  height: 100%;\n}\n\n.video_img img {\n  height: 111px;\n  width: 128px;\n}\n\n.col_text {\n  line-height: 8px;\n}\n\n.icons_set {\n  margin-top: 17px;\n  display: flex;\n  justify-content: space-around;\n}\n\n.date_f {\n  font-size: 12px;\n  color: #f9922d;\n  font-weight: 400;\n}\n\np.color_pink.comman.lineHe {\n  line-height: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxlY3R1cmVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUFDSjs7QUFFRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVFO0VBQ0UsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxpQ0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUdFO0VBQ0Usa0JBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0U7RUFDRSxhQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUdFO0VBQ0UsZ0JBQUE7QUFBSjs7QUFHRTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0U7RUFDRSxjQUFBO0FBQUoiLCJmaWxlIjoibGVjdHVyZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxlY3R1cmVzIHtcclxuICAgIHBhZGRpbmc6IDAgMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmJ0bl90aGVtZSBidXR0b24ge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzY0NDY5OTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICB3aWR0aDogNzFweDtcclxuICAgIGhlaWdodDogMzZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5yb3dfdW5pdCB7XHJcbiAgICBoZWlnaHQ6IDcxcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG4gICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICB9XHJcbiAgXHJcbiAgLnJvd191bml0IHAge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICB9XHJcbiAgXHJcbiAgI3RoZW1lX3NoYWRvdyB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGhlaWdodDogNjhweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwIDlweCAxcHggIzg4ODg4ODtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6LTJweDtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLnJvd192aWRlbyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBib3gtc2hhZG93OiAxcHggNHB4IDdweCAjYzNjM2MzO1xyXG4gICAgbWFyZ2luLXRvcDogMTVweDtcclxuICAgIG1heC1oZWlnaHQ6IDEzOHB4O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gIH1cclxuICBcclxuICAudmlkZW9faW1nIGltZyB7XHJcbiAgICBoZWlnaHQ6IDExMXB4O1xyXG4gICAgd2lkdGg6IDEyOHB4O1xyXG4gIH1cclxuICBcclxuICAuY29sX3RleHQge1xyXG4gICAgbGluZS1oZWlnaHQ6IDhweDtcclxuICB9XHJcbiAgXHJcbiAgLmljb25zX3NldCB7XHJcbiAgICBtYXJnaW4tdG9wOiAxN3B4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gIH1cclxuICBcclxuICAuZGF0ZV9mIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjZjk5MjJkO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB9XHJcblxyXG4gIHAuY29sb3JfcGluay5jb21tYW4ubGluZUhlIHtcclxuICAgIGxpbmUtaGVpZ2h0OiAxO1xyXG59XHJcbiAgIl19 */");

/***/ }),

/***/ 5939:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/lectures/lectures.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n    <ion-toolbar>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-buttons>\n                        <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button>\n                    </ion-buttons>\n                </ion-col>\n                <ion-col size=\"5\">\n                    <p class=\"ion-text-center heading\">Lectures</p>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <div class=\"avatar_icon\"></div>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"comman_page_padding \">\n    <div class=\"lectures \">\n        <ion-row>\n            <ion-col size=\"10\">\n                <h1 class=\"color_violet page_tittle\">Lectures</h1>\n            </ion-col>\n            <ion-col size=\"2\"> \n                <button [routerLink]=\"['/addlecture']\" [queryParams]=\"{iacs:iacs,subject:subject}\" class='bg_color btn comman_btn common_anc_btn common_btn_shadow'>Create</button> \n            </ion-col>\n        </ion-row>\n        \n       <ion-row class=\"row_unit\">\n            <ion-col (click)=\"toggleShow()\" id=\"{{!showUnitFor ? 'theme_shadow' :''}}\" >\n                <p > All</p>\n            </ion-col>\n            <ion-col *ngFor=\"let lect of lectures;\" id=\"{{showUnitFor == lect.unit ? 'theme_shadow' :''}}\">\n                <p (click)=\"toggleShow(lect.unit)\">{{lect.unit.length > 0 && lect.unit.length > 12 ? lect.unit.substring(0,12)+' ...' : 'Old' }}</p>\n            </ion-col> \n        </ion-row>\n\n    \n\n\n        <div *ngFor=\"let lect of lectures;let i=index;\"  >\n            <div *ngIf=\"showUnitFor == lect.unit || !showUnitFor\">\n                <p class='text-center'>{{lect?.unit | titlecase}}</p>\n                <ion-row class=\"row_video\" *ngFor=\"let single of lect.lectures;\"> \n                    <ion-col size=\"5\">\n                        <div class=\"video_img\">\n                            <a href='{{ single.lecture_video }}'><img src=\"../../assets/images/video_img2.png\" class=\"youtube_icon\"></a>\n                        </div>\n                    </ion-col>\n                    <ion-col size=\"7\">\n                        <div class=\"col_text\">\n                            <p class=\"comman_font color_violet\"></p>\n                            <p class=\"comman color_pink lineHe\">{{ single.lecture_name | titlecase }}</p>\n                            <p class=\"date_f\">{{ single.lecture_date | date: 'dd/MM/yyyy' }}</p>\n                        </div>\n                        <div class=\"icons_set\">\n                            <a href='{{ single.notes }}'><img src=\"../../assets/images/download_pdf.png\"></a>\n                            <a [routerLink]=\"['/addlecture']\" [queryParams]=\"{iacs:this.iacs,subject:subject,lectureid:single.id}\"><img src=\"../../assets/images/edit_icon.png\"></a>\n                            <a (click)=\"presentAlert(single.id)\"><img src=\"../../assets/images/delete_icon.png\"></a>\n                        </div>\n                    </ion-col>\n                </ion-row>\n            </div> \n        </div>\n    </div>\n    <ion-card *ngIf=\"nolectures == true\" class=\"card_4\" no-lines>\n        <ion-row>\n            <ion-col class='ion-text-center'>No Lectures Added Yet !!!\n            </ion-col>\n        </ion-row>\n    </ion-card>\n</div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_lectures_lectures_module_ts.js.map