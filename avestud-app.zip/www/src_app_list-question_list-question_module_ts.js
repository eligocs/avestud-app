(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_list-question_list-question_module_ts"],{

/***/ 2130:
/*!***************************************************************!*\
  !*** ./src/app/list-question/list-question-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListQuestionPageRoutingModule": () => (/* binding */ ListQuestionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _list_question_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-question.page */ 1129);




const routes = [
    {
        path: '',
        component: _list_question_page__WEBPACK_IMPORTED_MODULE_0__.ListQuestionPage
    }
];
let ListQuestionPageRoutingModule = class ListQuestionPageRoutingModule {
};
ListQuestionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ListQuestionPageRoutingModule);



/***/ }),

/***/ 8989:
/*!*******************************************************!*\
  !*** ./src/app/list-question/list-question.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListQuestionPageModule": () => (/* binding */ ListQuestionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _list_question_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-question-routing.module */ 2130);
/* harmony import */ var _list_question_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-question.page */ 1129);







let ListQuestionPageModule = class ListQuestionPageModule {
};
ListQuestionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _list_question_routing_module__WEBPACK_IMPORTED_MODULE_0__.ListQuestionPageRoutingModule
        ],
        declarations: [_list_question_page__WEBPACK_IMPORTED_MODULE_1__.ListQuestionPage]
    })
], ListQuestionPageModule);



/***/ }),

/***/ 1129:
/*!*****************************************************!*\
  !*** ./src/app/list-question/list-question.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListQuestionPage": () => (/* binding */ ListQuestionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_list_question_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./list-question.page.html */ 3075);
/* harmony import */ var _list_question_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-question.page.scss */ 6955);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! select2 */ 139);
/* harmony import */ var select2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(select2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var select2_dist_css_select2_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! select2/dist/css/select2.css */ 2919);











let ListQuestionPage = class ListQuestionPage {
    constructor(router, authService, storageService, homeService, route) {
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            this.iacs = params['iacs'];
            this.subject = params['subject'];
            this.assignment_id = params['assignment_id'];
            this.pagetype = params['type'];
            if (this.pagetype == 'assignment') {
                this.previousUrl = 'assignments?iacs=' + this.iacs + '&subject=' + this.subject;
            }
            else {
                this.previousUrl = 'test?iacs=' + this.iacs + '&subject=' + this.subject;
            }
            if (this.assignment_id && this.iacs) {
                this.getQuestions(this.iacs, this.assignment_id);
            }
        });
    }
    getQuestions(id, assignment) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            var data = {
                iacs: this.iacs,
                assignment_id: this.assignment_id,
            };
            yield this.homeService.getQuestions(data, token).subscribe((res) => {
                if (res.status == 200) {
                    this.questionsList = res.questions ? res.questions : '';
                    this.topic = res.topic ? res.topic : '';
                    this.showEmptyMsg = false;
                    this.EmptyMsg = '';
                }
                else {
                    this.questionsList = '';
                    this.topic = '';
                    this.showEmptyMsg = true;
                    this.EmptyMsg = 'No question added yet !!!';
                }
            });
        });
    }
};
ListQuestionPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute }
];
ListQuestionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-list-question',
        template: _raw_loader_list_question_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_list_question_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ListQuestionPage);



/***/ }),

/***/ 6955:
/*!*******************************************************!*\
  !*** ./src/app/list-question/list-question.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".questions_page {\n  padding: 0 14px;\n}\n\n.sums_imgs {\n  width: 98%;\n  height: 220px;\n  margin: 0 auto;\n  border-radius: 6px;\n}\n\n.comman_font3 {\n  color: #000000;\n}\n\n.options p {\n  font-size: 14px;\n  color: #404040;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3QtcXVlc3Rpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBQTtBQUFKOztBQUdBO0VBQ0ksVUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFHQTtFQUNJLGNBQUE7QUFBSjs7QUFJQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FBREoiLCJmaWxlIjoibGlzdC1xdWVzdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBxdWVzdGlvbnNfcGFnZSBcclxuLnF1ZXN0aW9uc19wYWdle1xyXG4gICAgcGFkZGluZzogMCAxNHB4O1xyXG59XHJcblxyXG4uc3Vtc19pbWdze1xyXG4gICAgd2lkdGg6IDk4JTtcclxuICAgIGhlaWdodDogMjIwcHg7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG5cclxuLmNvbW1hbl9mb250M3tcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG59XHJcblxyXG5cclxuLm9wdGlvbnMgcHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNDA0MDQwICA7XHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 3075:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/list-question/list-question.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n      <ion-grid>\n          <ion-row>\n              <ion-col size=\"4\">\n                  <ion-buttons>\n                      <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button>\n                  </ion-buttons>\n              </ion-col>\n              <ion-col size=\"4\">\n                  <p class=\"ion-text-center heading\">Questions</p>\n              </ion-col>\n              <ion-col size=\"4\">\n                  <div class=\"avatar_icon\"></div>\n              </ion-col>\n          </ion-row>\n      </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n <!--questions_page Start-->\n  <div class=\"comman_page_padding\">\n  <div class=\"questions_page\">\n    <ion-row>\n      <ion-col size=\"10\">\n        <h1 class=\"color_violet page_tittle\">Questions</h1>\n      </ion-col>\n      <ion-col size=\"2\">\n        <div class=\"btn_theme\">\n          <button [routerLink]=\"['/add-question']\" class='view_btn'   [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: assignment_id,type:pagetype}\">Add</button>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    \n    \n\n    <div *ngFor='let quest of questionsList'>\n    \n      <ion-row >\n        <ion-col>\n          <p class=\"comman_font2 color_violet\">Questions</p>\n        </ion-col>\n\n        <ion-col>\n          <p class=\"comman_font2 font_black\">Answer</p>\n        </ion-col>\n\n        <ion-col>\n          <p class=\"comman_font2 font_black\">Explanation</p>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <img src=\"../../assets/images/sum_maths.jpeg\" class=\"sums_imgs\">\n\n        <p class=\"comman_font3\">{{quest.question ?? ''}}</p>\n      </ion-row>\n      <ion-row> \n        <div class=\"options\">\n          <p>A. {{quest.a ?? ''}}</p>\n          <p>B. {{quest.b ?? ''}}</p>\n          <p>C. {{quest.c ?? ''}}</p>\n          <p>D. {{quest.d ?? ''}}</p>\n        </div>\n\n      </ion-row>\n      <ion-row>    \n          <p>Answer : {{quest.answer ?? ''}}</p> \n      </ion-row>\n      <ion-row> \n          <p>Explaination : {{quest.answer_exp ?? ''}}</p>  \n      </ion-row>\n      <hr>\n    </div>\n\n    <div *ngIf='showEmptyMsg' class='text-center'><br>{{EmptyMsg ?? ''}}</div>\n\n\n\n  </div>\n  </div>\n  <!--questions_page Ends-->\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_list-question_list-question_module_ts.js.map