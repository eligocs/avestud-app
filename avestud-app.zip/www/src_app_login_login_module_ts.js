(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_login_login_module_ts"],{

/***/ 5393:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 6825);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 107:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 5393);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 6825);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 6825:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.page.html */ 6770);
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss */ 1339);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);










let LoginPage = class LoginPage {
    constructor(alertCtrl, router, authService, storageService, toastService) {
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.toastService = toastService;
        this.postData = {
            email: '',
            password: ''
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            this.showloader = false;
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.Role);
            var user = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH);
            var role = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.Role);
            if (role == 'institute') {
                window.location.href = 'homepage';
            }
            else if (role == 'student') {
                window.location.href = '/studenthome';
            }
        });
    }
    showAlert() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                message: '<p>Send verification code to <br> verify your number </p>',
                cssClass: 'alert-box',
                inputs: [
                    {
                        name: 'pin',
                        cssClass: 'enter_otp',
                        type: 'number'
                    },
                ],
                buttons: [
                    {
                        text: 'resend otp',
                        cssClass: 'alert_otp_btn'
                    },
                    {
                        text: 'sign up',
                        cssClass: 'alert_signup_btn'
                    }
                ]
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
        });
    }
    validateInputs() {
        let email = this.postData.email.trim();
        let password = this.postData.password.trim();
        return (this.postData.email &&
            this.postData.password &&
            email.length > 0 &&
            password.length > 0);
    }
    loginAction() {
        this.showloader = true;
        if (this.validateInputs()) {
            this.authService.login(this.postData).subscribe((res) => {
                if (res.access_token) {
                    this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH, res.access_token);
                    this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.userdetails, res.userdetails);
                    if (res.role == 'student') {
                        window.location.href = 'studenthome';
                    }
                    else if (res.role == 'institute') {
                        window.location.href = 'homepage';
                    }
                }
                else {
                    this.toastService.presentToast('Incorrect email and password.');
                }
                this.showloader = false;
            }, (error) => {
                this.toastService.presentToast('Un Authorized, Please enter correct email / password');
                this.showloader = false;
            });
        }
        else {
            this.toastService.presentToast('Username & Password Required !!!');
            this.showloader = false;
        }
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__.StorageService },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginPage);

/*
  export class imageSlider {

  slideOpts = {
    initialSlide: 0,
    speed: 400,
    loop: true,
    autoplay: {
          delay: 2000
    },

    pagination : {
      el: '.swiper-pagination',
      clickable: true,
      type: 'progressbar',
      progressbarFillClass: 'swiper-pagination-progressbar-fill',
      renderProgressbar: function (progressbarFillClass) {
        return '<span class="' + progressbarFillClass + '" style="background: red"></span>';
      }
    }

  }
} */ 


/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 1339:
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  font-family: \"Poppins\", sans-serif;\n}\n\n.logo_area {\n  margin-top: 50px;\n}\n\nh1 {\n  font-size: 22px;\n  margin-top: 0%;\n  color: #090909;\n  font-family: \"Poppins\", sans-serif;\n  font-weight: 500;\n}\n\n.forgot_pass {\n  float: right;\n  margin-right: 22px;\n  font-size: 16px;\n  color: #A0A0A0;\n  font-weight: 400;\n  font-family: \"Poppins\", sans-serif;\n}\n\n.phone_input {\n  margin-bottom: 25px;\n}\n\nion-input {\n  border: 1px solid #A0A0A0;\n  border-radius: 25px;\n  height: 44px;\n  width: 95%;\n  font-size: 16px;\n  padding-left: 30px !important;\n  font-family: \"poppins\", sans-serif;\n  font-weight: 500;\n}\n\n.form_head {\n  margin-bottom: 12px;\n}\n\n.form_text_line {\n  font-size: 12px;\n  color: #A0A0A0;\n  font-family: \"poppins\", sans-serif;\n  font-weight: 600;\n}\n\n.password {\n  position: relative;\n}\n\n.lock_icon {\n  position: absolute;\n  top: 5px;\n  left: 80%;\n}\n\n.login_btn {\n  background-color: #644699;\n  height: 52px;\n  width: 268px;\n  color: white;\n  font-size: 16px;\n  border-radius: 30px;\n  font-family: \"poppins\", sans-serif;\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtDQUFBO0FBQ0o7O0FBRUE7RUFDQSxnQkFBQTtBQUNBOztBQUVBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQUNBOztBQUdBO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0FBQUo7O0FBSUE7RUFDSSxtQkFBQTtBQURKOztBQUlBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLDZCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQURBOztBQUlBO0VBQ0ksbUJBQUE7QUFESjs7QUFJQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQURBOztBQUlBO0VBQ0ksa0JBQUE7QUFESjs7QUFLQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUFGSjs7QUFLQTtFQUNJLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBQUZKIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxufVxyXG5cclxuLmxvZ29fYXJlYXtcclxubWFyZ2luLXRvcDogNTBweDtcclxufVxyXG5cclxuaDF7XHJcbmZvbnQtc2l6ZToyMnB4O1xyXG5tYXJnaW4tdG9wOiAwJTtcclxuY29sb3I6ICMwOTA5MDk7XHJcbmZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbmZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcblxyXG4uZm9yZ290X3Bhc3N7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDIycHg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogI0EwQTBBMDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG5cclxufVxyXG5cclxuLnBob25lX2lucHV0e1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjVweCA7XHJcbn1cclxuXHJcbmlvbi1pbnB1dHtcclxuYm9yZGVyOiAxcHggc29saWQgI0EwQTBBMDtcclxuYm9yZGVyLXJhZGl1czogMjVweDtcclxuaGVpZ2h0OiA0NHB4O1xyXG53aWR0aDogOTUlO1xyXG5mb250LXNpemU6IDE2cHg7XHJcbnBhZGRpbmctbGVmdDogMzBweCAhaW1wb3J0YW50O1xyXG5mb250LWZhbWlseTogJ3BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG5mb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uZm9ybV9oZWFke1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG5cclxuLmZvcm1fdGV4dF9saW5le1xyXG5mb250LXNpemU6IDEycHg7XHJcbmNvbG9yOiAjQTBBMEEwO1xyXG5mb250LWZhbWlseTogJ3BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG5mb250LXdlaWdodDogNjAwO1xyXG59XHJcblxyXG4ucGFzc3dvcmR7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcblxyXG4ubG9ja19pY29ue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1cHg7XHJcbiAgICBsZWZ0OiA4MCU7XHJcbn1cclxuXHJcbi5sb2dpbl9idG57XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNjQ0Njk5O1xyXG4gICAgaGVpZ2h0OiA1MnB4O1xyXG4gICAgd2lkdGg6IDI2OHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGZvbnQtZmFtaWx5OiAncG9wcGlucycsc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICB9Il19 */");

/***/ }),

/***/ 6770:
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" \n\n<ion-content> \n\n \n\n\n  <div class=\"logo_area ion-text-center\">\n\n    <img src=\"../../assets/images/logo.png\">\n\n  </div>\n\n\n  <div class=\"ion-text-center form_head\">\n\n    <h1>Welcome</h1>\n    <span class=\"form_text_line\">Please enter below details to login to Avestud  </span>\n\n    </div>\n\n\n    <ion-row>\n      <ion-col size-sm=\"6\" offset-sm=\"3\" class=\"Password_input\">\n        <ion-item lines=\"none\"> \n\n\n\n          <ion-input required placeholder=\"Phone Number\" name=\"email\" [(ngModel)]=\"postData.email\" class=\"phone_input\" type='text'></ion-input>\n\n        </ion-item>\n        \n        <ion-item lines=\"none\">\n\n\n          <ion-input class=\"password\" name=\"password\" [(ngModel)]=\"postData.password\" required placeholder=\"Password\" type=\"password\"></ion-input>\n\n\n          <img class=\"lock_icon\"  src=\"../assets/images/lock.svg\">\n\n        </ion-item>\n        <p class=\"forgot_pass\">Forgot Password ?</p>\n\n\n      </ion-col>\n      </ion-row>\n   \n      <ion-row class='ion-text-center' *ngIf=\"showloader\">\n        <ion-col size-sm=\"12\" >\n          <ion-spinner name=\"bubbles\" class='bubblesloader' style=\"color:#644699\"></ion-spinner>\n        </ion-col>\n      </ion-row>\n      <div class=\"log-btn ion-text-center\"> \n        <button class=\"login_btn\" (click)=\"loginAction()\">Log In</button> \n      </div> \n      <div class=\"hr_line\">\n        <p class=\"lines\">Register</p>\n      </div>\n      <div class=\"ion-text-center\">\n        <button class=\"login_btn2 comman_login_btn\" [routerLink]=\"['/signup']\">\n          Register\n        </button>\n      </div>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map