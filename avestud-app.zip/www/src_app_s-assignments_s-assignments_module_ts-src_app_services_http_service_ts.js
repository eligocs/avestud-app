(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_s-assignments_s-assignments_module_ts-src_app_services_http_service_ts"],{

/***/ 4985:
/*!***************************************************************!*\
  !*** ./src/app/s-assignments/s-assignments-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SAssignmentsPageRoutingModule": () => (/* binding */ SAssignmentsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_assignments_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-assignments.page */ 7219);




const routes = [
    {
        path: '',
        component: _s_assignments_page__WEBPACK_IMPORTED_MODULE_0__.SAssignmentsPage
    }
];
let SAssignmentsPageRoutingModule = class SAssignmentsPageRoutingModule {
};
SAssignmentsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SAssignmentsPageRoutingModule);



/***/ }),

/***/ 5203:
/*!*******************************************************!*\
  !*** ./src/app/s-assignments/s-assignments.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SAssignmentsPageModule": () => (/* binding */ SAssignmentsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_assignments_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-assignments-routing.module */ 4985);
/* harmony import */ var _s_assignments_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-assignments.page */ 7219);







let SAssignmentsPageModule = class SAssignmentsPageModule {
};
SAssignmentsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_assignments_routing_module__WEBPACK_IMPORTED_MODULE_0__.SAssignmentsPageRoutingModule
        ],
        declarations: [_s_assignments_page__WEBPACK_IMPORTED_MODULE_1__.SAssignmentsPage]
    })
], SAssignmentsPageModule);



/***/ }),

/***/ 7219:
/*!*****************************************************!*\
  !*** ./src/app/s-assignments/s-assignments.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SAssignmentsPage": () => (/* binding */ SAssignmentsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_assignments_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-assignments.page.html */ 8011);
/* harmony import */ var _s_assignments_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-assignments.page.scss */ 606);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_student_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/student.service */ 4339);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);








let SAssignmentsPage = class SAssignmentsPage {
    constructor(studentService, route, storageService) {
        this.studentService = studentService;
        this.route = route;
        this.storageService = storageService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                if (this.subject && this.iacs && token) {
                    this.previousUrl = '/subject-detail-student?iacs=' + this.iacs + '&subject=' + this.subject + '&purchased=1';
                    this.loadstudentAssign(this.iacs, this.subject, token);
                }
            });
        });
    }
    loadstudentAssign(iacs, subject, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                iacs_id: iacs,
                subject: subject,
                token: token,
            };
            yield this.studentService.getstudentAssignment(newData, token).subscribe((res) => {
                if (res.status == 200) {
                    this.assignment_old_unit = res.assignment_old_unit;
                    this.topics = res.topics;
                }
            });
        });
    }
};
SAssignmentsPage.ctorParameters = () => [
    { type: _services_student_service__WEBPACK_IMPORTED_MODULE_2__.StudentService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__.StorageService }
];
SAssignmentsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-s-assignments',
        template: _raw_loader_s_assignments_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_assignments_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SAssignmentsPage);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 606:
/*!*******************************************************!*\
  !*** ./src/app/s-assignments/s-assignments.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".assignment_qustion_page {\n  padding: 0 15px;\n}\n\n.assignment_card {\n  box-shadow: 3px 3px 5px #cccbcb;\n  border-radius: 8px;\n  margin-top: 20px;\n}\n\nh1 {\n  font-weight: 500;\n}\n\n.font_b {\n  font-weight: 600;\n}\n\n.comman_font3 {\n  margin-bottom: 0;\n  color: #949591;\n  font-weight: 500;\n  margin-top: 4px;\n}\n\n.points_row ion-col {\n  height: 25px;\n}\n\n.points_row {\n  line-height: 0;\n}\n\n.points_row p {\n  color: #414141;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.start_session {\n  margin: 25px auto;\n}\n\n.start_btn {\n  height: 36px;\n  width: 114px;\n  font-size: 14px;\n  color: white;\n  font-weight: 400;\n  border-radius: 6px;\n  background-color: #e03e91;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtYXNzaWdubWVudHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBQTtBQUFKOztBQUdFO0VBQ0UsK0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0U7RUFDRSxnQkFBQTtBQUFKOztBQUdFO0VBQ0UsZ0JBQUE7QUFBSjs7QUFHRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUFKOztBQUdFO0VBQ0UsWUFBQTtBQUFKOztBQUdFO0VBQ0UsY0FBQTtBQUFKOztBQUdFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUtFO0VBQ0UsaUJBQUE7QUFGSjs7QUFLRTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUFGSiIsImZpbGUiOiJzLWFzc2lnbm1lbnRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGFzc2lnbm1lbnRfcXVzdGlvbl9wYWdlXHJcbi5hc3NpZ25tZW50X3F1c3Rpb25fcGFnZSB7XHJcbiAgICBwYWRkaW5nOiAwIDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5hc3NpZ25tZW50X2NhcmQge1xyXG4gICAgYm94LXNoYWRvdzogM3B4IDNweCA1cHggI2NjY2JjYjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIGgxIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5mb250X2Ige1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgXHJcbiAgLmNvbW1hbl9mb250MyB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgY29sb3I6ICM5NDk1OTE7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luLXRvcDogNHB4O1xyXG4gIH1cclxuICBcclxuICAucG9pbnRzX3JvdyBpb24tY29sIHtcclxuICAgIGhlaWdodDogMjVweDtcclxuICB9XHJcbiAgXHJcbiAgLnBvaW50c19yb3cge1xyXG4gICAgbGluZS1oZWlnaHQ6IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5wb2ludHNfcm93IHAge1xyXG4gICAgY29sb3I6ICM0MTQxNDE7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gIH1cclxuICBcclxuICAvLyBzdGFydF9idG5cclxuICBcclxuICAuc3RhcnRfc2Vzc2lvbiB7XHJcbiAgICBtYXJnaW46IDI1cHggYXV0bztcclxuICB9XHJcbiAgXHJcbiAgLnN0YXJ0X2J0biB7XHJcbiAgICBoZWlnaHQ6IDM2cHg7XHJcbiAgICB3aWR0aDogMTE0cHg7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2UwM2U5MTtcclxuICB9XHJcbiAgIl19 */");

/***/ }),

/***/ 8011:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-assignments/s-assignments.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--Ion-Header Start-->\n<ion-header>\n  <ion-toolbar>\n     <ion-grid>\n        <ion-row>\n           <ion-col size=\"3\">\n              <ion-buttons>\n                 <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button>\n              </ion-buttons>\n           </ion-col>\n           <ion-col size=\"5\">\n              <p class=\"ion-text-center heading\">Assignments</p>\n           </ion-col>\n           <ion-col size=\"4\">\n              <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n           </ion-col>\n        </ion-row>\n     </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<!--Ion-Header Ends-->\n<!--ion-content Start-->\n<ion-content>\n  <div class=\"assignment_qustion_page\">\n    <div class=\"comman_page_padding\">\n   <!--  <ion-row class=\"row_unit\">\n      <ion-col id=\"theme_shadow\">\n        <p>Unit 5</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 4</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 3</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 2</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 1</p>\n      </ion-col>\n    </ion-row> -->\n    <!--assignment_card start-->\n    <div *ngFor='let assign of assignment_old_unit;'>\n      <div class=\"assignment_card\">\n        <ion-row>\n          <ion-col>\n            <h1 class=\"color_pink comman_font2\">Assignment</h1>\n            <span class=\"comman_font2 font_b\">{{assign.title | titlecase}}</span>\n            <p class=\"comman_font3\">{{assign.description ?? ''}}</p>\n          </ion-col>\n        </ion-row> \n        <ion-row class=\"points_row\">\n          <ion-col size=\"8\">\n            <p>Per Question Mark</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>{{assign.per_q_mark ?? ''}}</p>\n          </ion-col>\n          <ion-col size=\"8\">\n            <p>Total Questions</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>{{assign.questions.length ?? ''}}</p>\n          </ion-col>\n          <ion-col size=\"8\">\n            <p>Total Mark</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>{{assign.questions.length * assign.per_q_mark}}</p>\n          </ion-col>\n          <div class=\"start_session\">\n            <button [routerLink]=\"['/startassignment']\" [queryParams]=\"{iacs:iacs,assignment:assign.id}\" class=\"start_btn\">Start</button>\n          </div>\n        </ion-row> \n      </div>\n    </div>\n    <!--assignment_card Ends-->\n    <!--assignment_card End strat (2)-->\n   <!--  <div class=\"assignment_card\">\n      <ion-row>\n        <ion-col>\n          <h1 class=\"color_pink comman_font2\">Assignment 2</h1>\n          <span class=\"comman_font2 font_b\">How creatures Move</span>\n          <p class=\"comman_font3\">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a\n            piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>\n        </ion-col>\n      </ion-row> \n      <ion-row class=\"points_row\">\n        <ion-col size=\"8\">\n          <p>Per Question Mark</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p>2</p>\n        </ion-col>\n        <ion-col size=\"8\">\n          <p>Total Mark</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p>4</p>\n        </ion-col>\n        <ion-col size=\"8\">\n          <p>Total Questions</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p>2</p>\n        </ion-col>\n        <div class=\"start_session\">\n          <button class=\"start_btn\">Start</button>\n        </div>\n      </ion-row> \n    </div>  -->\n  </div>\n  </div>\n</ion-content>\n<!--ion-content End-->");

/***/ })

}]);
//# sourceMappingURL=src_app_s-assignments_s-assignments_module_ts-src_app_services_http_service_ts.js.map