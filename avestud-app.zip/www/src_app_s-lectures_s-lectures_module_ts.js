(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_s-lectures_s-lectures_module_ts"],{

/***/ 1666:
/*!*********************************************************!*\
  !*** ./src/app/s-lectures/s-lectures-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLecturesPageRoutingModule": () => (/* binding */ SLecturesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_lectures_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-lectures.page */ 6868);




const routes = [
    {
        path: '',
        component: _s_lectures_page__WEBPACK_IMPORTED_MODULE_0__.SLecturesPage
    }
];
let SLecturesPageRoutingModule = class SLecturesPageRoutingModule {
};
SLecturesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SLecturesPageRoutingModule);



/***/ }),

/***/ 5128:
/*!*************************************************!*\
  !*** ./src/app/s-lectures/s-lectures.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLecturesPageModule": () => (/* binding */ SLecturesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_lectures_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-lectures-routing.module */ 1666);
/* harmony import */ var _s_lectures_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-lectures.page */ 6868);







let SLecturesPageModule = class SLecturesPageModule {
};
SLecturesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_lectures_routing_module__WEBPACK_IMPORTED_MODULE_0__.SLecturesPageRoutingModule
        ],
        declarations: [_s_lectures_page__WEBPACK_IMPORTED_MODULE_1__.SLecturesPage]
    })
], SLecturesPageModule);



/***/ }),

/***/ 6868:
/*!***********************************************!*\
  !*** ./src/app/s-lectures/s-lectures.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLecturesPage": () => (/* binding */ SLecturesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_lectures_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-lectures.page.html */ 8040);
/* harmony import */ var _s_lectures_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-lectures.page.scss */ 3925);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _services_student_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/student.service */ 4339);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 476);











let SLecturesPage = class SLecturesPage {
    constructor(modalController, studentService, router, authService, storageService, toastService, route) {
        this.modalController = modalController;
        this.studentService = studentService;
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.toastService = toastService;
        this.route = route;
    }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            this.iacs = params['iacs'];
            this.subject = params['subject'];
            this.purchased = 1;
            if (this.iacs && this.subject) {
                this.getstudentsubject(this.iacs, this.subject);
            }
            if (this.purchased) {
                this.previousUrl = '/subject-detail-student?iacs=' + this.iacs + '&subject=' + this.subject + '&purchased=' + this.purchased;
            }
        });
    }
    getstudentsubject(iacs_id, lecture) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH);
            var newData = {
                iacs_id: iacs_id,
                lecture: lecture,
                token: token,
            };
            yield this.studentService.getstudentsubject(newData, token).subscribe((res) => {
                if (res.status == 200) {
                    this.myclasses = res.lecturesGroupedByUnits;
                }
            });
        });
    }
};
SLecturesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _services_student_service__WEBPACK_IMPORTED_MODULE_6__.StudentService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__.StorageService },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute }
];
SLecturesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-s-lectures',
        template: _raw_loader_s_lectures_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_lectures_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SLecturesPage);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 3925:
/*!*************************************************!*\
  !*** ./src/app/s-lectures/s-lectures.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".revise_lectures_page {\n  padding: 0 20px;\n}\n\n.mg_top {\n  margin-top: 14px;\n}\n\nh1 {\n  font-size: 18px;\n  color: #644699;\n  font-weight: 400;\n  margin-bottom: 0;\n}\n\n.row_unit {\n  margin-top: 20px !important;\n}\n\n.bg_light_yellow {\n  background-color: #FBFFF3;\n}\n\n.bg_light_pink {\n  background-color: #FDF6FA;\n}\n\n.bg_light_gray {\n  background-color: #FBF8FF;\n}\n\n.class_details {\n  box-shadow: 0px 2px 10px #e6dede;\n  border-radius: 8px;\n  padding: 10px;\n  margin-top: 15px;\n}\n\n.left_col {\n  line-height: 6px;\n}\n\nh2 {\n  color: #644699;\n  font-size: 16px;\n  font-weight: 500;\n  margin-bottom: -5px;\n}\n\n.color_pink {\n  font-size: 16px;\n  font-weight: 500;\n}\n\n.left_col span {\n  color: #F9922D;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.youtube_icon {\n  height: 30px;\n  width: 56px;\n  margin-top: 14px;\n}\n\n.download_icons {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtbGVjdHVyZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksZUFBQTtBQURKOztBQUlBO0VBQ0ksZ0JBQUE7QUFESjs7QUFJQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQURKOztBQUlBO0VBQ0ksMkJBQUE7QUFESjs7QUFPQTtFQUNJLHlCQUFBO0FBSko7O0FBT0E7RUFDSSx5QkFBQTtBQUpKOztBQVFBO0VBQ0kseUJBQUE7QUFMSjs7QUFVQTtFQUNJLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7QUFQSjs7QUFVQTtFQUNJLGdCQUFBO0FBUEo7O0FBVUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFQSjs7QUFVQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQVBKOztBQVVBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQVBKOztBQVdBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQVJKOztBQVdBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7QUFSSiIsImZpbGUiOiJzLWxlY3R1cmVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vID09PS5yZXZpc2VfbGVjdHVyZXNfcGFnZT09PSBcclxuXHJcbi5yZXZpc2VfbGVjdHVyZXNfcGFnZXtcclxuICAgIHBhZGRpbmc6IDAgMjBweDtcclxufVxyXG5cclxuLm1nX3RvcHtcclxuICAgIG1hcmdpbi10b3A6IDE0cHg7XHJcbn1cclxuXHJcbmgxe1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgY29sb3I6ICM2NDQ2OTk7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxufVxyXG5cclxuLnJvd191bml0e1xyXG4gICAgbWFyZ2luLXRvcDogMjBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuLy8gPT09Y2FyZCBiYWNrZ291bmQgY29sb3JzPT09IFxyXG5cclxuLmJnX2xpZ2h0X3llbGxvd3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGQkZGRjM7XHJcbn1cclxuXHJcbi5iZ19saWdodF9waW5re1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0ZERjZGQTtcclxufVxyXG5cclxuXHJcbi5iZ19saWdodF9ncmF5e1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0ZCRjhGRjtcclxufVxyXG5cclxuLy8gPT09Y2xhc3NfZGV0YWlscz09PVxyXG5cclxuLmNsYXNzX2RldGFpbHN7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMnB4IDEwcHggI2U2ZGVkZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcblxyXG4ubGVmdF9jb2x7XHJcbiAgICBsaW5lLWhlaWdodDogNnB4O1xyXG59XHJcblxyXG5oMntcclxuICAgIGNvbG9yOiAjNjQ0Njk5O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbi1ib3R0b206IC01cHg7XHJcbn1cclxuXHJcbi5jb2xvcl9waW5re1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLmxlZnRfY29sIHNwYW57XHJcbiAgICBjb2xvcjogI0Y5OTIyRDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcblxyXG4ueW91dHViZV9pY29ue1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgd2lkdGg6IDU2cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNHB4O1xyXG59XHJcblxyXG4uZG93bmxvYWRfaWNvbnN7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgbWFyZ2luLXRvcDogMThweDtcclxufSJdfQ== */");

/***/ }),

/***/ 8040:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-lectures/s-lectures.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--Ion-Header Start-->\n<ion-header>\n  <ion-toolbar>\n     <ion-grid>\n        <ion-row>\n           <ion-col size=\"3\">\n              <ion-buttons>\n                 <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button>\n              </ion-buttons>\n           </ion-col>\n           <ion-col size=\"5\">\n              <p class=\"ion-text-center heading\">Revise Lectures</p>\n           </ion-col>\n           <ion-col size=\"4\">\n              <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n           </ion-col>\n        </ion-row>\n     </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<!--Ion-Header Ends-->\n<!--Ion-content Starts-->\n<ion-content>\n  <!--revise lectures page start-->\n  <div class=\"revise_lectures_page\">\n    <!--Row Unit Start-->\n    <ion-row class=\"row_unit\">\n      <ion-col id=\"theme_shadow\">\n        <p>Unit 5</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 4</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 3</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 2</p>\n      </ion-col>\n      <ion-col>\n        <p>Unit 1</p>\n      </ion-col>\n    </ion-row>\n    <!--Row Uint End-->\n\n    <div *ngFor='let unit of myclasses'>  \n      <!--  <div *ngIf='unit.lectures.length > 0'> -->\n        <h1>{{unit.name ?? ''}}</h1> \n          <!-- <ion-row class=\"class_details bg_light_yellow\" *ngFor='let lect of unit.lectures'>\n            <ion-col size=\"10\" class=\"left_col\"> \n              <p class=\"color_pink\">{{lect.lecture_name}}</p>\n              <span>{{lect.lecture_date}}</span>\n            </ion-col>\n            <ion-col size=\"2\" class=\"right_col\">\n              <a href='{{video ?? \"\"}}'><img src=\"../../assets/images/youtube_icon.svg\" class=\"youtube_icon\"></a>\n              <div class=\"download_icons\">\n                <img src=\"../../assets/images/download_receipt.png\">\n                <a href='{{syllabus ?? \"\"}}' class=\"view_btn\"><img src=\"../../assets/images/arrow_down_pdf.png\"></a>\n              </div>\n            </ion-col>\n          </ion-row>  -->\n        <!-- </div>  -->\n    </div>\n\n    <!--class_detais row End-->\n    <!--class_detais row start-->\n    <!-- <ion-row class=\"class_details mg_top bg_light_gray\">\n      <ion-col size=\"10\" class=\"left_col\">\n        <h2>Unit No 5</h2>\n        <p class=\"color_pink\">The Golden Touch</p>\n        <span>16/01/2021</span>\n      </ion-col>\n      <ion-col size=\"2\" class=\"right_col\">\n        <img src=\"../../assets/imgs/youtube_icon.svg\" class=\"youtube_icon\">\n        <div class=\"download_icons\">\n          <img src=\"../../assets/imgs/download_receipt.png\">\n          <img src=\"../../assets/imgs/arrow_down_pdf.png\">\n        </div>\n      </ion-col>\n    </ion-row> -->\n    <!--class_detais row End-->\n  </div>\n  <!--revise_lectures_page-->\n</ion-content>\n<!--Ion-Content Ends-->\n");

/***/ })

}]);
//# sourceMappingURL=src_app_s-lectures_s-lectures_module_ts.js.map