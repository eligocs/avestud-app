(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_services_http_service_ts-src_app_startassignment_startassignment_module_ts"],{

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 7461:
/*!*******************************************************************!*\
  !*** ./src/app/startassignment/startassignment-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StartassignmentPageRoutingModule": () => (/* binding */ StartassignmentPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _startassignment_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./startassignment.page */ 5095);




const routes = [
    {
        path: '',
        component: _startassignment_page__WEBPACK_IMPORTED_MODULE_0__.StartassignmentPage
    }
];
let StartassignmentPageRoutingModule = class StartassignmentPageRoutingModule {
};
StartassignmentPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], StartassignmentPageRoutingModule);



/***/ }),

/***/ 6302:
/*!***********************************************************!*\
  !*** ./src/app/startassignment/startassignment.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StartassignmentPageModule": () => (/* binding */ StartassignmentPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _startassignment_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./startassignment-routing.module */ 7461);
/* harmony import */ var _startassignment_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./startassignment.page */ 5095);







let StartassignmentPageModule = class StartassignmentPageModule {
};
StartassignmentPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _startassignment_routing_module__WEBPACK_IMPORTED_MODULE_0__.StartassignmentPageRoutingModule
        ],
        declarations: [_startassignment_page__WEBPACK_IMPORTED_MODULE_1__.StartassignmentPage]
    })
], StartassignmentPageModule);



/***/ }),

/***/ 5095:
/*!*********************************************************!*\
  !*** ./src/app/startassignment/startassignment.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StartassignmentPage": () => (/* binding */ StartassignmentPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_startassignment_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./startassignment.page.html */ 8323);
/* harmony import */ var _startassignment_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./startassignment.page.scss */ 8147);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_student_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/student.service */ 4339);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);








let StartassignmentPage = class StartassignmentPage {
    constructor(studentService, route, storageService) {
        this.studentService = studentService;
        this.route = route;
        this.storageService = storageService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.instep = 1;
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.assignment = params['assignment'];
                if (this.assignment) {
                    this.startassignment(this.assignment, token);
                }
            });
        });
    }
    startassignment(assignment, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var newData = {
                assignment: assignment,
            };
            yield this.studentService.startassignment(newData, token).subscribe((res) => {
                var _a;
                if (res.status == 200) {
                    this.questions = (_a = res.questions) !== null && _a !== void 0 ? _a : '';
                    console.log(res);
                }
            });
        });
    }
};
StartassignmentPage.ctorParameters = () => [
    { type: _services_student_service__WEBPACK_IMPORTED_MODULE_2__.StudentService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__.StorageService }
];
StartassignmentPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-startassignment',
        template: _raw_loader_startassignment_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_startassignment_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], StartassignmentPage);



/***/ }),

/***/ 8147:
/*!***********************************************************!*\
  !*** ./src/app/startassignment/startassignment.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".assignment_test_page {\n  padding: 0 15px;\n}\n\n.content_header {\n  align-items: center;\n}\n\n.btn_theme button {\n  height: 35px;\n  width: 85px;\n}\n\nh1 {\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.row_pagination {\n  margin-top: 20px;\n}\n\n.pagination {\n  display: flex;\n  justify-content: space-between;\n}\n\n.pagination a {\n  color: #8a8a8a;\n  float: left;\n  padding: 8px 10px;\n  text-decoration: none;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.pagination .font_dark {\n  color: #000000;\n}\n\n.circle {\n  height: 28px;\n  width: 28px;\n  border: 2px solid #82cf05;\n  border-radius: 50%;\n  position: relative;\n  top: 4px;\n}\n\n.active {\n  position: absolute;\n  right: 8px;\n  bottom: 2px;\n}\n\n.question {\n  margin-bottom: 20px;\n  box-shadow: 0 3px 6px 1px #a9a9a9;\n  border-radius: 5px;\n}\n\nspan.numbreq {\n  font-size: 15px;\n  color: #644699;\n  font-weight: 900;\n}\n\n.question p {\n  font-size: 12px;\n  color: #000000;\n  font-weight: 400;\n  line-height: 22px;\n}\n\nion-item {\n  margin-bottom: 12px;\n  height: 36px;\n  display: flex;\n  align-items: center;\n  border-radius: 5px;\n}\n\nion-radio {\n  height: 13px;\n  width: 13px;\n  margin-right: 15px;\n}\n\nion-label {\n  font-size: 14px;\n  color: #404040;\n  font-weight: 400;\n}\n\n.mg-left {\n  margin-left: 15px;\n}\n\n.border_v {\n  border: 1px solid #634996;\n}\n\n.border_y {\n  border: 1px solid #f99f30;\n}\n\n.border_o {\n  border: 1px solid #fe7d4d;\n}\n\n.border_s {\n  border: 1px solid #1489d4;\n}\n\n.sums_img {\n  width: 150px;\n  height: 100px;\n}\n\n.mg_bottom {\n  margin-bottom: 0;\n}\n\n.btns_row button {\n  height: 30px;\n  width: 85px;\n  color: white;\n  font-size: 12px;\n  font-weight: 400;\n  border-radius: 5px;\n}\n\n.overflowhidden {\n  overflow-y: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXJ0YXNzaWdubWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxlQUFBO0FBREo7O0FBSUU7RUFDRSxtQkFBQTtBQURKOztBQUlFO0VBQ0UsWUFBQTtFQUNBLFdBQUE7QUFESjs7QUFJRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQURKOztBQU1FO0VBQ0UsZ0JBQUE7QUFISjs7QUFNRTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtBQUhOOztBQU1FO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBSEo7O0FBTUU7RUFDRSxjQUFBO0FBSEo7O0FBUUU7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUFMSjs7QUFRRTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUFMTjs7QUFVRTtFQUNFLG1CQUFBO0VBQ0EsaUNBQUE7RUFDQSxrQkFBQTtBQVBKOztBQVNFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQU5KOztBQVNFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBTko7O0FBV0U7RUFDRSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQVJKOztBQVdFO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQVJKOztBQVdFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQVJKOztBQVdFO0VBQ0ksaUJBQUE7QUFSTjs7QUFhRTtFQUNFLHlCQUFBO0FBVko7O0FBYUU7RUFDRSx5QkFBQTtBQVZKOztBQWFFO0VBQ0UseUJBQUE7QUFWSjs7QUFhRTtFQUNFLHlCQUFBO0FBVko7O0FBYUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQVZKOztBQWFFO0VBQ0UsZ0JBQUE7QUFWSjs7QUFlRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBWko7O0FBY0U7RUFDRSxrQkFBQTtBQVhKIiwiZmlsZSI6InN0YXJ0YXNzaWdubWVudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyA9PT09PWFzc2lnbm1lbnRfdGVzdF9wYWdlPT09PT1cclxuXHJcbi5hc3NpZ25tZW50X3Rlc3RfcGFnZSB7XHJcbiAgICBwYWRkaW5nOiAwIDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jb250ZW50X2hlYWRlciB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAuYnRuX3RoZW1lIGJ1dHRvbiB7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICB3aWR0aDogODVweDtcclxuICB9XHJcbiAgXHJcbiAgaDEge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICB9XHJcbiAgXHJcbiAgLy8gPT09PXJvd19wYWdpbmF0aW9uPT09PVxyXG4gIFxyXG4gIC5yb3dfcGFnaW5hdGlvbiB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIH1cclxuICBcclxuICAucGFnaW5hdGlvbntcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIH1cclxuICBcclxuICAucGFnaW5hdGlvbiBhIHtcclxuICAgIGNvbG9yOiAjOGE4YThhO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICBwYWRkaW5nOiA4cHggMTBweDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7IFxyXG4gIH1cclxuICBcclxuICAucGFnaW5hdGlvbiAuZm9udF9kYXJrIHtcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gIH1cclxuICBcclxuICAvLz09PT1wYWdpbmF0aW9uIGNpcmNsZT09PT09XHJcbiAgXHJcbiAgLmNpcmNsZSB7XHJcbiAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICB3aWR0aDogMjhweDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkICM4MmNmMDU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IDRweDtcclxuICB9XHJcbiAgXHJcbiAgLmFjdGl2ZSB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IDhweDtcclxuICAgICAgYm90dG9tOiAycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vID09PT09cXVlc3Rpb249PT09PVxyXG4gIFxyXG4gIC5xdWVzdGlvbiB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAzcHggNnB4IDFweCAjYTlhOWE5O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIH1cclxuICBzcGFuLm51bWJyZXEge1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgY29sb3I6ICM2NDQ2OTk7XHJcbiAgICBmb250LXdlaWdodDogOTAwO1xyXG59XHJcbiAgXHJcbiAgLnF1ZXN0aW9uIHAge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vPT09PT1SYWRpbyBRdWVzdGlvbnM9PT09PVxyXG4gIFxyXG4gIGlvbi1pdGVtIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbiAgICBoZWlnaHQ6IDM2cHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLXJhZGlvIHtcclxuICAgIGhlaWdodDogMTNweDtcclxuICAgIHdpZHRoOiAxM3B4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG4gIH1cclxuICBcclxuICBpb24tbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICM0MDQwNDA7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gIH1cclxuICBcclxuICAubWctbGVmdHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vID09PT09UmFkaW8gUXVlc3Rpb25zPT09PT1cclxuICBcclxuICAuYm9yZGVyX3Yge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzYzNDk5NjtcclxuICB9XHJcbiAgXHJcbiAgLmJvcmRlcl95IHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNmOTlmMzA7XHJcbiAgfVxyXG4gIFxyXG4gIC5ib3JkZXJfbyB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmU3ZDRkO1xyXG4gIH1cclxuICBcclxuICAuYm9yZGVyX3Mge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzE0ODlkNDtcclxuICB9XHJcbiAgXHJcbiAgLnN1bXNfaW1nIHtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5tZ19ib3R0b20ge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICB9XHJcbiAgXHJcbiAgLy8gPT09PT09YnRuc19yb3c9PT09PT09XHJcbiAgXHJcbiAgLmJ0bnNfcm93IGJ1dHRvbiB7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICB3aWR0aDogODVweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgfVxyXG4gIC5vdmVyZmxvd2hpZGRlbiB7XHJcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XHJcbn1cclxuICJdfQ== */");

/***/ }),

/***/ 8323:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/startassignment/startassignment.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--===Ion-Header Start===-->\n<ion-header>\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\">\n          <ion-buttons>\n            <ion-back-button defaultHref=\"/logout\" class=\"color_violet\"></ion-back-button>\n          </ion-buttons>\n        </ion-col>\n        <ion-col size=\"5\">\n          <p class=\"ion-text-center heading\">Assignments</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<!--====Ion-Header Ends=====-->\n<!--====ion-content Start===-->\n<ion-content>\n  <!--===assignment_test_page====-->\n  <div class=\"comman_page_padding\">\n\n  <div class=\"assignment_test_page \">\n    <!--==content_header==-->\n    <ion-row class=\"content_header\">\n      <ion-col size=\"8\">\n        <h1>29:15 min</h1>\n      </ion-col>\n      <ion-col size=\"4\">\n        <div class=\"btn_theme\">\n          <button href=\"#\">Submit</button>\n        </div>\n      </ion-col>\n    </ion-row>\n    <!--===row_pagination===-->\n    <ion-row>\n      <ion-col class=\"row_pagination\">\n        <div class=\"pagination\">\n          <a href=\"#\"><img src=\"../../assets/images/previous_btn.png\"></a>\n              <div  *ngFor='let quest of questions; let i = index;'>\n                <div class='overflow'>\n                  <a href=\"#\" (click)=\"changestep()\" class=\"font_dark {{instep == 1 ? 'circle' : ''}}\">{{i+1}}</a>\n                </div>\n              </div>\n             <!--  <a href=\"#\" class=\"font_dark circle\"><span class=\"active\">2</span></a>\n              <a href=\"#\">3</a>   -->\n          <a href=\"#\"><img src=\"../../assets/images/next_button.png\"></a>\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n    <!--==question==-->\n    <div class='questionary' *ngFor='let quest of questions; let i = index;'> \n      <div class='questionary' *ngIf='instep == 1;'> \n        <ion-row class=\"question\">\n          <ion-col>\n            <p><span class=\"numbreq\">{{i+1}}</span> : {{quest.question ?? ''}}</p>\n            <br>\n          </ion-col>\n        </ion-row>\n        <!--======ion-list======-->\n        <ion-list>\n          <ion-radio-group value=\"biff\">\n            <ion-item class=\"border_v\">\n              <ion-label>A. <span class=\"mg-left\">{{quest.a ?? ''}}</span></ion-label>\n              <ion-radio slot=\"start\" value=\"biff\"></ion-radio>\n            </ion-item>\n            <ion-item class=\"border_y\">\n              <ion-label>B. <span class=\"mg-left\">{{quest.b ?? ''}}</span></ion-label>\n              <ion-radio slot=\"start\" value=\"griff\"></ion-radio>\n            </ion-item>\n            <ion-item class=\"border_o\">\n              <ion-label>C. <span class=\"mg-left\">{{quest.c ?? ''}}</span></ion-label>\n              <ion-radio slot=\"start\" value=\"buford\"></ion-radio>\n            </ion-item>\n            <ion-item class=\"border_s mg_bottom\">\n              <ion-label>D. <span class=\"mg-left\">{{quest.d ?? ''}}</span></ion-label>\n              <ion-radio slot=\"start\" value=\"afjdks\"></ion-radio>\n            </ion-item>\n          </ion-radio-group>\n        </ion-list>\n        <br>\n        <!--======ion-list End====-->\n        <ion-row *ngIf='quest.question_img'>\n          <ion-col>\n            <img src=\"{{quest.question_img ?? ''}}\" class=\"sums_img\">\n          </ion-col>\n        </ion-row>\n        <hr>\n        <br>\n      </div>\n    </div>\n      <!--====btns_row====-->\n      <ion-row class=\"btns_row ion-text-center\">\n        <ion-col>\n          <button class=\"bg_green\">Skip</button>\n        </ion-col>\n        <ion-col>\n          <button class=\"bg_violet\">Prev</button>\n        </ion-col>\n        <ion-col>\n          <button class=\"bg_pink\">Next</button>\n        </ion-col>\n      </ion-row>\n    </div>\n   \n  \n</div>\n   <!--===assignment_test_page End====-->\n</ion-content>\n<!--Ion Content End-->");

/***/ })

}]);
//# sourceMappingURL=src_app_services_http_service_ts-src_app_startassignment_startassignment_module_ts.js.map