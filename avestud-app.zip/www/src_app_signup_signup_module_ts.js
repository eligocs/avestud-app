(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_signup_signup_module_ts"],{

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 159:
/*!*************************************************!*\
  !*** ./src/app/signup/signup-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPageRoutingModule": () => (/* binding */ SignupPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signup.page */ 771);




const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_0__.SignupPage
    }
];
let SignupPageRoutingModule = class SignupPageRoutingModule {
};
SignupPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SignupPageRoutingModule);



/***/ }),

/***/ 7648:
/*!*****************************************!*\
  !*** ./src/app/signup/signup.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPageModule": () => (/* binding */ SignupPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _signup_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./signup-routing.module */ 159);
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signup.page */ 771);







let SignupPageModule = class SignupPageModule {
};
SignupPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _signup_routing_module__WEBPACK_IMPORTED_MODULE_0__.SignupPageRoutingModule
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_1__.SignupPage]
    })
], SignupPageModule);



/***/ }),

/***/ 771:
/*!***************************************!*\
  !*** ./src/app/signup/signup.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignupPage": () => (/* binding */ SignupPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./signup.page.html */ 1355);
/* harmony import */ var _signup_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./signup.page.scss */ 4194);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 476);










let SignupPage = class SignupPage {
    constructor(authService, toastService, storageService, router, alertCtrl) {
        this.authService = authService;
        this.toastService = toastService;
        this.storageService = storageService;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.postData = {
            name: '',
            phone: '',
            grade: '',
            state: '',
            city: '',
            password: '',
            confirm_password: '',
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH);
            var mainThis = this;
            if (token) {
            }
        });
    }
    validateInputs() {
        let name = this.postData.name;
        let password = this.postData.password;
        let confirm_password = this.postData.confirm_password;
        let phone = this.postData.phone;
        let grade = this.postData.grade;
        let state = this.postData.state;
        let city = this.postData.city;
        if (name == '') {
            return 0;
        }
        if (password == '') {
            return 0;
        }
        if (confirm_password == '') {
            return 0;
        }
        if (phone == '') {
            return 0;
        }
        if (grade == '') {
            return 0;
        }
        if (state == '') {
            return 0;
        }
        if (city == '') {
            return 0;
        }
        return 1;
    }
    register_student() {
        if (this.validateInputs()) {
            if (this.postData.password == this.postData.confirm_password) {
                this.authService.register_student(this.postData).subscribe((res) => {
                    if (res.status == 200) {
                        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.otp);
                        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.phone);
                        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.pwd);
                        this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.otp, res.otp);
                        this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.phone, res.phone);
                        this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.pwd, res.pwd);
                        this.router.navigate(['verifyotp']);
                    }
                    else {
                        this.toastService.presentToast('Data already exists, please enter new details.');
                    }
                }, (error) => {
                    this.toastService.presentToast('Network Issue.');
                });
            }
            else {
                this.toastService.presentToast('Password did not match !!!');
            }
        }
        else {
            this.toastService.presentToast('All the fields are required');
        }
    }
    signAction() {
        if (this.validateInputs()) {
            this.authService.signup(this.postData).subscribe((res) => {
                if (res.userData) {
                    // Storing the User data.
                    this.storageService
                        .store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH, res.userData)
                        .then(res => {
                        this.router.navigate(['home/feed']);
                    });
                }
                else {
                    this.toastService.presentToast('Data alreay exists, please enter new details.');
                }
            }, (error) => {
                this.toastService.presentToast('Network Issue.');
            });
        }
        else {
            this.toastService.presentToast('Please enter email, username or password.');
        }
    }
};
SignupPage.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController }
];
SignupPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-signup',
        template: _raw_loader_signup_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_signup_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SignupPage);



/***/ }),

/***/ 4194:
/*!*****************************************!*\
  !*** ./src/app/signup/signup.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".register_page {\n  padding: 0 15px;\n}\n\nion-input {\n  border: 1px solid #a0a0a0;\n  border-radius: 25px;\n  height: 44px;\n  width: 100%;\n  font-size: 16px;\n  padding-left: 18px !important;\n  font-family: \"poppins\", sans-serif;\n  font-weight: 400;\n  margin-bottom: 15px;\n}\n\nion-select {\n  border: 1px solid #a0a0a0;\n  border-radius: 25px;\n  height: 44px;\n  width: 100% !important;\n  font-size: 16px;\n  padding-left: 30px !important;\n  font-family: \"poppins\", sans-serif;\n  font-weight: 400;\n  margin-bottom: 18px;\n  color: #000000;\n  padding-left: 18px !important;\n}\n\nion-select {\n  --opacity: 1 !important;\n}\n\n.ion_select {\n  background: url('arrow_down.png');\n  background-repeat: no-repeat;\n  background-position: right 6% bottom 45%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZ251cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDSSxlQUFBO0FBRko7O0FBT0U7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFKSjs7QUFTRTtFQUNFLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7QUFOSjs7QUFTRTtFQUNFLHVCQUFBO0FBTko7O0FBU0U7RUFDRSxpQ0FBQTtFQUNBLDRCQUFBO0VBQ0Esd0NBQUE7QUFOSiIsImZpbGUiOiJzaWdudXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8vID09PT09PT09PT0ucmVnaXN0ZXJfcGFnZT09PT09PT09PVxyXG5cclxuLnJlZ2lzdGVyX3BhZ2Uge1xyXG4gICAgcGFkZGluZzogMCAxNXB4O1xyXG4gIH1cclxuICBcclxuICAvLyA9PT09PT1pb24taW5wdXQ9PT09PT09XHJcbiAgXHJcbiAgaW9uLWlucHV0IHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNhMGEwYTA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gIH1cclxuICBcclxuICAvLyA9PT09PT1pb24tc2VsZWN0IHN0YXJ0PT09PT09XHJcbiAgXHJcbiAgaW9uLXNlbGVjdCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjYTBhMGEwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLXNlbGVjdCB7XHJcbiAgICAtLW9wYWNpdHk6IDEgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgLmlvbl9zZWxlY3Qge1xyXG4gICAgYmFja2dyb3VuZDogdXJsKC4uLy4uL2Fzc2V0cy9pbWFnZXMvYXJyb3dfZG93bi5wbmcpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IHJpZ2h0IDYlIGJvdHRvbSA0NSU7XHJcbiAgfVxyXG4gIFxyXG4gIC8vID09PT09PUVuZD09PT09XHJcbiAgIl19 */");

/***/ }),

/***/ 1355:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" \n  \n  <ion-content padding='true'>\n    <div class=\"register_page\">\n      <div class=\"logo_area ion-text-center\">\n        <img src=\"../../assets/images/logo.png\" />\n      </div>\n      <div class=\"ion-text-center form_head\">\n        <h1>Welcome Back</h1>\n        <span class=\"form_text_line\">Please enter below detials to login to Avestud</span>\n      </div>\n      <!--======regster page input start=======-->\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <!--======input phone number======-->\n          <ion-item lines=\"none\">\n            <ion-input  [(ngModel)]=\"postData.name\" name='name' required placeholder=\"Full Name\" type=\"text\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-input  [(ngModel)]=\"postData.phone\" name='phone' required placeholder=\"Phone Number\" type=\"Number\"></ion-input>\n          </ion-item>\n          <!--input Grade-->\n          <ion-item lines=\"none\">\n            <ion-input  [(ngModel)]=\"postData.grade\" name='grade' type=\"text\" required placeholder=\"your grade  eg: 12th,engineering\"></ion-input>\n          </ion-item>\n          <!--======input select state=====-->\n          <ion-item lines=\"none\">\n            <ion-select placeholder=\"Select State\"  [(ngModel)]=\"postData.state\" name='state' class=\"ion_select\">\n              <ion-select-option value=\"Andhra Pradesh\">Andhra Pradesh</ion-select-option>\n              <ion-select-option value=\"Arunachal Pradesh\">Arunachal Pradesh</ion-select-option>\n              <ion-select-option value=\"Assam\">Assam</ion-select-option>\n              <ion-select-option value=\"Bihar\">Bihar</ion-select-option>\n              <ion-select-option value=\"Chhattisgarh\">Chhattisgarh</ion-select-option>\n              <ion-select-option value=\"Goa\">Goa</ion-select-option>\n              <ion-select-option value=\"Gujarat\">Gujarat</ion-select-option>\n              <ion-select-option value=\"Haryana\">Haryana</ion-select-option>\n              <ion-select-option value=\"Himachal Pradesh\">Himachal Pradesh</ion-select-option>\n              <ion-select-option value=\"Jammu and Kashmir\">Jammu and Kashmir</ion-select-option>\n              <ion-select-option value=\"Jharkhand\">Jharkhand</ion-select-option>\n              <ion-select-option value=\"Karnataka\">Karnataka</ion-select-option>\n              <ion-select-option value=\"Kerala\">Kerala</ion-select-option>\n              <ion-select-option value=\"Madhya Pradesh\">Madhya Pradesh</ion-select-option>\n              <ion-select-option value=\"Maharashtra\">Maharashtra</ion-select-option>\n              <ion-select-option value=\"Manipur\">Manipur</ion-select-option>\n              <ion-select-option value=\"Meghalaya\">Meghalaya</ion-select-option>\n              <ion-select-option value=\"Mizoram\">Mizoram</ion-select-option>\n              <ion-select-option value=\"Nagaland\">Nagaland</ion-select-option>\n              <ion-select-option value=\"Odisha\">Odisha</ion-select-option>\n              <ion-select-option value=\"Punjab\">Punjab</ion-select-option>\n              <ion-select-option value=\"Rajasthan\">Rajasthan</ion-select-option>\n              <ion-select-option value=\"Sikkim\">Sikkim</ion-select-option>\n              <ion-select-option value=\"Tamil Nadu\">Tamil Nadu</ion-select-option>\n              <ion-select-option value=\"Telangana\">Telangana</ion-select-option>\n              <ion-select-option value=\"Tripura\">Tripura</ion-select-option>\n              <ion-select-option value=\"Uttar Pradesh\">Uttar Pradesh</ion-select-option>\n              <ion-select-option value=\"Uttarakhand\">Uttarakhand</ion-select-option>\n              <ion-select-option value=\"West Bengal\">West Bengal</ion-select-option>\n              <ion-select-option value=\"Andaman and Nicobar Islands\">Andaman and Nicobar Island</ion-select-option> \n              <ion-select-option value=\"Chandigarh\">Chandigarh</ion-select-option>\n              <ion-select-option value=\"Dadra and Nagar Haveli\">Dadra and Nagar Haveli</ion-select-option>\n              <ion-select-option value=\"Daman and Diu\">Daman and Diu</ion-select-option>\n              <ion-select-option value=\"Lakshadweep\">Lakshadweep</ion-select-option>\n              <ion-select-option value=\"National Capital Territory of Delhi\">National Capital Tion-select-optionry of Delhi</ion-select-option>\n              <ion-select-option value=\"Puducherry\">Puducherry</ion-select-option>\n            </ion-select>\n          </ion-item>\n          <!--=====input City=====-->\n          <ion-item lines=\"none\">\n            <ion-input  [(ngModel)]=\"postData.city\"  name='city' required placeholder=\"Enter your city name\" type=\"text\"></ion-input>\n          </ion-item>\n          <!-- =======iput password======== -->\n          <ion-item lines=\"none\">\n            <ion-input type=\"password\" [(ngModel)]=\"postData.password\" name='password'  required placeholder=\"Password\"></ion-input>\n          </ion-item>\n          <!--input confirm password-->\n          <ion-item lines=\"none\">\n            <ion-input type=\"password\" required [(ngModel)]=\"postData.confirm_password\" name='confirm_password' placeholder=\"Confirm Password\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <!--======regster page input End=======-->\n      <div class=\"ion-text-center\" id=\"otp_alert_box\">\n        <button class=\"get_otp comman_login_btn\" (click)=\"register_student()\">\n          Get Otp\n        </button>\n      </div>\n      <div class=\"hr_line\">\n        <p class=\"lines\">Existing user</p>\n      </div>\n      <div class=\"ion-text-center\">\n        <button class=\"login_btn2 comman_login_btn\" [routerLink]=\"['/']\">\n          Login\n        </button>\n      </div>\n    </div>\n   <!--  <div class=\"center\">\n    <img src=\"assets/images/logo.png\" class=\"smallLogo\"/>\n    <h1>Create Account</h1>\n    </div>\n    <form>\n    <ion-list>\n    <ion-item>\n    <ion-label position=\"stacked\">Email</ion-label>\n    <ion-input autocomplete=\"off\" name=\"email\" type=\"email\"></ion-input>\n    </ion-item>\n    <ion-item>\n    <ion-label position=\"stacked\">Username</ion-label>\n    <ion-input autocomplete=\"off\" name=\"username\" type=\"text\"></ion-input>\n    </ion-item>\n    \n    <ion-item>\n    <ion-label position=\"stacked\">Password</ion-label>\n    <ion-input autocomplete=\"off\" name=\"password\" type=\"password\"></ion-input>\n    </ion-item>\n    \n    <ion-item lines='none'>\n    Already have an account? <a routerLink='/login'>Sign in.</a>\n    </ion-item>\n    </ion-list>\n    <ion-button expand=\"block\" share=\"round\" color=\"success\" (click)=\"signAction()\">Registration</ion-button>\n    </form> -->\n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_signup_signup_module_ts.js.map