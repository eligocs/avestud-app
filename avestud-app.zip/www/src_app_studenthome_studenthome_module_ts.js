(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_studenthome_studenthome_module_ts"],{

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 6824:
/*!***********************************************************!*\
  !*** ./src/app/studenthome/studenthome-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudenthomePageRoutingModule": () => (/* binding */ StudenthomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _studenthome_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./studenthome.page */ 1945);




const routes = [
    {
        path: '',
        component: _studenthome_page__WEBPACK_IMPORTED_MODULE_0__.StudenthomePage
    }
];
let StudenthomePageRoutingModule = class StudenthomePageRoutingModule {
};
StudenthomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], StudenthomePageRoutingModule);



/***/ }),

/***/ 870:
/*!***************************************************!*\
  !*** ./src/app/studenthome/studenthome.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudenthomePageModule": () => (/* binding */ StudenthomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _studenthome_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./studenthome-routing.module */ 6824);
/* harmony import */ var _studenthome_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./studenthome.page */ 1945);







let StudenthomePageModule = class StudenthomePageModule {
};
StudenthomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _studenthome_routing_module__WEBPACK_IMPORTED_MODULE_0__.StudenthomePageRoutingModule
        ],
        declarations: [_studenthome_page__WEBPACK_IMPORTED_MODULE_1__.StudenthomePage]
    })
], StudenthomePageModule);



/***/ }),

/***/ 1945:
/*!*************************************************!*\
  !*** ./src/app/studenthome/studenthome.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudenthomePage": () => (/* binding */ StudenthomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_studenthome_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./studenthome.page.html */ 156);
/* harmony import */ var _studenthome_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./studenthome.page.scss */ 2346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _services_student_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/student.service */ 4339);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../previous-route.service */ 8735);











let StudenthomePage = class StudenthomePage {
    constructor(previousRouteService, router, authService, storageService, StudentService, homeService) {
        this.previousRouteService = previousRouteService;
        this.router = router;
        this.authService = authService;
        this.storageService = storageService;
        this.StudentService = StudentService;
        this.homeService = homeService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.showEnrolled = false;
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_6__.AuthConstants.AUTH);
            var userdetails = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_6__.AuthConstants.userdetails);
            this.studentname = userdetails.name ? userdetails.name : '';
            var mainThis = this;
            if (!token) {
                this.router.navigate(['/']);
            }
            else {
                if (userdetails.role == 'student') {
                    mainThis.router.navigate(['/studenthome']);
                }
                else if (userdetails.role == 'institute') {
                    mainThis.router.navigate(['/homepage']);
                }
                var classroom = yield this.StudentService.studenthome(token).subscribe((res) => {
                    if (res.data) {
                        var allClasses = res.data;
                        allClasses.institute_assigned_class.forEach((entry, i) => {
                            entry.institute_assigned_class_subject.forEach((entry1, i) => {
                                entry1.color_code = colorLight(i);
                            });
                        });
                        this.allClasses = allClasses;
                        console.log(this.allClasses);
                        this.showEnrolled = true;
                    }
                    else {
                        /*  mainThis.storageService.removeStorageItem(AuthConstants.AUTH).then(res => {
                         mainThis.storageService.removeStorageItem(AuthConstants.Role);
                         mainThis.storageService.removeStorageItem(AuthConstants.userdetails);
                         mainThis.router.navigate(['/']);
                       }); */
                    }
                });
            }
            function colorLight(i) {
                var items = ['yellow_gradient_btn', 'pink_btn', 'blue_gradient_btn', 'green_gradient_btn', 'orange_gradient_btn'];
                return items[Math.floor(Math.random() * items.length)];
            }
        });
    }
    logoutAction() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.showloader = true;
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_6__.AuthConstants.Role);
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_6__.AuthConstants.AUTH);
            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_6__.AuthConstants.userdetails);
            this.authService.logout();
        });
    }
};
StudenthomePage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_7__.PreviousRouteService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_student_service__WEBPACK_IMPORTED_MODULE_5__.StudentService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_4__.HomeService }
];
StudenthomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-studenthome',
        template: _raw_loader_studenthome_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_studenthome_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], StudenthomePage);



/***/ }),

/***/ 2346:
/*!***************************************************!*\
  !*** ./src/app/studenthome/studenthome.page.scss ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("* {\n  font-family: \"poppins\", sans-serif;\n}\n\n.home_page_student {\n  padding: 0 18px;\n}\n\nh1 {\n  font-size: 20px;\n  font-weight: 400;\n  margin-bottom: 0;\n}\n\nh2 {\n  font-size: 18px;\n  font-weight: 600;\n  margin-top: 0;\n}\n\n.standared {\n  line-height: 0;\n}\n\n.standared h3 {\n  font-weight: 500;\n}\n\n.standared p {\n  margin-top: 12px;\n  color: #727272;\n  font-size: 12px;\n  margin-bottom: 6px;\n}\n\n.video_btn button {\n  height: 40px;\n  width: 154px;\n  color: white;\n  font-size: 10px;\n  font-weight: 400;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 6px;\n  margin: 0 auto;\n  margin-bottom: 6px;\n}\n\n.video_btn button img {\n  padding-right: 15px;\n  height: 32px;\n  width: 45px;\n}\n\n.box_shadow {\n  box-shadow: 0px 3px 10px #d6d2d2;\n  width: 100%;\n  padding: 0 10px;\n  border-radius: 7px;\n}\n\n.subject_card {\n  line-height: 8px;\n  width: 100%;\n  padding: 5px 15px;\n  border-radius: 6px;\n  color: white;\n}\n\n.subject_card h4 {\n  margin-top: 0;\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.subject_details {\n  display: flex;\n  justify-content: space-between;\n}\n\n.subject_details p {\n  font-size: 14px;\n  margin-top: 0;\n  font-weight: 500;\n}\n\n.grad_green,\n.grad_orange,\n.grad_sky {\n  margin-top: 16px;\n}\n\n.blue_gradient_btn {\n  background: linear-gradient(45deg, #62d9ff, #1a83a4);\n}\n\n.orange_gradient_btn {\n  background: linear-gradient(45deg, #ff9212d9, #f5a24b);\n}\n\n.pink_btn {\n  background: linear-gradient(45deg, #e45bffd9, #871b98);\n}\n\n.green_gradient_btn {\n  background: linear-gradient(45deg, #57bc14d9, #438c3c);\n}\n\n.yellow_gradient_btn {\n  background: linear-gradient(45deg, #fb5e5e, #c80404);\n}\n\n.class_days {\n  display: flex;\n  justify-content: space-evenly;\n  line-height: 8px;\n}\n\n.class_days p {\n  font-size: 14px;\n  color: #727272;\n  font-weight: 600;\n}\n\n.class_days span {\n  font-size: 10px;\n  color: #000000;\n  font-weight: 400;\n}\n\n.margin_for_card {\n  margin-top: 15px;\n  margin-bottom: 15px;\n  padding-bottom: 10px;\n}\n\n.mt-5 {\n  margin-top: 180px;\n}\n\n.text-white {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0dWRlbnRob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtDQUFBO0FBQ0o7O0FBSUU7RUFDRSxlQUFBO0FBREo7O0FBTUU7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQUhKOztBQU1FO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsY0FBQTtBQUhKOztBQU1FO0VBQ0UsZ0JBQUE7QUFISjs7QUFNRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUhKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUxKOztBQVFFO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQUxKOztBQVlFO0VBQ0UsZ0NBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBVEo7O0FBZ0JFO0VBQ0UsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFiSjs7QUFnQkU7RUFDRSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBYko7O0FBa0JFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBZko7O0FBa0JFO0VBQ0UsZUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQWZKOztBQW1CRTs7O0VBR0UsZ0JBQUE7QUFoQko7O0FBbUJFO0VBQ0Usb0RBQUE7QUFoQko7O0FBa0JFO0VBQ0Usc0RBQUE7QUFmSjs7QUFpQkU7RUFDRSxzREFBQTtBQWRKOztBQWdCRTtFQUNFLHNEQUFBO0FBYko7O0FBZUU7RUFDRSxvREFBQTtBQVpKOztBQWlCRTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtFQUNBLGdCQUFBO0FBZEo7O0FBaUJFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQWRKOztBQWlCRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFkSjs7QUFrQkU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7QUFmSjs7QUFrQkU7RUFDSSxpQkFBQTtBQWZOOztBQWtCQTtFQUNJLFlBQUE7QUFmSiIsImZpbGUiOiJzdHVkZW50aG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqIHtcclxuICAgIGZvbnQtZmFtaWx5OiBcInBvcHBpbnNcIiwgc2Fucy1zZXJpZjtcclxuICB9XHJcbiAgXHJcbiAgLy8gPT09PT1ob21lX3BhZ2Vfc3R1ZGVudCBjc3Mgc3RhcnQ9PT09XHJcbiAgXHJcbiAgLmhvbWVfcGFnZV9zdHVkZW50IHtcclxuICAgIHBhZGRpbmc6IDAgMThweDtcclxuICB9XHJcbiAgXHJcbiAgLy8gPT09aGVhZGVyIHBhcnQncyBjc3M9PT0gXHJcbiAgXHJcbiAgaDEge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgfVxyXG4gIFxyXG4gIGgyIHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gIH1cclxuICBcclxuICAuc3RhbmRhcmVkIHtcclxuICAgIGxpbmUtaGVpZ2h0OiAwO1xyXG4gIH1cclxuICBcclxuICAuc3RhbmRhcmVkIGgzIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5zdGFuZGFyZWQgcCB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgY29sb3I6ICM3MjcyNzI7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA2cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC8vID09PT09PWhlYWRlciB2aWRlbyBidG49PT09PT0gXHJcbiAgXHJcbiAgLnZpZGVvX2J0biBidXR0b24ge1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgd2lkdGg6IDE1NHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIG1hcmdpbi1ib3R0b206IDZweDtcclxuICB9XHJcbiAgXHJcbiAgLnZpZGVvX2J0biBidXR0b24gaW1nIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICB3aWR0aDogNDVweDtcclxuICB9XHJcbiAgXHJcbiAgLy8gPT09PXN1YmplY3RfY2FyZCAvYm94X3NoYWRvdyBjc3Mgc3RhcnQ9PT09XHJcbiAgXHJcbiAgLy8gPT09Ym94X3NoYWRvdz09PVxyXG4gIFxyXG4gIC5ib3hfc2hhZG93e1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCAxMHB4ICNkNmQyZDI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDAgMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcclxuICBcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLy8gPT09c3ViamVjdF9jYXJkPT09PSBcclxuICBcclxuICAuc3ViamVjdF9jYXJkIHtcclxuICAgIGxpbmUtaGVpZ2h0OiA4cHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDVweCAxNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICBcclxuICAuc3ViamVjdF9jYXJkIGg0IHtcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gIH1cclxuICBcclxuICAvLz09PT09c3ViamVjdCBjYXJkIHN1YmplY3RfZGV0YWlscyBjc3M9PT09PSBcclxuICBcclxuICAuc3ViamVjdF9kZXRhaWxzIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgfVxyXG4gIFxyXG4gIC5zdWJqZWN0X2RldGFpbHMgcCB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLmdyYWRfZ3JlZW4sXHJcbiAgLmdyYWRfb3JhbmdlLFxyXG4gIC5ncmFkX3NreSB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gIH1cclxuXHJcbiAgLmJsdWVfZ3JhZGllbnRfYnRue1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCAjNjJkOWZmLCAjMWE4M2E0KTtcclxuICB9IFxyXG4gIC5vcmFuZ2VfZ3JhZGllbnRfYnRue1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCAjZmY5MjEyZDksICNmNWEyNGIpO1xyXG4gIH1cclxuICAucGlua19idG57XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNlNDViZmZkOSwgIzg3MWI5OClcclxuICB9XHJcbiAgLmdyZWVuX2dyYWRpZW50X2J0bntcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgIzU3YmMxNGQ5LCAjNDM4YzNjKTtcclxuICB9XHJcbiAgLnllbGxvd19ncmFkaWVudF9idG57XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsICNmYjVlNWUsICNjODA0MDQpO1xyXG4gIH1cclxuICBcclxuICAvLz09c3ViamVjdF9kZXRhaWxzPT1cclxuICBcclxuICAuY2xhc3NfZGF5cyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XHJcbiAgICBsaW5lLWhlaWdodDogOHB4O1xyXG4gIH1cclxuICBcclxuICAuY2xhc3NfZGF5cyBwIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNzI3MjcyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgXHJcbiAgLmNsYXNzX2RheXMgc3BhbiB7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIC5tYXJnaW5fZm9yX2NhcmR7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gIH1cclxuXHJcbiAgLm10LTUge1xyXG4gICAgICBtYXJnaW4tdG9wOiAxODBweDtcclxuICB9XHJcblxyXG4udGV4dC13aGl0ZSB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn0iXX0= */");

/***/ }),

/***/ 156:
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/studenthome/studenthome.page.html ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--===Ion-Header Start===-->\n<ion-header>\n  <ion-toolbar>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\">\n\n          <ion-buttons>\n             <ion-icon class='logout_btn color_violet' (click)=\"logoutAction()\" name=\"log-out-outline\"></ion-icon>\n          </ion-buttons>\n\n        </ion-col>\n        \n        <ion-col size=\"5\">\n\n          <p class=\"ion-text-center heading\">My Study Room</p>\n\n        </ion-col>\n\n        <ion-col size=\"4\">\n\n          <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n\n        </ion-col>\n\n      </ion-row>\n    </ion-grid>\n\n  </ion-toolbar>\n\n</ion-header>\n<!--===ion-header End-===-->\n<!--====ion-content Start====-->\n<ion-content>\n  <!--===home_page_student===-->\n  <div class=\"home_page_student\">\n    <div class=\"comman_page_padding\">\n    <!--====page_headings====-->\n    <div class=\"page_headings\">\n      <h1 class=\"color_violet\">Welcome</h1>\n      <h2 class=\"color_pink\">{{studentname | titlecase  }}</h2>\n    </div>\n    <div class=\"ion-text-center\" *ngIf=\"showEnrolled == false\">\n      <div  class='mt-5'>\n        <h1 class=\"color_violet \">\n          <a  [routerLink]=\"['/searchclass']\" class='btn_theme '>\n            <img src=\"../../assets/images/home_icon.png\"> Search a class\n          </a>\n        </h1>\n        <small class=\" \">No class yet !!!</small> \n      </div>\n    </div>\n    <!--====main div / box shadow====-->\n    <div *ngIf='showEnrolled == true'>\n      <div class=\"box_shadow\"  *ngFor='let class of allClasses.institute_assigned_class'>\n        <ion-row class=\"line_height\">\n          <ion-col class=\"ion-text-center standared\" size=\"12\">\n            <h3 class=\"color_pink comman_font\">{{class.name ?? ''}}</h3>\n            <!-- <p>By: Akash Institute</p> -->\n          </ion-col>\n          <!-- <ion-col size=\"12\" class=\"ion-text-center video_btn\">\n            <button class=\"grad_green\"><img src=\"../../assets/images/btn_red_icon.png\">Next Class on <br>08/08/2021</button>\n          </ion-col> -->\n        </ion-row>\n        \n        <div *ngFor='let subj of class.institute_assigned_class_subject'> \n          <div  class=\"subject_card {{subj.color_code ?? grad_orange}}\">\n            <a  [routerLink]=\"['/subject-detail-student']\" [queryParams]=\"{iacs:subj.id,subject:class.institute_id,purchased:1}\" class=\" text-white \">\n              {{subj.details ? subj.details.name : ''}}\n             \n              <h4 class=\"ion-text-center text-white \">{{subj.subject.name ?? ''}}</h4> \n              <div class=\"subject_details text-white \">\n                <div>\n                  <p>Board</p>\n                  <p>Attendance</p>\n                  <p>Percentage</p>\n                </div>\n                <div>\n                  <p>{{class.board ?? ''}}</p>\n                  <p>{{subj.total_absents_in_lectures ?? 0}} P | {{subj.total_attended_lectures ?? 0}} AB</p>\n                  <p>{{subj.percentage ?? 0}} %</p>\n                </div>\n              </div>\n            </a> \n          </div>\n        </div>\n        \n       <!--  <div class=\"subject_card grad_green\">\n          <h4 class=\"ion-text-center\">Hindi</h4>\n        \n          <div class=\"subject_details\">\n            <div>\n              <p>Next Class</p>\n              <p>Attendance</p>\n              <p>Percentage</p>\n            </div>\n            <div>\n              <p>Tuesday 6:00pm</p>\n              <p>7P | 3 AB</p>\n              <p>75%</p>\n            </div>\n          </div>\n        \n        </div> \n        <div class=\"subject_card grad_orange\">\n          <h4 class=\"ion-text-center\">English</h4>\n        \n          <div class=\"subject_details\">\n            <div>\n              <p>Next Class</p>\n              <p>Attendance</p>\n              <p>Percentage</p>\n            </div>\n            <div>\n              <p>Tuesday 6:00pm</p>\n              <p>7P | 3 AB</p>\n              <p>75%</p>\n            </div>\n          </div>\n        \n        </div> -->\n      \n        <div class=\"class_days\">\n          <div>\n            <p>Start <span>{{class.start_date | date: 'dd/MM/yyyy'}}</span></p>\n          </div>\n          <div>\n            <p>End <span> {{class.end_date | date: 'dd/MM/yyyy'}}</span></p>\n          </div>\n        </div>\n      </div>\n    </div>\n    </div>\n\n   \n    <!-- <div class=\"box_shadow margin_for_card\">\n      <ion-row>\n        <ion-col class=\"ion-text-center standared\" size=\"12\">\n          <h3 class=\"color_pink comman_font\">6th Standared</h3>\n          <p>By: Akash Institute</p>\n        </ion-col>\n        <ion-col size=\"12\" class=\"ion-text-center video_btn\">\n          <button class=\"grad_green\"><img src=\"../../assets/images/btn_red_icon.png\">Next Class on <br>08/08/2021</button>\n        </ion-col>\n      </ion-row>\n     \n      <div class=\"subject_card grad_sky\">\n        <h4 class=\"ion-text-center\">Science</h4>\n       \n        <div class=\"subject_details\">\n          <div>\n            <p>Next Class</p>\n            <p>Attendance</p>\n            <p>Percentage</p>\n          </div>\n          <div>\n            <p>Tuesday 6:00pm</p>\n            <p>7P | 3 AB</p>\n            <p>75%</p>\n          </div>\n        </div>\n     \n      </div>\n \n      <div class=\"subject_card grad_orange\">\n        <h4 class=\"ion-text-center\">English</h4>\n     \n        <div class=\"subject_details\">\n          <div>\n            <p>Next Class</p>\n            <p>Attendance</p>\n            <p>Percentage</p>\n          </div>\n          <div>\n            <p>Tuesday 6:00pm</p>\n            <p>7P | 3 AB</p>\n            <p>75%</p>\n          </div>\n        </div>\n    \n      </div>\n  \n    </div> -->\n    <!--===box_shadow close===-->\n  </div>\n  <!--======home_page_student Close========-->\n</ion-content>\n<!--==========ion-content End==========-->");

/***/ })

}]);
//# sourceMappingURL=src_app_studenthome_studenthome_module_ts.js.map