(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_subject-detail-student_subject-detail-student_module_ts"],{

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 3489:
/*!*********************************************************************************!*\
  !*** ./src/app/subject-detail-student/subject-detail-student-routing.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailStudentPageRoutingModule": () => (/* binding */ SubjectDetailStudentPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _subject_detail_student_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject-detail-student.page */ 5617);




const routes = [
    {
        path: '',
        component: _subject_detail_student_page__WEBPACK_IMPORTED_MODULE_0__.SubjectDetailStudentPage
    }
];
let SubjectDetailStudentPageRoutingModule = class SubjectDetailStudentPageRoutingModule {
};
SubjectDetailStudentPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SubjectDetailStudentPageRoutingModule);



/***/ }),

/***/ 5271:
/*!*************************************************************************!*\
  !*** ./src/app/subject-detail-student/subject-detail-student.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailStudentPageModule": () => (/* binding */ SubjectDetailStudentPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _subject_detail_student_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject-detail-student-routing.module */ 3489);
/* harmony import */ var _subject_detail_student_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject-detail-student.page */ 5617);







let SubjectDetailStudentPageModule = class SubjectDetailStudentPageModule {
};
SubjectDetailStudentPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject_detail_student_routing_module__WEBPACK_IMPORTED_MODULE_0__.SubjectDetailStudentPageRoutingModule
        ],
        declarations: [_subject_detail_student_page__WEBPACK_IMPORTED_MODULE_1__.SubjectDetailStudentPage]
    })
], SubjectDetailStudentPageModule);



/***/ }),

/***/ 5617:
/*!***********************************************************************!*\
  !*** ./src/app/subject-detail-student/subject-detail-student.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailStudentPage": () => (/* binding */ SubjectDetailStudentPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_subject_detail_student_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject-detail-student.page.html */ 8876);
/* harmony import */ var _subject_detail_student_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject-detail-student.page.scss */ 1926);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../previous-route.service */ 8735);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);











let SubjectDetailStudentPage = class SubjectDetailStudentPage {
    constructor(previousRouteService, router, alertController, storageService, homeService, route, toastService) {
        this.previousRouteService = previousRouteService;
        this.router = router;
        this.alertController = alertController;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.doubtsnotify = 0;
            this.purchased = 2;
            this.previousUrl = '/searchclass';
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.purchased = params['purchased'];
                if (this.purchased) {
                    this.previousUrl = '/studenthome';
                }
                if (this.subject && this.iacs && token) {
                    this.loadstudentdata(this.iacs, this.subject, token);
                }
            });
        });
    }
    loadstudentdata(iacs, subject, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (this.iacs && this.subject) {
                if (this.iacs && this.subject) {
                    yield this.homeService.loadstudentdata(iacs, subject, token).subscribe((res) => {
                        if (res.status == 200) {
                            this.syllabus = res.data.syllabus != '' ? res.data.syllabus : '';
                            this.getSubjectsInfo = res.getSubjectsInfo ? res.getSubjectsInfo : '';
                            this.iac = res.iac ? res.iac : '';
                            this.subjectname = res.subject ? res.subject : '';
                            this.i_a_c_s_id = res.i_a_c_s_id ? res.i_a_c_s_id : '';
                            this.teacher = res.teacher ? res.teacher : '';
                            this.class_time = res.class_time ? res.class_time : '';
                            this.video = res.data.video ? res.data.video : '';
                            console.log(this.class_time[0]);
                        }
                        /*
                         this.doubtsnotify = res.data.doubtsnotify ? res.data.doubtsnotify:0;
                          */
                    });
                }
            }
        });
    }
};
SubjectDetailStudentPage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_4__.PreviousRouteService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_3__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
SubjectDetailStudentPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-subject-detail-student',
        template: _raw_loader_subject_detail_student_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject_detail_student_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SubjectDetailStudentPage);



/***/ }),

/***/ 1926:
/*!*************************************************************************!*\
  !*** ./src/app/subject-detail-student/subject-detail-student.page.scss ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".page_content {\n  padding: 0 20px;\n}\n\nh1 {\n  font-size: 18px;\n  font-weight: 600;\n}\n\n.btn_view {\n  width: 201px;\n  height: 62px;\n  border-radius: 8px;\n  color: white;\n  font-size: 16px;\n  font-weight: 400;\n  text-align: center;\n  text-align: center;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto;\n}\n\n.btn_demo img {\n  padding-right: 8px;\n}\n\n.margin-t14 {\n  margin-top: 5px;\n}\n\n.purple_btns {\n  background-image: linear-gradient(to bottom, #644699, #b292e9);\n}\n\n.syllabus_btns button {\n  height: 44px;\n  width: 143px;\n  font-size: 16px;\n  font-weight: 400;\n  color: white;\n  border-radius: 8px;\n  margin-top: 10px;\n}\n\n.view_btn {\n  background: linear-gradient(to bottom, #F9922D, #F3C261);\n}\n\n.add_btn {\n  background: linear-gradient(to bottom, #FE8647, #FE6168);\n}\n\n.font_b {\n  color: #414141;\n}\n\n.card {\n  height: 70px;\n  width: 85%;\n  border-radius: 10px;\n  display: flex;\n  justify-content: space-evenly;\n}\n\n.text_white {\n  margin: 0;\n  margin: 0;\n  padding: 0;\n  line-height: 28px;\n  color: white;\n  font-size: 17px;\n  font-weight: bold;\n  text-align: center;\n}\n\n.card2 {\n  padding: 0;\n  line-height: 7px;\n  padding-left: 8px;\n}\n\n.day {\n  font-size: 14px;\n  color: #644699;\n}\n\n.time {\n  font-size: 12px;\n  color: #E03E91;\n}\n\n.card1 {\n  padding: 0;\n  background: linear-gradient(to bottom, #0FA8DD, #1386D3);\n}\n\n.card3 {\n  background: linear-gradient(to bottom, #F99A2F, #F9B435);\n}\n\n.card4 {\n  background: linear-gradient(to bottom, #8FDE01, #69B20C);\n}\n\n.card5 {\n  background: linear-gradient(to bottom, #FE6A5B, #FE7F49);\n}\n\n.comman_font {\n  font-size: 18px;\n  font-weight: 400 !important;\n}\n\n.resources_btns {\n  margin-bottom: 15px;\n}\n\n.resources_btns button {\n  display: block;\n  width: 95%;\n}\n\n.create {\n  height: 44px;\n  width: 143px;\n  font-size: 16px;\n  font-weight: 400;\n  color: white;\n  border-radius: 8px;\n  margin-top: 10px;\n  margin-left: 6px;\n  margin-bottom: 15px;\n}\n\np.text_white.mt-2 {\n  margin-top: 6px;\n}\n\nion-row.success_msg.md.hydrated {\n  background: linear-gradient(45deg, #8ad80363, #7fcb077a);\n  padding: 3px;\n  color: #375702;\n  border-radius: 5px;\n}\n\nion-row.teacher_.md.hydrated {\n  background: #faefd76b;\n  box-shadow: 3px 2px 5px 1px #b7b7b7;\n  border-radius: 4px;\n  padding: 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3QtZGV0YWlsLXN0dWRlbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZUFBQTtBQUFKOztBQUdBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0E7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FBREo7O0FBSUE7RUFDSSxrQkFBQTtBQURKOztBQUdBO0VBQ0ksZUFBQTtBQUFKOztBQUVBO0VBQ0ksOERBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFFQTtFQUNJLHdEQUFBO0FBQ0o7O0FBRUE7RUFDSSx3REFBQTtBQUNKOztBQUVBO0VBQ0ksY0FBQTtBQUNKOztBQUlBO0VBQ0ksWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUVBLGFBQUE7RUFDQSw2QkFBQTtBQUZKOztBQU9BO0VBQ0ksU0FBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFKSjs7QUFPQTtFQUNJLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBSko7O0FBT0E7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQUpKOztBQU9BO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFKSjs7QUFPQTtFQUNJLFVBQUE7RUFDQSx3REFBQTtBQUpKOztBQU9BO0VBQ0ksd0RBQUE7QUFKSjs7QUFPQTtFQUNJLHdEQUFBO0FBSko7O0FBT0E7RUFDSSx3REFBQTtBQUpKOztBQU9BO0VBQ0ksZUFBQTtFQUNBLDJCQUFBO0FBSko7O0FBT0E7RUFDSSxtQkFBQTtBQUpKOztBQU9BO0VBQ0ksY0FBQTtFQUNBLFVBQUE7QUFKSjs7QUFPQTtFQUNJLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBSko7O0FBT0E7RUFDSSxlQUFBO0FBSko7O0FBT0E7RUFDSSx3REFBQTtFQUdBLFlBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFOSjs7QUFTQTtFQUNJLHFCQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFOSiIsImZpbGUiOiJzdWJqZWN0LWRldGFpbC1zdHVkZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ucGFnZV9jb250ZW50e1xyXG4gICAgcGFkZGluZzogMCAyMHB4O1xyXG59XHJcblxyXG5oMXtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuXHJcbi5idG5fdmlld3tcclxuICAgIHdpZHRoOiAyMDFweDtcclxuICAgIGhlaWdodDogNjJweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAvL2JhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM2M2FhMTAsICM4ZmRlMDMpO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxufVxyXG5cclxuLmJ0bl9kZW1vIGltZ3tcclxuICAgIHBhZGRpbmctcmlnaHQ6IDhweDtcclxufVxyXG4ubWFyZ2luLXQxNHtcclxuICAgIG1hcmdpbi10b3A6NXB4O1xyXG59XHJcbi5wdXJwbGVfYnRucyB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNjQ0Njk5LCAjYjI5MmU5KTtcclxufVxyXG5cclxuLnN5bGxhYnVzX2J0bnMgYnV0dG9ue1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgd2lkdGg6IDE0M3B4O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi52aWV3X2J0bntcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNGOTkyMkQgLCAjRjNDMjYxKTtcclxufVxyXG5cclxuLmFkZF9idG57XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjRkU4NjQ3LCAjRkU2MTY4KTtcclxufVxyXG5cclxuLmZvbnRfYntcclxuICAgIGNvbG9yOiAjNDE0MTQxO1xyXG59XHJcblxyXG5cclxuXHJcbi5jYXJke1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG4gICAgd2lkdGg6IDg1JTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAvLyBiYWNrZ3JvdW5kOiByZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KCM3NEFCREQsICM3NEFCREQgNDkuOSUsICM0OThEQ0IgNTAuMSUsICM0OThEQ0IgMTAwJSk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XHJcbiAgICAvLyBib3gtc2hhZG93OiBibGFjayAwIDAgMjVweCAtMTNweDtcclxufVxyXG5cclxuXHJcbi50ZXh0X3doaXRlIHtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBsaW5lLWhlaWdodDogMjhweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uY2FyZDJ7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbGluZS1oZWlnaHQ6IDdweDtcclxuICAgIHBhZGRpbmctbGVmdDogOHB4O1xyXG59XHJcblxyXG4uZGF5eyBcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNjQ0Njk5O1xyXG59XHJcblxyXG4udGltZXtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjRTAzRTkxO1xyXG59XHJcblxyXG4uY2FyZDF7IFxyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMwRkE4REQsICMxMzg2RDMpOyBcclxufVxyXG5cclxuLmNhcmQze1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI0Y5OUEyRiwgI0Y5QjQzNSk7XHJcbn1cclxuXHJcbi5jYXJkNHtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM4RkRFMDEsICM2OUIyMEMpO1xyXG59XHJcblxyXG4uY2FyZDV7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjRkU2QTVCLCAjRkU3RjQ5KTtcclxufVxyXG5cclxuLmNvbW1hbl9mb250e1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucmVzb3VyY2VzX2J0bnN7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcblxyXG4ucmVzb3VyY2VzX2J0bnMgIGJ1dHRvbntcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLmNyZWF0ZXtcclxuICAgIGhlaWdodDogNDRweDtcclxuICAgIHdpZHRoOiAxNDNweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDZweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbnAudGV4dF93aGl0ZS5tdC0yIHtcclxuICAgIG1hcmdpbi10b3A6IDZweDtcclxufVxyXG5cclxuaW9uLXJvdy5zdWNjZXNzX21zZy5tZC5oeWRyYXRlZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoXHJcbjQ1ZGVnXHJcbiwgIzhhZDgwMzYzLCAjN2ZjYjA3N2EpO1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgY29sb3I6ICMzNzU3MDI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbmlvbi1yb3cudGVhY2hlcl8ubWQuaHlkcmF0ZWQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZhZWZkNzZiO1xyXG4gICAgYm94LXNoYWRvdzogM3B4IDJweCA1cHggMXB4ICNiN2I3Yjc7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBwYWRkaW5nOiA2cHg7XHJcbn0iXX0= */");

/***/ }),

/***/ 8876:
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subject-detail-student/subject-detail-student.page.html ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n      <ion-grid>\n          <ion-row>\n              <ion-col size=\"2\">\n                  <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button>\n              </ion-col>\n              <ion-col size=\"8\">\n                  <p class=\"ion-text-center heading\">{{iac ?? ''}}</p>\n              </ion-col>\n              <ion-col size=\"2\">\n                  <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n              </ion-col>\n          </ion-row>\n      </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"page_content\">\n    <div class=\"comman_page_padding\">\n      <h1 class=\"ion-text-center color_pink\">{{subjectname ?? ''}}</h1>\n      <h2 class=\"ion-text-center color_pink\"></h2>\n      <ion-row>\n          <ion-col class=\"btn_demo\">\n              <ion-button class='text-white' class=\"btn_view\"   href='{{video ?? \"\"}}'><img src=\"../../assets/images/btn_red_icon.png\"> View Demo </ion-button>\n          </ion-col>\n      </ion-row>\n\n      <ion-row class=\"syllabus_btns ion-text-center\">\n          <ion-col>\n              <ion-button href='{{syllabus ?? \"\"}}' class=\"view_btn\">View Syllabus</ion-button>\n          </ion-col>  \n      </ion-row>\n\n      <ion-row>\n          <ion-col size=\"8\">\n              <p class=\"comman_font color_violet\">Class Shedule</p>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <a class='link_subject '  [routerLink]=\"['/changetime']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><p class=\"comman_font font_b\">Class Time</p></a>\n          </ion-col>\n\n      </ion-row>\n\n\n      <!--ion row starts-->\n\n      <ion-row>\n          <ion-col *ngFor=\"let subjec of getSubjectsInfo; let i = index;\" size=\"6\">\n\n            <ion-card class=\"card\"> \n                <ion-col class=\"card1\" size=\"5\">\n                  <p class=\"text_white\">{{class_time[i] ??  ''}}</p>\n                </ion-col> \n                <ion-col class=\"card2\" size=\"7\">\n                  <p class=\"day\">{{subjec?.day}}</p>\n                  <!-- <p class=\"time\"></p> -->\n                </ion-col>\n              </ion-card>\n              <!-- <ion-card class=\"card\"> \n                  <ion-col class=\"card1 \" size=\"12\"> \n                      <p class=\"text_white mt-2 \">{{subjec?.day}}</p> \n                  </ion-col> \n              </ion-card>  -->\n\n          </ion-col> \n      </ion-row>\n     \n\n      <div>\n\n        <div>\n            <h2 class=\"color_violet comman_font resources\">Class Teacher</h2>\n            <ion-row class='teacher_'>\n                <ion-col class='ion-text-center'> \n                    <div *ngIf='teacher?.avatar'>\n                        <img  src=\"../assets/images/avatar_bottom_nav.png\">\n                    </div>\n                    <div class='teacher_card'>\n                        <h1 >{{teacher?.name}}</h1>\n                        <h3  >{{teacher?.qualifications}}</h3>\n                        <h4  >{{teacher?.experience ? 'Experience : '+teacher?.experience : ''}}</h4> \n                    </div>\n                </ion-col>\n            </ion-row>\n        </div>\n\n          <h2 class=\"color_violet comman_font resources\">Class Resources</h2> \n          <div *ngIf='purchased != 1'>\n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Live Classes</button>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <button  class=\"grad_yellow comman_btn common_anc_btn common_btn_shadow\">Lectures</button>\n                </ion-col> \n            </ion-row> \n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button  class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Assigments</button>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Doubts ({{doubtsnotify ?? ''}})</button>\n                </ion-col> \n            </ion-row> \n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button   class=\"grad_orange comman_btn common_anc_btn common_btn_shadow\">Test</button>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <button  class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Extra Classes</button>\n                </ion-col> \n            </ion-row>\n        </div>\n\n          <div *ngIf='purchased == 1'>\n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <a class='link_subject ' ><button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Live Classes</button></a>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <a class='link_subject '  [routerLink]=\"['/s-lectures']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><button  class=\"grad_yellow comman_btn common_anc_btn common_btn_shadow\">Lectures</button></a>\n                </ion-col> \n            </ion-row> \n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <a class='link_subject '  [routerLink]=\"['/s-assignments']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><button  class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Assigments</button></a>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <a class='link_subject '  [routerLink]=\"['/s-doubts']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Doubts ({{doubtsnotify ?? ''}})</button></a>\n                </ion-col> \n            </ion-row> \n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <a class='link_subject '  [routerLink]=\"['/s-test']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><button   class=\"grad_orange comman_btn common_anc_btn common_btn_shadow\">Test</button></a>\n                </ion-col> \n                <ion-col size=\"6\">\n                    <a class='link_subject '  [routerLink]=\"['/s-extraclasses']\" [queryParams]=\"{iacs:iacs,subject:subject}\" ><button  class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Extra Classes</button></a>\n                </ion-col> \n            </ion-row>\n            </div>\n\n\n          \n\n      </div>\n\n      <!-- <ion-row class='success_msg' *ngIf='loadsuccess'>{{loadsuccess}}</ion-row>\n      <button class=\"bg_color create common_anc_btn common_btn_shadow\" (click)=\"setText($event)\">Create</button> -->\n  </div>\n  </div>\n</ion-content>\n ");

/***/ })

}]);
//# sourceMappingURL=src_app_subject-detail-student_subject-detail-student_module_ts.js.map