(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_subject-detail_subject-detail_module_ts"],{

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 5164:
/*!*****************************************************************!*\
  !*** ./src/app/subject-detail/subject-detail-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailPageRoutingModule": () => (/* binding */ SubjectDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _subject_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject-detail.page */ 6569);




const routes = [
    {
        path: '',
        component: _subject_detail_page__WEBPACK_IMPORTED_MODULE_0__.SubjectDetailPage
    }
];
let SubjectDetailPageRoutingModule = class SubjectDetailPageRoutingModule {
};
SubjectDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SubjectDetailPageRoutingModule);



/***/ }),

/***/ 4761:
/*!*********************************************************!*\
  !*** ./src/app/subject-detail/subject-detail.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailPageModule": () => (/* binding */ SubjectDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _subject_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subject-detail-routing.module */ 5164);
/* harmony import */ var _subject_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject-detail.page */ 6569);







let SubjectDetailPageModule = class SubjectDetailPageModule {
};
SubjectDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subject_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.SubjectDetailPageRoutingModule
        ],
        declarations: [_subject_detail_page__WEBPACK_IMPORTED_MODULE_1__.SubjectDetailPage]
    })
], SubjectDetailPageModule);



/***/ }),

/***/ 6569:
/*!*******************************************************!*\
  !*** ./src/app/subject-detail/subject-detail.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubjectDetailPage": () => (/* binding */ SubjectDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_subject_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subject-detail.page.html */ 5212);
/* harmony import */ var _subject_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subject-detail.page.scss */ 8025);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../previous-route.service */ 8735);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);











let SubjectDetailPage = class SubjectDetailPage {
    constructor(previousRouteService, router, alertController, storageService, homeService, route, toastService) {
        this.previousRouteService = previousRouteService;
        this.router = router;
        this.alertController = alertController;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.toastService = toastService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.doubtsnotify = 0;
            this.previousUrl = '/homepage';
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject_id = params['subject'];
                this.istudent = params['istudent'];
                if (this.subject_id && this.iacs && token) {
                    /* if(this.istudent){
                      this.loadstudentdata(this.iacs,this.subject_id,token);
                    }else{ */
                    this.loaddata(this.iacs, this.subject_id, token);
                    /*  } */
                }
            });
        });
    }
    setText(e) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (this.notificat) {
                var notifytext = this.notificat;
                var iacs = this.iacs;
                if (iacs && notifytext) {
                    var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH);
                    var classid = this.iacs;
                    var newData = {
                        notifytext: notifytext,
                        iacs: iacs,
                        type: 'text',
                    };
                    yield this.homeService.creatnotify(newData, token).subscribe((res) => {
                        this.loadsuccess = res.msg;
                        setTimeout(() => {
                            this.loadsuccess = '';
                            this.notificat = '';
                        }, 5000);
                    });
                }
            }
        });
    }
    loaddata(iacs, subject_id, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (this.iacs && this.subject_id) {
                if (this.iacs && this.subject_id) {
                    yield this.homeService.openSubject(iacs, subject_id, token).subscribe((res) => {
                        this.syllabus = res.data.syllabus ? res.data.syllabus : '';
                        this.getSubjectsInfo = res.data.getSubjectsInfo ? res.data.getSubjectsInfo : '';
                        this.doubtsnotify = res.data.doubtsnotify ? res.data.doubtsnotify : 0;
                        this.class_days = res.data.class_days ? res.data.class_days : '';
                        this.iac = res.data.iac ? res.data.iac : '';
                        this.lecture_dates = res.data.lecture_dates ? res.data.lecture_dates : '';
                        this.subject = res.data.subject ? res.data.subject : '';
                        this.i_a_c_s_id = res.data.i_a_c_s_id ? res.data.i_a_c_s_id : '';
                    });
                }
            }
        });
    }
};
SubjectDetailPage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_4__.PreviousRouteService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_3__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
SubjectDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-subject-detail',
        template: _raw_loader_subject_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subject_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SubjectDetailPage);



/***/ }),

/***/ 8025:
/*!*********************************************************!*\
  !*** ./src/app/subject-detail/subject-detail.page.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".page_content {\n  padding: 0 20px;\n}\n\nh1 {\n  font-size: 18px;\n  font-weight: 600;\n}\n\n.btn_view {\n  width: 201px;\n  height: 62px;\n  border-radius: 8px;\n  color: white;\n  font-size: 16px;\n  font-weight: 400;\n  text-align: center;\n  text-align: center;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto;\n}\n\n.btn_demo img {\n  padding-right: 8px;\n}\n\n.margin-t14 {\n  margin-top: 5px;\n}\n\n.purple_btns {\n  background-image: linear-gradient(to bottom, #644699, #b292e9);\n}\n\n.syllabus_btns button {\n  height: 44px;\n  width: 143px;\n  font-size: 16px;\n  font-weight: 400;\n  color: white;\n  border-radius: 8px;\n  margin-top: 10px;\n}\n\n.view_btn {\n  background: linear-gradient(to bottom, #F9922D, #F3C261);\n}\n\n.add_btn {\n  background: linear-gradient(to bottom, #FE8647, #FE6168);\n}\n\n.font_b {\n  color: #414141;\n}\n\n.card {\n  height: 40px;\n  width: 85%;\n  border-radius: 10px;\n  display: flex;\n  justify-content: space-evenly;\n}\n\n.text_white {\n  margin: 0;\n  margin: 0;\n  padding: 0;\n  line-height: 28px;\n  color: white;\n  font-size: 17px;\n  font-weight: bold;\n  text-align: center;\n}\n\n.card2 {\n  padding: 0;\n  line-height: 7px;\n  padding-left: 8px;\n}\n\n.day {\n  font-size: 16px;\n  color: #644699;\n}\n\n.time {\n  font-size: 12px;\n  color: #E03E91;\n}\n\n.card1 {\n  padding: 0;\n  background: linear-gradient(to bottom, #0FA8DD, #1386D3);\n}\n\n.card3 {\n  background: linear-gradient(to bottom, #F99A2F, #F9B435);\n}\n\n.card4 {\n  background: linear-gradient(to bottom, #8FDE01, #69B20C);\n}\n\n.card5 {\n  background: linear-gradient(to bottom, #FE6A5B, #FE7F49);\n}\n\n.comman_font {\n  font-size: 18px;\n  font-weight: 400 !important;\n}\n\n.resources_btns {\n  margin-bottom: 15px;\n}\n\n.resources_btns button {\n  display: block;\n  width: 95%;\n}\n\n.create {\n  height: 44px;\n  width: 143px;\n  font-size: 16px;\n  font-weight: 400;\n  color: white;\n  border-radius: 8px;\n  margin-top: 10px;\n  margin-left: 6px;\n  margin-bottom: 15px;\n}\n\np.text_white.mt-2 {\n  margin-top: 6px;\n}\n\nion-row.success_msg.md.hydrated {\n  background: linear-gradient(45deg, #8ad80363, #7fcb077a);\n  padding: 3px;\n  color: #375702;\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmplY3QtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGVBQUE7QUFBSjs7QUFHQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUdBO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFFQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtBQURKOztBQUlBO0VBQ0ksa0JBQUE7QUFESjs7QUFHQTtFQUNJLGVBQUE7QUFBSjs7QUFFQTtFQUNJLDhEQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUE7RUFDSSx3REFBQTtBQUNKOztBQUVBO0VBQ0ksd0RBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7QUFDSjs7QUFJQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFFQSxhQUFBO0VBQ0EsNkJBQUE7QUFGSjs7QUFPQTtFQUNJLFNBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBSko7O0FBT0E7RUFDSSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUpKOztBQU9BO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFKSjs7QUFPQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FBSko7O0FBT0E7RUFDSSxVQUFBO0VBQ0Esd0RBQUE7QUFKSjs7QUFPQTtFQUNJLHdEQUFBO0FBSko7O0FBT0E7RUFDSSx3REFBQTtBQUpKOztBQU9BO0VBQ0ksd0RBQUE7QUFKSjs7QUFPQTtFQUNJLGVBQUE7RUFDQSwyQkFBQTtBQUpKOztBQU9BO0VBQ0ksbUJBQUE7QUFKSjs7QUFPQTtFQUNJLGNBQUE7RUFDQSxVQUFBO0FBSko7O0FBT0E7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUpKOztBQU9BO0VBQ0ksZUFBQTtBQUpKOztBQU9BO0VBQ0ksd0RBQUE7RUFHQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBTkoiLCJmaWxlIjoic3ViamVjdC1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5wYWdlX2NvbnRlbnR7XHJcbiAgICBwYWRkaW5nOiAwIDIwcHg7XHJcbn1cclxuXHJcbmgxe1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5cclxuLmJ0bl92aWV3e1xyXG4gICAgd2lkdGg6IDIwMXB4O1xyXG4gICAgaGVpZ2h0OiA2MnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIC8vYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzYzYWExMCwgIzhmZGUwMyk7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcblxyXG4uYnRuX2RlbW8gaW1ne1xyXG4gICAgcGFkZGluZy1yaWdodDogOHB4O1xyXG59XHJcbi5tYXJnaW4tdDE0e1xyXG4gICAgbWFyZ2luLXRvcDo1cHg7XHJcbn1cclxuLnB1cnBsZV9idG5zIHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM2NDQ2OTksICNiMjkyZTkpO1xyXG59XHJcblxyXG4uc3lsbGFidXNfYnRucyBidXR0b257XHJcbiAgICBoZWlnaHQ6IDQ0cHg7XHJcbiAgICB3aWR0aDogMTQzcHg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLnZpZXdfYnRue1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI0Y5OTIyRCAsICNGM0MyNjEpO1xyXG59XHJcblxyXG4uYWRkX2J0bntcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNGRTg2NDcsICNGRTYxNjgpO1xyXG59XHJcblxyXG4uZm9udF9ie1xyXG4gICAgY29sb3I6ICM0MTQxNDE7XHJcbn1cclxuXHJcblxyXG5cclxuLmNhcmR7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogODUlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIC8vIGJhY2tncm91bmQ6IHJlcGVhdGluZy1saW5lYXItZ3JhZGllbnQoIzc0QUJERCwgIzc0QUJERCA0OS45JSwgIzQ5OERDQiA1MC4xJSwgIzQ5OERDQiAxMDAlKTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuICAgIC8vIGJveC1zaGFkb3c6IGJsYWNrIDAgMCAyNXB4IC0xM3B4O1xyXG59XHJcblxyXG5cclxuLnRleHRfd2hpdGUge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyOHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jYXJkMntcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBsaW5lLWhlaWdodDogN3B4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiA4cHg7XHJcbn1cclxuXHJcbi5kYXl7IFxyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgY29sb3I6ICM2NDQ2OTk7XHJcbn1cclxuXHJcbi50aW1le1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICNFMDNFOTE7XHJcbn1cclxuXHJcbi5jYXJkMXsgXHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzBGQThERCwgIzEzODZEMyk7IFxyXG59XHJcblxyXG4uY2FyZDN7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjRjk5QTJGLCAjRjlCNDM1KTtcclxufVxyXG5cclxuLmNhcmQ0e1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzhGREUwMSwgIzY5QjIwQyk7XHJcbn1cclxuXHJcbi5jYXJkNXtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNGRTZBNUIsICNGRTdGNDkpO1xyXG59XHJcblxyXG4uY29tbWFuX2ZvbnR7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5yZXNvdXJjZXNfYnRuc3tcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbi5yZXNvdXJjZXNfYnRucyAgYnV0dG9ue1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB3aWR0aDogOTUlO1xyXG59XHJcblxyXG4uY3JlYXRle1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG4gICAgd2lkdGg6IDE0M3B4O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG5cclxucC50ZXh0X3doaXRlLm10LTIge1xyXG4gICAgbWFyZ2luLXRvcDogNnB4O1xyXG59XHJcblxyXG5pb24tcm93LnN1Y2Nlc3NfbXNnLm1kLmh5ZHJhdGVkIHtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcclxuNDVkZWdcclxuLCAjOGFkODAzNjMsICM3ZmNiMDc3YSk7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgICBjb2xvcjogIzM3NTcwMjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 5212:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subject-detail/subject-detail.page.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n    <ion-toolbar>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"2\">\n                    <ion-back-button defaultHref=\"{{previousUrl}}\" class=\"color_violet\"></ion-back-button>\n                </ion-col>\n                <ion-col size=\"8\">\n                    <p class=\"ion-text-center heading\">{{iac?.name}}</p>\n                </ion-col>\n                <ion-col size=\"2\">\n                    <div class=\"avatar_icon\" (click)=\"presentPopover('any')\"></div>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"page_content\">\n\n        <h1 class=\"ion-text-center color_pink\">{{subject?.name}}</h1>\n        <h2 class=\"ion-text-center color_pink\"></h2>\n        <ion-row>\n            <ion-col class=\"btn_demo\">\n                <ion-button class='text-white' class=\"btn_view\"   href='{{iac?.video}}'><img src=\"../../assets/images/btn_red_icon.png\"> View Demo </ion-button>\n            </ion-col>\n        </ion-row>\n\n        <ion-row class=\"syllabus_btns ion-text-center\">\n            <ion-col>\n                <ion-button href='{{syllabus ?? \"\"}}' class=\"view_btn\">View Syllabus</ion-button>\n            </ion-col>\n\n            <ion-col>\n                <ion-input class='margin-t14' type=\"file\" accept=\"image/*\" (change)=\"changeListener($event)\"></ion-input>\n            </ion-col>\n\n\n        </ion-row>\n\n        <ion-row>\n            <ion-col size=\"8\">\n                <p class=\"comman_font color_violet\">Class Shedule</p>\n            </ion-col>\n\n            <ion-col size=\"4\">\n                <!--  <p class=\"comman_font font_b\">View All</p> -->\n            </ion-col>\n\n        </ion-row>\n\n\n        <!--ion row starts-->\n\n        <ion-row>\n            <ion-col *ngFor=\"let subjec of getSubjectsInfo;\" size=\"6\">\n\n                <ion-card class=\"card\">\n\n                    <ion-col class=\"card1 \" size=\"12\">\n\n                        <p class=\"text_white mt-2 \">{{subjec?.day}}</p>\n\n                    </ion-col>\n\n                    <!--   <ion-col class=\"card2\" size=\"7\">\n            <p class=\"day\"></p>\n            <p class=\"time\">10:00 Am</p>\n          </ion-col> -->\n                </ion-card>\n                <!--.card-->\n\n\n            </ion-col>\n\n            <!--  <ion-col size=\"6\">\n\n        <ion-card class=\"card\">\n          <ion-col class=\"card3\" size=\"5\">\n\n            <p class=\"text_white\">27 <br> july</p>\n\n          </ion-col>\n\n          <ion-col class=\"card2\" size=\"7\">\n            <p class=\"day\">Tuesday</p>\n            <p class=\"time\">10:00 Am</p>\n          </ion-col>\n        </ion-card> \n\n      </ion-col> -->\n\n        </ion-row>\n        <!--ion-row Ends-->\n\n\n\n        <!---ion row Starts-->\n        <!-- <ion-row>\n      <ion-col size=\"6\">\n\n        <ion-card class=\"card\">\n          <ion-col class=\"card4\" size=\"5\">\n\n            <p class=\"text_white\">26 <br> july</p>\n\n          </ion-col>\n\n          <ion-col class=\"card2\" size=\"7\">\n            <p class=\"day\">Monday</p>\n            <p class=\"time\">10:00 Am</p>\n          </ion-col>\n        </ion-card> \n\n\n      </ion-col>\n\n      <ion-col size=\"6\">\n\n        <ion-card class=\"card\">\n          <ion-col class=\"card5\" size=\"5\">\n\n            <p class=\"text_white\">27 <br> july</p>\n\n          </ion-col>\n\n          <ion-col class=\"card2\" size=\"7\">\n            <p class=\"day\">Tuesday</p>\n            <p class=\"time\">10:00 Am</p>\n          </ion-col>\n        </ion-card> \n\n      </ion-col>\n\n    </ion-row> -->\n        <!--ion-row Ends-->\n\n        <div>\n            <h2 class=\"color_violet comman_font resources\">Class Resources</h2>\n\n\n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Live Classes</button>\n                </ion-col>\n\n                <ion-col size=\"6\">\n                    <button [routerLink]=\"['/lectures']\" [queryParams]=\"{iacs:iacs,subject:subject_id}\" class=\"grad_yellow comman_btn common_anc_btn common_btn_shadow\">Lectures</button>\n                </ion-col>\n\n            </ion-row>\n\n\n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button [routerLink]=\"['/assignments']\" [queryParams]=\"{iacs:iacs,subject:subject_id}\" class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Assigments</button>\n                </ion-col>\n\n                <ion-col size=\"6\">\n                    <button class=\"grad_sky comman_btn common_anc_btn common_btn_shadow\">Doubts ({{doubtsnotify ?? ''}})</button>\n                </ion-col>\n\n            </ion-row>\n\n            <ion-row class=\"resources_btns\">\n                <ion-col size=\"6\">\n                    <button [routerLink]=\"['/test']\" [queryParams]=\"{iacs:iacs,subject:subject_id}\" class=\"grad_orange comman_btn common_anc_btn common_btn_shadow\">Test</button>\n                </ion-col>\n\n                <ion-col size=\"6\">\n                    <button [routerLink]=\"['/extraclass']\" [queryParams]=\"{iacs:iacs,subject:subject_id}\" class=\"grad_green comman_btn common_anc_btn common_btn_shadow\">Extra Classes</button>\n                </ion-col>\n\n            </ion-row>\n\n\n            <ion-row>\n                <ion-col>\n                    <ion-label class=\"comman_font color_violet \">Class Notification</ion-label>\n                    <!-- <ion-textarea  class=\"text_area\"></ion-textarea> -->\n                    <ion-textarea [(ngModel)]=\"notificat\" class=\"text_area\"></ion-textarea>\n                </ion-col>\n            </ion-row>\n\n        </div>\n\n        <ion-row class='success_msg' *ngIf='loadsuccess'>{{loadsuccess}}</ion-row>\n        <button class=\"bg_color create common_anc_btn common_btn_shadow\" (click)=\"setText($event)\">Create</button>\n    </div>\n</ion-content>\n<!-- <ion-content>\n  <ion-row >\n    <ion-title><h4 >{{iac?.name}}</h4></ion-title>\n    <ion-item> \n      <a href='{{iac?.video}}'><ion-button>Demo</ion-button></a>\n      <ion-label >Add Syllabus :</ion-label>\n      <ion-input type=\"file\" accept=\"image/*\" (change)=\"changeListener($event)\"></ion-input>\n    </ion-item>\n  </ion-row>\n  \n  <ion-card  width='100%'> \n    <ion-card-header>Class Schedule</ion-card-header> \n    <ion-row >\n      <ion-button *ngFor=\"let subjec of getSubjectsInfo;\">{{subjec?.day}}</ion-button>\n    </ion-row>\n    <ion-item-divider  ></ion-item-divider>\n    <ion-card-header>Class Resources :</ion-card-header>\n    <ion-row >\n      <ion-button [routerLink]=\"['/lectures']\" [queryParams]=\"{iacs:i_a_c_s_id}\">Lectures</ion-button>\n      <ion-button >Assignments</ion-button>\n      <ion-button >Doubts ({{doubtsnotify}})</ion-button>\n      <ion-button >Test</ion-button>\n      <ion-button >Extra Classes</ion-button>\n    </ion-row>\n    <ion-row >\n      <ion-item>\n        <ion-label >Class Notification :</ion-label>\n        <ion-input placeholder='Type Notification Here' type=\"text\" ></ion-input>\n      </ion-item>\n    </ion-row>\n  </ion-card> \n</ion-content>\n -->");

/***/ })

}]);
//# sourceMappingURL=src_app_subject-detail_subject-detail_module_ts.js.map