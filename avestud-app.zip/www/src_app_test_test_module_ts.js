(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_test_test_module_ts"],{

/***/ 3264:
/*!******************************************!*\
  !*** ./src/app/services/home.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeService": () => (/* binding */ HomeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);




let HomeService = class HomeService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    getClassRoom(token) {
        return this.httpService.get('institute', token);
    }
    openAssignments(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignments', postData, token);
    }
    createAssigment(data, token) {
        return this.httpService.gettrip('createAssignments', data, token);
    }
    publishAssigment(data, token) {
        return this.httpService.gettrip('publishAssigment', data, token);
    }
    openSubject(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('inst_detail', postData, token);
    }
    loadstudentdata(iacs, subject, token) {
        var postData = {
            iacs: iacs,
            subject: subject,
        };
        return this.httpService.gettrip('loadstudentdata', postData, token);
    }
    openLecture(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('lectures', postData, token);
    }
    openExtraclass(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('extraclass', postData, token);
    }
    getClassunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getClassunits', postData, token);
    }
    getAssignmentunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getAssignmentunits', postData, token);
    }
    getTestunits(iacs, token) {
        var postData = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTestunits', postData, token);
    }
    getTests(iacs, token) {
        var data = {
            iacs: iacs,
        };
        return this.httpService.gettrip('getTests', data, token);
    }
    createLecture(postData, token) {
        return this.httpService.postWithImg('createLecture', postData, token);
    }
    createExtraClass(postData, token) {
        return this.httpService.postWithImg('createExtraclass', postData, token);
    }
    delLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delLecture', data, token);
    }
    delExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delExtraClass', data, token);
    }
    delAssignment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('delAssignments', data, token);
    }
    deltest(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.delLecture('deltest', data, token);
    }
    getLecture(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getLecture', data, token);
    }
    getExtraClass(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getExtraClass', data, token);
    }
    getSAssigment(id, token) {
        var data = {
            id: id,
        };
        return this.httpService.gettrip('getSAssigment', data, token);
    }
    enrollments(iacs, subject_id, token) {
        var data = {
            iacs: iacs,
            subject: subject_id,
        };
        return this.httpService.gettrip('enrollments', data, token);
    }
    creatnotify(data, token) {
        return this.httpService.gettrip('creatnotify', data, token);
    }
    createAssigmentQuestion(data, token) {
        return this.httpService.createAssigmentQuestion('addAssignmentQuestion', data, token);
    }
    createTest(data, token) {
        return this.httpService.gettrip('createTest', data, token);
    }
    getQuestions(id, token) {
        return this.httpService.gettrip('getQuestions', id, token);
    }
    createAssigmentUnit(data, token) {
        return this.httpService.gettrip('createAssigmentUnit', data, token);
    }
    createTestUnit(data, token) {
        return this.httpService.gettrip('createTestUnit', data, token);
    }
};
HomeService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
HomeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 1764:
/*!*********************************************!*\
  !*** ./src/app/test/test-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TestPageRoutingModule": () => (/* binding */ TestPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _test_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./test.page */ 6103);




const routes = [
    {
        path: '',
        component: _test_page__WEBPACK_IMPORTED_MODULE_0__.TestPage
    }
];
let TestPageRoutingModule = class TestPageRoutingModule {
};
TestPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TestPageRoutingModule);



/***/ }),

/***/ 6615:
/*!*************************************!*\
  !*** ./src/app/test/test.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TestPageModule": () => (/* binding */ TestPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _test_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./test-routing.module */ 1764);
/* harmony import */ var _test_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./test.page */ 6103);







let TestPageModule = class TestPageModule {
};
TestPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _test_routing_module__WEBPACK_IMPORTED_MODULE_0__.TestPageRoutingModule
        ],
        declarations: [_test_page__WEBPACK_IMPORTED_MODULE_1__.TestPage]
    })
], TestPageModule);



/***/ }),

/***/ 6103:
/*!***********************************!*\
  !*** ./src/app/test/test.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TestPage": () => (/* binding */ TestPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_test_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./test.page.html */ 5679);
/* harmony import */ var _test_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./test.page.scss */ 8909);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/home.service */ 3264);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);
/* harmony import */ var _previous_route_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../previous-route.service */ 8735);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);











let TestPage = class TestPage {
    constructor(previousRouteService, storageService, homeService, route, alertCtrl, toastService) {
        this.previousRouteService = previousRouteService;
        this.storageService = storageService;
        this.homeService = homeService;
        this.route = route;
        this.alertCtrl = alertCtrl;
        this.toastService = toastService;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            this.route.queryParams.subscribe(params => {
                this.iacs = params['iacs'];
                this.subject = params['subject'];
                this.getTests(this.iacs, token);
                this.previousUrl = 'subject-detail?iacs=' + this.iacs + '&subject=' + this.subject;
            });
        });
    }
    toggleShow(unit) {
        if (unit) {
            this.showUnitFor = unit;
        }
        else {
            this.showUnitFor = '';
        }
    }
    getTests(iacs, token) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            if (iacs && token) {
                yield this.homeService.getTests(iacs, token).subscribe((res) => {
                    if (res.status == 200) {
                        this.testAll = res.topics ? res.topics : '';
                        this.testWithoutClass = res.assignmet_w_n_t ? res.assignmet_w_n_t : '';
                    }
                    else {
                        this.testAll = [];
                        this.testWithoutClass = [];
                        this.noTest = true;
                    }
                });
            }
        });
    }
    presentAlert(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            var token = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_4__.AuthConstants.AUTH);
            var toast = this.toastService;
            var serv_home = this.homeService;
            var mainthis = this;
            function delete_l(id) {
                serv_home.deltest(id, token).subscribe((res) => {
                    mainthis.getTests(mainthis.iacs, token);
                });
            }
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Confirm!',
                message: 'Are you sure you want to delete this !!!',
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                        }
                    }, {
                        text: 'Yes',
                        handler: function () {
                            delete_l(id);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
TestPage.ctorParameters = () => [
    { type: _previous_route_service__WEBPACK_IMPORTED_MODULE_5__.PreviousRouteService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService },
    { type: _services_home_service__WEBPACK_IMPORTED_MODULE_3__.HomeService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
TestPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-test',
        template: _raw_loader_test_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_test_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TestPage);



/***/ }),

/***/ 8909:
/*!*************************************!*\
  !*** ./src/app/test/test.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".test {\n  padding: 0 12px;\n}\n\nh3 {\n  font-size: 16px;\n  font-weight: 500;\n  margin-bottom: 0;\n}\n\n.color_pink {\n  font-size: 16px;\n  font-weight: 500;\n}\n\n.test_section {\n  border-radius: 14px;\n  padding: 0 15px;\n  line-height: 15px;\n  margin-bottom: 20px;\n  box-shadow: 2px 2px 14px #ccc7c7;\n  margin-top: 22px;\n}\n\n.row_assignment {\n  display: flex;\n  justify-content: space-between;\n}\n\n.box {\n  box-sizing: border-box;\n}\n\n.box1 {\n  width: 38%;\n}\n\n.box2 {\n  display: flex;\n  justify-content: space-between;\n  width: 55%;\n}\n\n.box2 img {\n  padding: 16px 3px;\n  height: 49px;\n}\n\n.publish_btn {\n  width: 104px;\n  height: 31px;\n  color: white;\n  font-size: 10px;\n  font-weight: 500;\n  background-color: #00c43b;\n  border-radius: 5px;\n  margin-top: 15px;\n  line-height: 13px;\n}\n\n.No_publish_btn {\n  width: 104px;\n  height: 31px;\n  color: white;\n  font-size: 10px;\n  font-weight: 500;\n  background-color: #ff4f4f;\n  border-radius: 5px;\n  margin-top: 15px;\n  line-height: 13px;\n}\n\n.details_sec p {\n  font-size: 12px;\n  color: #646464;\n  font-weight: 400;\n  padding-right: 15px;\n}\n\n.question_section ion-col {\n  margin-bottom: 0;\n}\n\n.question_section ion-col span {\n  line-height: 0;\n  font-size: 14px;\n  color: #414141;\n}\n\n.assignment_btns {\n  display: flex;\n  justify-content: space-between;\n}\n\n.assignment_btns button {\n  width: 114px;\n  height: 36px;\n  color: white;\n  font-size: 12px;\n  font-weight: 400;\n  border-radius: 6px;\n  margin: 15px 0;\n}\n\n.d-flex {\n  display: flex;\n  justify-content: space-between;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVFO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFFRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQUNKOztBQUVFO0VBQ0Usc0JBQUE7QUFDSjs7QUFFRTtFQUNFLFVBQUE7QUFDSjs7QUFFRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFVBQUE7QUFDSjs7QUFFRTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUdFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFBSjs7QUFHRTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFHRTtFQUNFLGdCQUFBO0FBQUo7O0FBR0U7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFBSjs7QUFHRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQUFKOztBQUdFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBQUo7O0FBRUU7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7QUFDSiIsImZpbGUiOiJ0ZXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50ZXN0IHtcclxuICAgIHBhZGRpbmc6IDAgMTJweDtcclxuICB9XHJcbiAgXHJcbiAgaDMge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5jb2xvcl9waW5rIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgfVxyXG4gIFxyXG4gIC50ZXN0X3NlY3Rpb24ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgIHBhZGRpbmc6IDAgMTVweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIGJveC1zaGFkb3c6IDJweCAycHggMTRweCAjY2NjN2M3O1xyXG4gICAgbWFyZ2luLXRvcDogMjJweDtcclxuICB9XHJcblxyXG4gIC5yb3dfYXNzaWdubWVudHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgfVxyXG4gIFxyXG4gIC5ib3gge1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICB9XHJcbiAgXHJcbiAgLmJveDEge1xyXG4gICAgd2lkdGg6IDM4JTtcclxuICB9XHJcbiAgXHJcbiAgLmJveDJ7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgd2lkdGg6IDU1JTtcclxuICB9XHJcbiAgXHJcbiAgLmJveDIgaW1nIHtcclxuICAgIHBhZGRpbmc6IDE2cHggM3B4O1xyXG4gICAgaGVpZ2h0OiA0OXB4O1xyXG4gIH1cclxuIFxyXG4gIFxyXG4gIC5wdWJsaXNoX2J0biB7XHJcbiAgICB3aWR0aDogMTA0cHg7XHJcbiAgICBoZWlnaHQ6IDMxcHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwYzQzYjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMTNweDtcclxuICB9XHJcbiAgXHJcbiAgLk5vX3B1Ymxpc2hfYnRuIHtcclxuICAgIHdpZHRoOiAxMDRweDtcclxuICAgIGhlaWdodDogMzFweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY0ZjRmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTVweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxM3B4O1xyXG4gIH1cclxuICBcclxuICAuZGV0YWlsc19zZWMgcCB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBjb2xvcjogIzY0NjQ2NDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxNXB4O1xyXG4gIH1cclxuICBcclxuICAucXVlc3Rpb25fc2VjdGlvbiBpb24tY29sIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC5xdWVzdGlvbl9zZWN0aW9uIGlvbi1jb2wgc3BhbiB7XHJcbiAgICBsaW5lLWhlaWdodDogMDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNDE0MTQxO1xyXG4gIH1cclxuICBcclxuICAuYXNzaWdubWVudF9idG5zIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgfVxyXG4gIFxyXG4gIC5hc3NpZ25tZW50X2J0bnMgYnV0dG9uIHtcclxuICAgIHdpZHRoOiAxMTRweDtcclxuICAgIGhlaWdodDogMzZweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBtYXJnaW46IDE1cHggMDsgXHJcbiAgfVxyXG4gIC5kLWZsZXh7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIH0iXX0= */");

/***/ }),

/***/ 5679:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/test/test.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n    <ion-toolbar>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-buttons>\n                        <ion-back-button defaultHref=\"{{previousUrl ?? ''}}\" class=\"color_violet\"></ion-back-button>\n                    </ion-buttons>\n                </ion-col>\n                <ion-col size=\"5\">\n                    <p class=\"ion-text-center heading\">Test</p>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <div class=\"avatar_icon\"></div>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"comman_page_padding \">\n    <div class=\"test \">\n        <!--page_tittle and add button-->\n        <!-- <ion-row>\n            <ion-col size=\"8\">\n                <h1 class=\"color_violet page_tittle\">Test</h1>\n            </ion-col>\n            <ion-col size=\"2\">\n                <div class=\"btn_theme\">\n                    <button [routerLink]=\"['/add-test']\" [queryParams]=\"{iacs:iacs,subject:subject}\">Add</button>\n                </div> \n            </ion-col>\n            <ion-col size=\"2\">\n                <div class=\"btn_theme\">\n                    <button [routerLink]=\"['/add-test-unit']\" [queryParams]=\"{iacs:iacs,subject:subject}\"> Add Unit</button>\n                </div>\n            </ion-col>\n        </ion-row> -->\n        <ion-row>\n            <ion-col size=\"12\" class='d-flex'>\n                <h1 class=\"color_violet page_tittle\">Test</h1> \n                <div class=\"text-right\">\n                    <div class=\"btn_theme\">\n                        <button [routerLink]=\"['/add-test']\" [queryParams]=\"{iacs:iacs,subject:subject,type:test}\">Add</button> \n                    &nbsp;&nbsp; \n                        <button [routerLink]=\"['/add-test-unit']\" [queryParams]=\"{iacs:iacs,subject:subject,type:test}\"> Add Unit</button>\n                    </div>\n                </div>\n            </ion-col>\n        </ion-row>\n        <!--row_unit start-->\n        <ion-row class=\"row_unit\">\n            <ion-col (click)=\"toggleShow()\" id=\"{{!showUnitFor ? 'theme_shadow' :''}}\" >\n                <p > All</p>\n            </ion-col>\n            <ion-col  id=\"{{showUnitFor == 'old' ? 'theme_shadow' :''}}\">\n                <p (click)=\"toggleShow('old')\">Old</p>\n            </ion-col> \n            <ion-col *ngFor=\"let assign of testAll;\" id=\"{{showUnitFor == assign.name ? 'theme_shadow' :''}}\">\n                <p (click)=\"toggleShow(assign.name)\">{{assign.name | titlecase}}</p>\n            </ion-col> \n        </ion-row>\n        <!--row_unit End-->\n        <!--test_section start-->\n        <div class=\"\" *ngFor=\"let assign of testAll;\">\n\n            <div  *ngIf=\"showUnitFor == assign.name || !showUnitFor\">\n                <h2 class=\"text-center\">{{assign.name | titlecase}}</h2>\n                <div class=\"test_section bg_light_yellow\" *ngFor=\"let topicsAll of assign.topics;\">\n                    <!--row_assignment-->\n\n                    <ion-row class=\"row_assignment\">\n                        <div class=\"box box1\">\n                            <h2 class=\"color_pink\">{{topicsAll.title | titlecase}}</h2>\n                        </div>\n                        <div class=\"box box2 ion-text-center\">\n                            <div>\n                                <a [routerLink]=\"['/add-assignment']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\"><img src=\"../../assets/images/edit_icon.png\" alt=\"\"></a>\n                            </div>\n                            <div>\n                                <a (click)=\"presentAlert(topicsAll.id)\"> <img src=\"../../assets/images/delete_icon.png\" alt=\"\"></a>\n                            </div>\n\n                            <button [routerLink]=\"['/publish-assignment']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\"  class=\"{{topicsAll.publish_date ? 'publish_btn' : 'No_publish_btn'}}\">  {{topicsAll.publish_date ? 'Published on '+topicsAll.publish_date : 'Not Published'}}  </button>\n                        </div>\n                    </ion-row>\n                    <!--details_sec-->\n                    <ion-row class=\"details_sec\">\n                        <p>{{topicsAll.description}}</p>\n                    </ion-row>\n                    <!--question_section start-->\n                    <div>\n                        <ion-row class=\"question_section\">\n                            <ion-col size=\"8\">\n                                <span>Per Question Mark</span>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                                <span>{{topicsAll.per_q_mark}}</span>\n                            </ion-col>\n                            <ion-col size=\"8\">\n                                <span>Total Questions</span>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                                <span>{{topicsAll.totalQuestions}}</span>\n                            </ion-col>\n                            <ion-col size='8'>\n                                <span>Time Duration</span>\n                            </ion-col>\n                            <ion-col size='4'>\n                                <span>{{topicsAll.timer}}</span>\n                            </ion-col>\n                        </ion-row>\n                    </div>\n                    <!--question_section End-->\n                    <!--assignment_btns-->\n                    <div class=\"assignment_btns\">\n                        <button [routerLink]=\"['/list-question']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\" class=\"bg_color add_q\">Add Question</button>\n                        <button class=\"show_r bg_color_p\">Show Reports</button>\n                    </div>\n                    <!--assignment_btns closer-->\n                </div>\n            </div>\n        </div>\n\n        <div  *ngIf=\"showUnitFor == 'old' || !showUnitFor\" > \n            <hr>\n            <h2 *ngIf=\"testWithoutClass\" class=\"text-center\">Old Test</h2>\n        <div *ngFor=\"let topicsAll of testWithoutClass;\"> \n            <div  >\n                <div class=\"test_section bg_light_yellow\"  >\n                    <!--row_assignment-->\n\n                    <ion-row class=\"row_assignment\">\n                        <div class=\"box box1\">\n                            <h2 class=\"color_pink\">{{topicsAll.title | titlecase}}</h2>\n                        </div>\n                        <div class=\"box box2 ion-text-center\">\n                            <div>\n                                <a [routerLink]=\"['/add-assignment']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\"><img src=\"../../assets/images/edit_icon.png\" alt=\"\"></a>\n                            </div>\n                            <div>\n                                <a (click)=\"presentAlert(topicsAll.id)\"> <img src=\"../../assets/images/delete_icon.png\" alt=\"\"></a>\n                            </div>\n\n                            <button [routerLink]=\"['/publish-assignment']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\"  class=\"{{topicsAll.publish_date ? 'publish_btn' : 'No_publish_btn'}}\">  {{topicsAll.publish_date ? 'Published on '+topicsAll.publish_date : 'Not Published'}}  </button>\n                        </div>\n                    </ion-row>\n                    <!--details_sec-->\n                    <ion-row class=\"details_sec\">\n                        <p>{{topicsAll.description}}</p>\n                    </ion-row>\n                    <!--question_section start-->\n                    <div>\n                        <ion-row class=\"question_section\">\n                            <ion-col size=\"8\">\n                                <span>Per Question Mark</span>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                                <span>{{topicsAll.per_q_mark}}</span>\n                            </ion-col>\n                            <ion-col size=\"8\">\n                                <span>Total Questions</span>\n                            </ion-col>\n                            <ion-col size=\"4\">\n                                <span>{{topicsAll.totalQuestions}}</span>\n                            </ion-col>\n                            <ion-col size='8'>\n                                <span>Time Duration</span>\n                            </ion-col>\n                            <ion-col size='4'>\n                                <span>{{topicsAll.timer}}</span>\n                            </ion-col>\n                        </ion-row>\n                    </div>\n                    <!--question_section End-->\n                    <!--assignment_btns-->\n                    <div class=\"assignment_btns\">\n                        <button [routerLink]=\"['/list-question']\" [queryParams]=\"{iacs:iacs,subject:subject,assignment_id: topicsAll.id,type:'test'}\" class=\"bg_color add_q\">Add Question</button>\n                        <button class=\"show_r bg_color_p\">Show Reports</button>\n                    </div>\n                    <!--assignment_btns closer-->\n                </div>\n            </div>\n        </div>\n        </div>\n\n        <!--test_section End-->\n    </div>\n    </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_test_test_module_ts.js.map