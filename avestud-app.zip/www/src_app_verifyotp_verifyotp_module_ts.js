(self["webpackChunkavestud_app"] = self["webpackChunkavestud_app"] || []).push([["src_app_verifyotp_verifyotp_module_ts"],{

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);







let AuthService = class AuthService {
    constructor(httpService, storageService, router) {
        this.httpService = httpService;
        this.storageService = storageService;
        this.router = router;
        this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getUserData() {
        this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next(res);
        });
    }
    login(postData) {
        return this.httpService.post('login', postData);
    }
    signup(postData) {
        return this.httpService.post('signup', postData);
    }
    register_student(postData) {
        return this.httpService.post('register_student', postData);
    }
    resendOtp(postData) {
        return this.httpService.post('resendOtp', postData);
    }
    logout() {
        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_2__.AuthConstants.AUTH).then(res => {
            this.userData$.next('');
            window.location.href = 'homepage';
            //this.router.navigate(['/']);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 6858:
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HttpService": () => (/* binding */ HttpService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
    }
    post(serviceName, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        const options = { headers: headers, withCredintials: false };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    get(serviceName, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.get(url, options);
    }
    gettrip(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, JSON.stringify(data), options);
    }
    delLecture(serviceName, data, token) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Authorization': 'Bearer ' + token
        });
        const formDatas = new FormData();
        formDatas.append('id', data.id);
        const options = { headers };
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        return this.http.post(url, formDatas, options);
    }
    postWithImg(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('unit', data.unit);
        formDatas.append('number', data.number);
        formDatas.append('lecturename', data.lecturename);
        formDatas.append('date', data.date);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.notes) {
            formDatas.append('notes', data.notes);
        }
        if (data.video) {
            formDatas.append('video', data.video);
        }
        formDatas.append('i_assigned_class_subject_id', data.i_assigned_class_subject_id);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
    createAssigmentQuestion(serviceName, data, token) {
        const formDatas = new FormData();
        formDatas.append('topic_id', data.topic_id);
        formDatas.append('question', data.question);
        formDatas.append('a', data.a);
        formDatas.append('b', data.b);
        formDatas.append('c', data.c);
        formDatas.append('d', data.d);
        formDatas.append('answer', data.answer);
        formDatas.append('answer_exp', data.answer_exp);
        formDatas.append('testType', data.testType);
        if (data.old_id) {
            formDatas.append('last_id', data.old_id);
        }
        if (data.question_img) {
            formDatas.append('question_img', data.question_img);
        }
        formDatas.append('i_assigned_class_subject_id', data.iacs);
        const url = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl + serviceName;
        const options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                'Authorization': 'Bearer ' + token,
            })
        };
        return this.http.post(url, formDatas, options);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
HttpService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ 7646:
/*!*******************************************************!*\
  !*** ./src/app/verifyotp/verifyotp-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyotpPageRoutingModule": () => (/* binding */ VerifyotpPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _verifyotp_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verifyotp.page */ 7416);




const routes = [
    {
        path: '',
        component: _verifyotp_page__WEBPACK_IMPORTED_MODULE_0__.VerifyotpPage
    }
];
let VerifyotpPageRoutingModule = class VerifyotpPageRoutingModule {
};
VerifyotpPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VerifyotpPageRoutingModule);



/***/ }),

/***/ 8394:
/*!***********************************************!*\
  !*** ./src/app/verifyotp/verifyotp.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyotpPageModule": () => (/* binding */ VerifyotpPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _verifyotp_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verifyotp-routing.module */ 7646);
/* harmony import */ var _verifyotp_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verifyotp.page */ 7416);







let VerifyotpPageModule = class VerifyotpPageModule {
};
VerifyotpPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _verifyotp_routing_module__WEBPACK_IMPORTED_MODULE_0__.VerifyotpPageRoutingModule
        ],
        declarations: [_verifyotp_page__WEBPACK_IMPORTED_MODULE_1__.VerifyotpPage]
    })
], VerifyotpPageModule);



/***/ }),

/***/ 7416:
/*!*********************************************!*\
  !*** ./src/app/verifyotp/verifyotp.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyotpPage": () => (/* binding */ VerifyotpPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_verifyotp_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./verifyotp.page.html */ 5430);
/* harmony import */ var _verifyotp_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verifyotp.page.scss */ 6385);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ 4465);
/* harmony import */ var _config_auth_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/auth-constants */ 9582);









let VerifyotpPage = class VerifyotpPage {
    constructor(authService, toastService, storageService, router) {
        this.authService = authService;
        this.toastService = toastService;
        this.storageService = storageService;
        this.router = router;
        this.postData = {
            otpentered: ''
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            var otp = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.otp);
        });
    }
    verifyotp() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            var otp = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.otp);
            var phone = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.phone);
            var pwd = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.pwd);
            if (this.postData.otpentered != '' && this.postData.otpentered == otp) {
                this.toastService.presentToast('Phone number verified successfully');
                if (phone) {
                    var newData = {
                        email: phone,
                        password: pwd,
                    };
                    yield this.authService.login(newData).subscribe((res) => {
                        if (res.access_token) {
                            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.otp);
                            this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.AUTH, res.access_token);
                            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.phone);
                            this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.pwd);
                            window.location.href = 'studenthome';
                            //this.router.navigate(['homepage']);
                        }
                        else {
                            this.toastService.presentToast('Incorrect email and password.');
                        }
                    });
                }
                //this.router.navigate(['/']); 
            }
            else if (this.postData.otpentered == '') {
                this.toastService.presentToast('Please enter OTP sent to your phone number !!!');
            }
            else {
                this.toastService.presentToast('OTP did not match !!!');
            }
        });
    }
    resendOtp() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            var phone = yield this.storageService.get(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.phone);
            if (phone) {
                var newData = {
                    phone: phone,
                };
                yield this.authService.resendOtp(newData).subscribe((res) => {
                    if (res.status == 'Success') {
                        this.storageService.removeStorageItem(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.otp);
                        this.storageService.store(_config_auth_constants__WEBPACK_IMPORTED_MODULE_5__.AuthConstants.otp, res.otp);
                        this.toastService.presentToast('Otp sent successfully');
                    }
                    else {
                        this.toastService.presentToast('Fail to sent otp');
                    }
                });
            }
            else {
                this.toastService.presentToast('Phone number required !!!');
            }
        });
    }
};
VerifyotpPage.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
VerifyotpPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-verifyotp',
        template: _raw_loader_verifyotp_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_verifyotp_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], VerifyotpPage);



/***/ }),

/***/ 6385:
/*!***********************************************!*\
  !*** ./src/app/verifyotp/verifyotp.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".login_btn1 {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZlcmlmeW90cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FBQ0oiLCJmaWxlIjoidmVyaWZ5b3RwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dpbl9idG4xe1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbn0iXX0= */");

/***/ }),

/***/ 5430:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/verifyotp/verifyotp.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n      <ion-grid>\n          <ion-row>\n              <ion-col size=\"3\">\n                  <ion-buttons>\n                      <ion-back-button defaultHref=\"/\" class=\"color_violet\"></ion-back-button>\n                  </ion-buttons>\n              </ion-col>\n              <ion-col size=\"5\">\n                \n              </ion-col>\n              <ion-col size=\"4\">\n                \n              </ion-col>\n          </ion-row>\n      </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"comman_page_padding\">\n    <div class=\"register_page\">\n      <div class=\"logo_area ion-text-center\">\n        <img src=\"../../assets/images/logo.png\" />\n      </div>\n      <div class=\"ion-text-center form_head\">\n        <h1>Enter the OTP received</h1>\n        <span class=\"form_text_line\">We have sent an OTP to your phone</span>\n      </div>\n      <!--======regster page input start=======-->\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <!--======input phone number======-->\n          <ion-item lines=\"none\">\n            <ion-input  [(ngModel)]=\"postData.otpentered\" name='postData' required placeholder=\"Enter OTP\" type=\"text\"></ion-input>\n          </ion-item> \n        </ion-col>\n      </ion-row>\n      <!--======regster page input End=======-->\n    \n      <div class=\"ion-text-center\">\n        <button class=\"login_btn2 comman_login_btn\" (click)=\"verifyotp()\">\n          Verify\n        </button>\n      </div>\n      <div class=\"hr_line\"> \n        <p class=\"lines\">Didn' get OTP</p>\n      </div>\n      <div class=\"ion-text-center\">\n        <button class=\"comman_login_btn login_btn1\" (click)=\"resendOtp()\">\n          Resend OTP\n        </button>\n      </div> \n    </div>\n  </div>\n  \n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_verifyotp_verifyotp_module_ts.js.map