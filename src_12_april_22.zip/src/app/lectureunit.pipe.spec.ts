import { LectureunitPipe } from './lectureunit.pipe';

describe('LectureunitPipe', () => {
  it('create an instance', () => {
    const pipe = new LectureunitPipe();
    expect(pipe).toBeTruthy();
  });
});
